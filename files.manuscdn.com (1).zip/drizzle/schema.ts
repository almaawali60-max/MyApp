import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  float,
  date,
  json,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// جدول المعلمين
export const teachers = mysqlTable("teachers", {
  id: int("id").autoincrement().primaryKey(),
  externalId: varchar("externalId", { length: 64 }), // ID من ملف XML
  name: varchar("name", { length: 255 }).notNull(),
  shortName: varchar("shortName", { length: 100 }),
  gender: mysqlEnum("gender", ["M", "F"]).default("M"),
  weeklyLoad: float("weeklyLoad").default(0), // النصاب الأسبوعي المحسوب من الجدول
  color: varchar("color", { length: 10 }),
  isActive: boolean("isActive").default(true).notNull(),
  isExemptFromSubstitute: boolean("isExemptFromSubstitute").default(false).notNull(), // استثناء دائم من الاحتياط
  specialty: varchar("specialty", { length: 100 }), // التخصص الرسمي للمعلم
  monthlyCapacity: int("monthlyCapacity").default(0), // السقف الشهري للاحتياط (0 = غير محدود)
  individualCap: int("individual_cap").default(4), // السقف الأسبوعي الفردي لكل معلم (افتراضي: 4)
  totalAssignmentsCumulative: int("total_assignments_cumulative").default(0).notNull(), // الرصيد التراكمي لحصص الاحتياط (لا يُصفّر أسبوعياً)
  passwordHash: varchar("password_hash", { length: 255 }), // الرقم السري للمعلم الأول (Subject Head)
  teacherRole: mysqlEnum("teacher_role", ["teacher", "subject_head", "admin"]).default("teacher").notNull(), // دور المعلم
  // === حقول الجولات التراكمية الجديدة (مايو 2026) ===
  currentRoundId: int("current_round_id"), // FK → rotation_rounds.id (يُضاف بعد إنشاء الجدول)
  roundAssignmentsCount: int("round_assignments_count").default(0).notNull(), // عدد الاحتياط في الجولة الحالية (سقف: 2)
  // === حقول الحماية والقيود ===
  isHardBlocked: boolean("is_hard_blocked").default(false).notNull(), // حظر صارم - لا يُختار آلياً أبداً
  isLastResort: boolean("is_last_resort").default(false).notNull(), // خيار أخير فقط
  lastResortMax: int("last_resort_max"), // الحد الأقصى لحصص الطوارئ
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Teacher = typeof teachers.$inferSelect;
export type InsertTeacher = typeof teachers.$inferInsert;

// جدول حصص المعلمين (الجدول الأسبوعي)
export const teacherSchedule = mysqlTable("teacher_schedule", {
  id: int("id").autoincrement().primaryKey(),
  teacherId: int("teacherId").notNull(),
  dayOfWeek: mysqlEnum("dayOfWeek", ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"]).notNull(),
  periodNumber: int("periodNumber").notNull(), // 1-8
  subjectName: varchar("subjectName", { length: 255 }),
  className: varchar("className", { length: 100 }),
  classroomName: varchar("classroomName", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TeacherSchedule = typeof teacherSchedule.$inferSelect;
export type InsertTeacherSchedule = typeof teacherSchedule.$inferInsert;

// جدول سجلات الغياب
export const absenceRecords = mysqlTable("absence_records", {
  id: int("id").autoincrement().primaryKey(),
  teacherId: int("teacherId").notNull(),
  absenceDate: date("absenceDate").notNull(),
  reason: varchar("reason", { length: 500 }),
  createdBy: int("createdBy"), // user id
  // غياب جزئي: قائمة بأرقام الحصص المغيبة فقط (JSON مثل '[1,2,3,4]')
  // null = غياب كامل (جميع الحصص)
  partialPeriods: text("partialPeriods"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AbsenceRecord = typeof absenceRecords.$inferSelect;
export type InsertAbsenceRecord = typeof absenceRecords.$inferInsert;

// جدول توزيع الاحتياط
export const substituteAssignments = mysqlTable("substitute_assignments", {
  id: int("id").autoincrement().primaryKey(),
  absenceRecordId: int("absenceRecordId").notNull(),
  absentTeacherId: int("absentTeacherId").notNull(),
  substituteTeacherId: int("substituteTeacherId").notNull(),
  assignmentDate: date("assignmentDate").notNull(),
  periodNumber: int("periodNumber").notNull(), // 1-8
  dayOfWeek: mysqlEnum("dayOfWeek", ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"]).notNull(),
  subjectName: varchar("subjectName", { length: 255 }),
  className: varchar("className", { length: 100 }),
  isSpecialtyMatch: boolean("isSpecialtyMatch").default(false).notNull(), // هل البديل من نفس التخصص؟
  constraintBreakLevel: int("constraintBreakLevel").default(0).notNull(), // 0=عادي، 1=كسر الفجوة، 2=رفع سقف أسبوعي، 3=رفع النصاب الكلي، 4=معلم أوائل، 5=مستثنى دائم
  constraintBreakReason: varchar("constraintBreakReason", { length: 255 }), // سبب الكسر للعرض البصري
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SubstituteAssignment = typeof substituteAssignments.$inferSelect;
export type InsertSubstituteAssignment = typeof substituteAssignments.$inferInsert;

// جدول الاستثناءات اليومية (مؤقتة)
export const dailyExemptions = mysqlTable("daily_exemptions", {
  id: int("id").autoincrement().primaryKey(),
  teacherId: int("teacherId").notNull(),
  exemptionDate: date("exemptionDate").notNull(),
  reason: varchar("reason", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DailyExemption = typeof dailyExemptions.$inferSelect;
export type InsertDailyExemption = typeof dailyExemptions.$inferInsert;

// جدول الاستثناءات الجزئية الدائمة (بأيام أو حصص محددة)
export const partialExemptions = mysqlTable("teacher_partial_exemptions", {
  id: int("id").autoincrement().primaryKey(),
  teacherId: int("teacherId").notNull(),
  // أيام الاستثناء: نص JSON مثل '["Thursday"]' أو '["Wednesday","Thursday"]'
  exemptDays: text("exemptDays").default("[]"),
  // حصص الاستثناء: نص JSON مثل '[7,8]' أو '[]' تعني كل الحصص
  exemptPeriods: text("exemptPeriods").default("[]"),
  reason: varchar("reason", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PartialExemption = typeof partialExemptions.$inferSelect;
export type InsertPartialExemption = typeof partialExemptions.$inferInsert;

// جدول حالة الدورة (Rotation State)
// يحفظ من أخذ حصة احتياط في الدورة الحالية (الدورة الأولى/الثانية)
export const rotationState = mysqlTable("rotation_state", {
  id: int("id").autoincrement().primaryKey(),
  teacherId: int("teacherId").notNull().unique(),
  roundNumber: int("roundNumber").default(1).notNull(), // رقم الدورة الحالية
  takenInCurrentRound: boolean("takenInCurrentRound").default(false).notNull(), // هل أخذ حصة في الدورة الحالية؟
  totalRoundAssignments: int("totalRoundAssignments").default(0).notNull(), // إجمالي حصص الاحتياط في الدورة الحالية
  lastAssignmentDate: date("lastAssignmentDate"), // تاريخ آخر حصة احتياط
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type RotationState = typeof rotationState.$inferSelect;
export type InsertRotationState = typeof rotationState.$inferInsert;

// جدول إعدادات المدرسة
export const schoolSettings = mysqlTable("school_settings", {
  id: int("id").autoincrement().primaryKey(),
  schoolName: varchar("schoolName", { length: 255 }).notNull().default("مدرسة الخوير للتعليم الأساسي (5-9)"),
  schoolSubtitle: varchar("schoolSubtitle", { length: 255 }).default("نظام توزيع الاحتياط اليومي"),
  directorate: varchar("directorate", { length: 255 }).default("المديرية العامة للتعليم بمسقط"),
  ministry: varchar("ministry", { length: 255 }).default("وزارة التعليم"),
  country: varchar("country", { length: 100 }).default("سلطنة عُمان"),
  logoUrl: text("logoUrl"),
  adminContact: varchar("adminContact", { length: 255 }).default("almaawali60@gmail.com"),
  adminPhone: varchar("adminPhone", { length: 50 }).default("0096892668828"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type SchoolSettings = typeof schoolSettings.$inferSelect;
export type InsertSchoolSettings = typeof schoolSettings.$inferInsert;

// جدول إعدادات النظام
export const systemSettings = mysqlTable("system_settings", {
  id: int("id").autoincrement().primaryKey(),
  settingKey: varchar("settingKey", { length: 100 }).notNull().unique(),
  settingValue: text("settingValue"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// جدول مجالات التخصص (قابل للتعديل من الواجهة)
export const specialtyDomains = mysqlTable("specialty_domains", {
  id: int("id").autoincrement().primaryKey(),
  domainKey: varchar("domainKey", { length: 100 }).notNull().unique(), // مثل: علوم، مهارات_فردية
  domainLabel: varchar("domainLabel", { length: 200 }).notNull(), // الاسم المعروض: مجال العلوم
  specialties: text("specialties").notNull().default("[]"), // JSON: ["فيزياء","كيمياء","أحياء"]
  color: varchar("color", { length: 50 }).default("oklch(0.5 0.1 200)"), // لون المجال
  isCore: boolean("isCore").default(false).notNull(), // هل هو مادة أساسية؟
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type SpecialtyDomain = typeof specialtyDomains.$inferSelect;
export type InsertSpecialtyDomain = typeof specialtyDomains.$inferInsert;

// ============================================================================
// جدول الجولات التراكمية (3 أيام) - مايو 2026
// كل جولة = 3 أيام متتالية
// عند انتهاء الجولة → إنشاء جولة جديدة وتصفير roundAssignmentsCount
// ============================================================================
export const rotationRounds = mysqlTable("rotation_rounds", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(), // مثال: "الجولة الأولى - مايو 2026"
  startDate: date("start_date").notNull(), // YYYY-MM-DD
  endDate: date("end_date").notNull(), // YYYY-MM-DD
  dayCount: int("day_count").default(3).notNull(), // عدد أيام الجولة
  status: mysqlEnum("status", ["active", "completed", "pending"]).default("pending").notNull(),
  isCurrent: boolean("is_current").default(false).notNull(), // هل هي الجولة الحالية
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type RotationRound = typeof rotationRounds.$inferSelect;
export type InsertRotationRound = typeof rotationRounds.$inferInsert;

// ============================================================================
// جدول تتبع التعويض الإلزامي - مايو 2026
// المعلم العائد من غياب → يُكلّف إلزامياً بحصة واحدة يومياً ليومين
// هذه الحصص "تعويض فاقد" ولا تُحتسب ضد سقف المعلم البديل
// ============================================================================
export const compensationTracking = mysqlTable("compensation_tracking", {
  id: int("id").autoincrement().primaryKey(),
  teacherId: int("teacherId").notNull(), // المعلم العائد (يستحق التعويض)
  absenceRecordId: int("absenceRecordId").notNull(), // ربط بسجل الغياب الأصلي
  compensationDate: date("compensation_date").notNull(), // YYYY-MM-DD
  period: int("period").notNull(), // الحصة المطلوبة
  substituteTeacherId: int("substituteTeacherId"), // المعلم البديل (يُعيّن عند التوزيع)
  status: mysqlEnum("compensation_status", ["pending", "completed", "waived"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type CompensationTracking = typeof compensationTracking.$inferSelect;
export type InsertCompensationTracking = typeof compensationTracking.$inferInsert;
