import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {} as any,
    res: {
      cookie: () => {},
      clearCookie: () => {},
    } as any,
  };
}

describe("teachers.getAvailableForPeriod", () => {
  it("يجب أن يُرجع قائمة (مصفوفة) عند استدعائه بمعاملات صحيحة", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.teachers.getAvailableForPeriod({
      dayOfWeek: "Wednesday",
      periodNumber: 6,
      date: "2026-05-14",
      excludeTeacherIds: [],
    });
    // يجب أن يكون النتيجة مصفوفة
    expect(Array.isArray(result)).toBe(true);
  });

  it("يجب أن يستثني المعلم الغائب من القائمة", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    // جلب قائمة بدون استثناء
    const allAvailable = await caller.teachers.getAvailableForPeriod({
      dayOfWeek: "Wednesday",
      periodNumber: 6,
      date: "2026-05-14",
      excludeTeacherIds: [],
    });
    if (allAvailable.length === 0) {
      // لا يوجد معلمون متاحون، تجاوز الاختبار
      return;
    }
    const firstTeacherId = allAvailable[0].id;
    // جلب قائمة مع استثناء المعلم الأول
    const filteredAvailable = await caller.teachers.getAvailableForPeriod({
      dayOfWeek: "Wednesday",
      periodNumber: 6,
      date: "2026-05-14",
      excludeTeacherIds: [firstTeacherId],
    });
    // يجب أن يكون المعلم المستثنى غير موجود في النتيجة
    const ids = filteredAvailable.map((t: any) => t.id);
    expect(ids).not.toContain(firstTeacherId);
  });
});
