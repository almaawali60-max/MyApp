/**
 * اختبارات ميزة استيراد PDF جدول المعلمين
 * تختبر: منطق تحليل الصفحات، خريطة الأيام، تحويل الأرقام العربية
 */
import { describe, it, expect } from "vitest";

// ===== منطق تحويل الأرقام العربية =====
const arabicToWestern = (s: string) =>
  s.replace(/[٠١٢٣٤٥٦٧٨٩]/g, (d: string) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));

describe("arabicToWestern", () => {
  it("يحوّل الأرقام العربية إلى غربية", () => {
    expect(arabicToWestern("٤")).toBe("4");
    expect(arabicToWestern("١٢٣")).toBe("123");
    expect(arabicToWestern("٠")).toBe("0");
    expect(arabicToWestern("٩")).toBe("9");
  });

  it("يبقي الأرقام الغربية كما هي", () => {
    expect(arabicToWestern("123")).toBe("123");
    expect(arabicToWestern("0")).toBe("0");
  });

  it("يعالج النصوص المختلطة", () => {
    expect(arabicToWestern("الحصة ٣")).toBe("الحصة 3");
    expect(arabicToWestern("الصف ١٠")).toBe("الصف 10");
  });
});

// ===== خريطة الأيام العربية =====
const arabicDayMap: Record<string, string> = {
  "الأحد": "Sunday", "الاحد": "Sunday",
  "الاثنين": "Monday", "الأثنين": "Monday", "الإثنين": "Monday",
  "الثلاثاء": "Tuesday",
  "الأربعاء": "Wednesday", "الاربعاء": "Wednesday",
  "الخميس": "Thursday",
};

describe("arabicDayMap", () => {
  it("يعرف جميع أيام الأسبوع الدراسي", () => {
    expect(arabicDayMap["الأحد"]).toBe("Sunday");
    expect(arabicDayMap["الاثنين"]).toBe("Monday");
    expect(arabicDayMap["الثلاثاء"]).toBe("Tuesday");
    expect(arabicDayMap["الأربعاء"]).toBe("Wednesday");
    expect(arabicDayMap["الخميس"]).toBe("Thursday");
  });

  it("يدعم الكتابة البديلة للأيام", () => {
    expect(arabicDayMap["الاحد"]).toBe("Sunday");
    expect(arabicDayMap["الأثنين"]).toBe("Monday");
    expect(arabicDayMap["الإثنين"]).toBe("Monday");
    expect(arabicDayMap["الاربعاء"]).toBe("Wednesday");
  });

  it("يُرجع undefined للأيام غير المعروفة", () => {
    expect(arabicDayMap["الجمعة"]).toBeUndefined();
    expect(arabicDayMap["السبت"]).toBeUndefined();
  });
});

// ===== منطق تحليل بيانات المعلم =====
interface TeacherScheduleEntry {
  day: string;
  period: number | string;
  className: string;
  subject: string;
}

interface TeacherData {
  name: string;
  schedule: TeacherScheduleEntry[];
}

function processTeacherData(teacherData: TeacherData): Array<{
  dayOfWeek: string;
  periodNumber: number;
  subjectName: string;
  className: string;
} | null> {
  return teacherData.schedule.map(s => {
    const dayEn = arabicDayMap[s.day];
    if (!dayEn) return null;
    const periodNum = parseInt(arabicToWestern(String(s.period)));
    if (isNaN(periodNum) || periodNum < 1 || periodNum > 8) return null;
    return {
      dayOfWeek: dayEn,
      periodNumber: periodNum,
      subjectName: s.subject || "غير محدد",
      className: arabicToWestern(s.className || ""),
    };
  });
}

describe("processTeacherData", () => {
  it("يحوّل بيانات المعلم إلى مدخلات قاعدة البيانات", () => {
    const data: TeacherData = {
      name: "أحمد محمد",
      schedule: [
        { day: "الأحد", period: 1, className: "التاسع/1", subject: "رياضيات" },
        { day: "الاثنين", period: 3, className: "الثامن/2", subject: "علوم" },
      ]
    };
    const result = processTeacherData(data).filter(Boolean);
    expect(result).toHaveLength(2);
    expect(result[0]).toEqual({
      dayOfWeek: "Sunday",
      periodNumber: 1,
      subjectName: "رياضيات",
      className: "التاسع/1",
    });
    expect(result[1]).toEqual({
      dayOfWeek: "Monday",
      periodNumber: 3,
      subjectName: "علوم",
      className: "الثامن/2",
    });
  });

  it("يتجاهل الأيام غير المعروفة", () => {
    const data: TeacherData = {
      name: "فاطمة علي",
      schedule: [
        { day: "الجمعة", period: 1, className: "السابع/1", subject: "عربي" },
        { day: "الأحد", period: 2, className: "السادس/1", subject: "عربي" },
      ]
    };
    const result = processTeacherData(data).filter(Boolean);
    expect(result).toHaveLength(1);
    expect(result[0]?.dayOfWeek).toBe("Sunday");
  });

  it("يتجاهل الحصص خارج النطاق 1-8", () => {
    const data: TeacherData = {
      name: "خالد سعيد",
      schedule: [
        { day: "الأحد", period: 0, className: "السابع/1", subject: "تقنية" },
        { day: "الاثنين", period: 9, className: "الثامن/1", subject: "تقنية" },
        { day: "الثلاثاء", period: 5, className: "التاسع/1", subject: "تقنية" },
      ]
    };
    const result = processTeacherData(data).filter(Boolean);
    expect(result).toHaveLength(1);
    expect(result[0]?.periodNumber).toBe(5);
  });

  it("يحوّل الأرقام العربية في رقم الحصة", () => {
    const data: TeacherData = {
      name: "مريم ناصر",
      schedule: [
        { day: "الأحد", period: "٤", className: "السادس/2", subject: "إنجليزي" },
      ]
    };
    const result = processTeacherData(data).filter(Boolean);
    expect(result).toHaveLength(1);
    expect(result[0]?.periodNumber).toBe(4);
  });

  it("يضع 'غير محدد' عند غياب اسم المادة", () => {
    const data: TeacherData = {
      name: "سالم راشد",
      schedule: [
        { day: "الخميس", period: 6, className: "الخامس/1", subject: "" },
      ]
    };
    const result = processTeacherData(data).filter(Boolean);
    expect(result[0]?.subjectName).toBe("غير محدد");
  });

  it("يحوّل الأرقام العربية في اسم الفصل", () => {
    const data: TeacherData = {
      name: "نورة سعيد",
      schedule: [
        { day: "الأربعاء", period: 2, className: "الصف ٩ أساسي/٣", subject: "دراسات" },
      ]
    };
    const result = processTeacherData(data).filter(Boolean);
    expect(result[0]?.className).toBe("الصف 9 أساسي/3");
  });
});

// ===== التحقق من صحة بيانات LLM =====
function isValidLLMResponse(parsed: unknown): parsed is TeacherData {
  if (!parsed || typeof parsed !== "object") return false;
  const obj = parsed as Record<string, unknown>;
  return (
    typeof obj.teacherName === "string" &&
    obj.teacherName.trim().length > 0 &&
    Array.isArray(obj.schedule)
  );
}

describe("isValidLLMResponse", () => {
  it("يقبل استجابة صحيحة", () => {
    expect(isValidLLMResponse({
      teacherName: "أحمد محمد",
      schedule: [{ day: "الأحد", period: 1, className: "التاسع/1", subject: "رياضيات" }]
    })).toBe(true);
  });

  it("يرفض استجابة بدون اسم", () => {
    expect(isValidLLMResponse({ teacherName: "", schedule: [] })).toBe(false);
    expect(isValidLLMResponse({ schedule: [] })).toBe(false);
  });

  it("يرفض استجابة بدون جدول", () => {
    expect(isValidLLMResponse({ teacherName: "أحمد" })).toBe(false);
    expect(isValidLLMResponse({ teacherName: "أحمد", schedule: "not-array" })).toBe(false);
  });

  it("يرفض القيم الفارغة", () => {
    expect(isValidLLMResponse(null)).toBe(false);
    expect(isValidLLMResponse(undefined)).toBe(false);
    expect(isValidLLMResponse("string")).toBe(false);
  });
});

// ===== اختبار توليد اسم المعلم الخارجي =====
describe("externalId generation", () => {
  it("يولّد معرّفاً خارجياً فريداً بناءً على الاسم", () => {
    const name = "أحمد محمد السعيد";
    const externalId = `pdf-${name.replace(/\s+/g, '-')}`;
    expect(externalId).toBe("pdf-أحمد-محمد-السعيد");
  });

  it("يتعامل مع الأسماء ذات المسافات المتعددة", () => {
    const name = "فاطمة  علي";
    const externalId = `pdf-${name.replace(/\s+/g, '-')}`;
    expect(externalId).toBe("pdf-فاطمة-علي");
  });
});
