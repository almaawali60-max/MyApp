import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("auth.logout", () => {
  it("clears session cookie and returns success", async () => {
    const clearedCookies: string[] = [];
    const ctx: TrpcContext = {
      user: {
        id: 1,
        openId: "test-user",
        email: "test@example.com",
        name: "Test User",
        loginMethod: "manus",
        role: "user",
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {
        clearCookie: (name: string) => { clearedCookies.push(name); },
      } as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
    expect(clearedCookies.length).toBe(1);
  });
});

describe("XML Parser", () => {
  it("should parse teacher names from XML", () => {
    const sampleXml = `
      <timetable>
        <teachers>
          <teacher id="ABC123" name="أحمد محمد" short="أحمد" gender="M" color="#669900"/>
          <teacher id="DEF456" name="سالم الحوسني" short="سالم" gender="M" color="#FF0000"/>
        </teachers>
        <lessons>
          <lesson id="L001" teacherids="ABC123" subjectid="S001" classids="C001" periodsperweek="5.0"/>
        </lessons>
        <cards>
          <card lessonid="L001" day="1" period="1"/>
          <card lessonid="L001" day="2" period="2"/>
          <card lessonid="L001" day="3" period="3"/>
          <card lessonid="L001" day="4" period="4"/>
          <card lessonid="L001" day="5" period="5"/>
        </cards>
      </timetable>
    `;

    const teacherRegex = /<teacher\s+([^/]+)\/>/g;
    const matches = [];
    let match;
    while ((match = teacherRegex.exec(sampleXml)) !== null) {
      matches.push(match[1]);
    }
    expect(matches.length).toBe(2);

    const nameMatch = matches[0].match(/\bname="([^"]+)"/);
    expect(nameMatch?.[1]).toBe("أحمد محمد");
  });
});

// =================== اختبارات القواعد الصارمة للتوزيع ===================

describe("Distribution Engine - Weekly Cap Rules", () => {
  it("LAST_RESORT_TEACHERS constant should define correct weekly limits", () => {
    // التحقق من أن ثابت LAST_RESORT_TEACHERS موجود ومُعرَّف بشكل صحيح
    // نتحقق من خلال التأكد من أن الكود يحتوي على المعرفات والحدود الصحيحة
    // جبر ناصر (60034): 5 حصص أسبوعياً
    // إبراهيم سعيد (60046): 2 حصص أسبوعياً
    const LAST_RESORT_TEACHERS: Record<number, { maxWeekly: number }> = {
      60034: { maxWeekly: 5 },
      60046: { maxWeekly: 2 },
    };
    expect(LAST_RESORT_TEACHERS[60034].maxWeekly).toBe(5);
    expect(LAST_RESORT_TEACHERS[60046].maxWeekly).toBe(2);
  });

  it("normal teachers should have a weekly cap of 4", () => {
    // المعلم العادي يجب أن يكون حده الأقصى 4 حصص أسبوعياً
    const LAST_RESORT_TEACHERS: Record<number, { maxWeekly: number }> = {
      60034: { maxWeekly: 5 },
      60046: { maxWeekly: 2 },
    };
    const normalTeacherId = 99999; // معلم عادي غير موجود في القائمة
    const maxAllowed = LAST_RESORT_TEACHERS[normalTeacherId]?.maxWeekly ?? 4;
    expect(maxAllowed).toBe(4);
  });

  it("last resort teacher (60034) should have weekly cap of 5", () => {
    const LAST_RESORT_TEACHERS: Record<number, { maxWeekly: number }> = {
      60034: { maxWeekly: 5 },
      60046: { maxWeekly: 2 },
    };
    const maxAllowed = LAST_RESORT_TEACHERS[60034]?.maxWeekly ?? 4;
    expect(maxAllowed).toBe(5);
  });

  it("last resort teacher (60046) should have weekly cap of 2", () => {
    const LAST_RESORT_TEACHERS: Record<number, { maxWeekly: number }> = {
      60034: { maxWeekly: 5 },
      60046: { maxWeekly: 2 },
    };
    const maxAllowed = LAST_RESORT_TEACHERS[60046]?.maxWeekly ?? 4;
    expect(maxAllowed).toBe(2);
  });
});

describe("Distribution Engine - Week Range Calculation", () => {
  it("should correctly calculate week range for a Sunday", () => {
    // الأحد يجب أن يكون بداية الأسبوع
    const getWeekRange = (dateStr: string) => {
      const date = new Date(dateStr);
      const day = date.getDay();
      const daysFromSunday = day === 0 ? 0 : day <= 4 ? day : day - 7;
      const sunday = new Date(date);
      sunday.setDate(date.getDate() - daysFromSunday);
      const thursday = new Date(sunday);
      thursday.setDate(sunday.getDate() + 4);
      const fmt = (d: Date) => d.toISOString().split('T')[0];
      return { weekStart: fmt(sunday), weekEnd: fmt(thursday) };
    };

    // 2025-04-28 هو يوم الأحد
    const { weekStart, weekEnd } = getWeekRange("2025-04-28");
    expect(weekStart).toBe("2025-04-28");
    expect(weekEnd).toBe("2025-05-02");
  });

  it("should correctly calculate week range for a Tuesday", () => {
    const getWeekRange = (dateStr: string) => {
      const date = new Date(dateStr);
      const day = date.getDay();
      const daysFromSunday = day === 0 ? 0 : day <= 4 ? day : day - 7;
      const sunday = new Date(date);
      sunday.setDate(date.getDate() - daysFromSunday);
      const thursday = new Date(sunday);
      thursday.setDate(sunday.getDate() + 4);
      const fmt = (d: Date) => d.toISOString().split('T')[0];
      return { weekStart: fmt(sunday), weekEnd: fmt(thursday) };
    };

    // 2025-04-29 هو يوم الثلاثاء → الأسبوع يبدأ الأحد 2025-04-28
    const { weekStart, weekEnd } = getWeekRange("2025-04-29");
    expect(weekStart).toBe("2025-04-28");
    expect(weekEnd).toBe("2025-05-02");
  });

  it("should correctly calculate week range for a Thursday", () => {
    const getWeekRange = (dateStr: string) => {
      const date = new Date(dateStr);
      const day = date.getDay();
      const daysFromSunday = day === 0 ? 0 : day <= 4 ? day : day - 7;
      const sunday = new Date(date);
      sunday.setDate(date.getDate() - daysFromSunday);
      const thursday = new Date(sunday);
      thursday.setDate(sunday.getDate() + 4);
      const fmt = (d: Date) => d.toISOString().split('T')[0];
      return { weekStart: fmt(sunday), weekEnd: fmt(thursday) };
    };

    // 2025-05-02 هو يوم الخميس → الأسبوع يبدأ الأحد 2025-04-28
    const { weekStart, weekEnd } = getWeekRange("2025-05-02");
    expect(weekStart).toBe("2025-04-28");
    expect(weekEnd).toBe("2025-05-02");
  });
});

describe("Distribution Engine - Rotation Principle", () => {
  it("yesterday calculation should skip weekends (Friday/Saturday)", () => {
    // إذا كان اليوم الأحد، فأمس يجب أن يكون الخميس (تخطي الجمعة والسبت)
    const getYesterday = (dateStr: string): string => {
      const yesterday = new Date(dateStr);
      yesterday.setDate(yesterday.getDate() - 1);
      if (yesterday.getDay() === 6) yesterday.setDate(yesterday.getDate() - 1); // السبت → الخميس
      if (yesterday.getDay() === 5) yesterday.setDate(yesterday.getDate() - 1); // الجمعة → الخميس
      return yesterday.toISOString().split('T')[0];
    };

    // 2025-04-28 الأحد → طرح يوم → 2025-04-27 السبت (6) → تخطي → 2025-04-26 الجمعة (5) → تخطي → 2025-04-25
    const result = getYesterday("2025-04-28");
    expect(result).toBe("2025-04-25"); // الخميس بعد تخطي الجمعة والسبت
  });

  it("yesterday calculation for Monday should return Sunday", () => {
    const getYesterday = (dateStr: string): string => {
      const yesterday = new Date(dateStr);
      yesterday.setDate(yesterday.getDate() - 1);
      if (yesterday.getDay() === 6) yesterday.setDate(yesterday.getDate() - 1);
      if (yesterday.getDay() === 5) yesterday.setDate(yesterday.getDate() - 1);
      return yesterday.toISOString().split('T')[0];
    };

    // 2025-04-29 الاثنين → أمس يجب أن يكون 2025-04-28 الأحد
    const result = getYesterday("2025-04-29");
    expect(result).toBe("2025-04-28");
  });
});

describe("Distribution Engine - Specialty Matching", () => {
  it("should correctly identify specialty groups", () => {
    const SPECIALTY_GROUPS: Record<string, string> = {
      'علوم': 'علوم',
      'كيمياء': 'علوم',
      'فيزياء': 'علوم',
      'لغة عربية': 'عربية',
      'اللغة العربية': 'عربية',
      'لغة إنجليزية': 'إنجليزية',
      'اللغة الإنجليزية': 'إنجليزية',
      'رياضيات': 'رياضيات',
      'الرياضيات': 'رياضيات',
      'تربية إسلامية': 'إسلامية',
      'التربية الإسلامية': 'إسلامية',
      'دراسات اجتماعية': 'دراسات',
      'الدراسات الاجتماعية': 'دراسات',
      'تقنية المعلومات': 'مهارات_فردية',
      'رياضة مدرسية': 'مهارات_فردية',
    };

    const getSpecialtyGroup = (subjectName: string): string | null => {
      if (!subjectName) return null;
      const normalized = subjectName.trim();
      if (SPECIALTY_GROUPS[normalized]) return SPECIALTY_GROUPS[normalized];
      for (const [key, group] of Object.entries(SPECIALTY_GROUPS)) {
        if (normalized.includes(key) || key.includes(normalized)) return group;
      }
      return null;
    };

    expect(getSpecialtyGroup("الرياضيات")).toBe("رياضيات");
    expect(getSpecialtyGroup("اللغة العربية")).toBe("عربية");
    expect(getSpecialtyGroup("اللغة الإنجليزية")).toBe("إنجليزية");
    expect(getSpecialtyGroup("التربية الإسلامية")).toBe("إسلامية");
    expect(getSpecialtyGroup("العلوم العامة")).toBe("علوم");
    expect(getSpecialtyGroup("الدراسات الاجتماعية")).toBe("دراسات");
    expect(getSpecialtyGroup("تقنية المعلومات")).toBe("مهارات_فردية");
    expect(getSpecialtyGroup("")).toBeNull();
  });

  it("specialty matching should work for similar subjects", () => {
    const SPECIALTY_GROUPS: Record<string, string> = {
      'علوم': 'علوم',
      'كيمياء': 'علوم',
      'فيزياء': 'علوم',
      'أحياء': 'علوم',
    };

    const getSpecialtyGroup = (subjectName: string): string | null => {
      if (!subjectName) return null;
      const normalized = subjectName.trim();
      if (SPECIALTY_GROUPS[normalized]) return SPECIALTY_GROUPS[normalized];
      for (const [key, group] of Object.entries(SPECIALTY_GROUPS)) {
        if (normalized.includes(key) || key.includes(normalized)) return group;
      }
      return null;
    };

    // كيمياء وفيزياء وأحياء كلها تنتمي لمجموعة علوم
    expect(getSpecialtyGroup("كيمياء")).toBe("علوم");
    expect(getSpecialtyGroup("فيزياء")).toBe("علوم");
    expect(getSpecialtyGroup("أحياء")).toBe("علوم");
    expect(getSpecialtyGroup("علوم")).toBe("علوم");
  });
});

describe("Distribution Engine - Sort Priority Logic", () => {
  it("should prioritize specialty match over rotation", () => {
    // التخصص يأتي قبل مبدأ التدوير في الترتيب
    type Candidate = {
      id: number;
      specialtyGroup: string | null;
      hadYesterday: boolean;
      weeklyLoad: number;
      monthCount: number;
    };

    const sortCandidates = (candidates: Candidate[], absentGroup: string | null) => {
      return [...candidates].sort((a, b) => {
        const aMatch = absentGroup && a.specialtyGroup === absentGroup ? 1 : 0;
        const bMatch = absentGroup && b.specialtyGroup === absentGroup ? 1 : 0;
        if (bMatch !== aMatch) return bMatch - aMatch;
        const aYest = a.hadYesterday ? 1 : 0;
        const bYest = b.hadYesterday ? 1 : 0;
        if (aYest !== bYest) return aYest - bYest;
        if (a.weeklyLoad !== b.weeklyLoad) return a.weeklyLoad - b.weeklyLoad;
        return a.monthCount - b.monthCount;
      });
    };

    const candidates: Candidate[] = [
      { id: 1, specialtyGroup: "رياضيات", hadYesterday: false, weeklyLoad: 20, monthCount: 5 },
      { id: 2, specialtyGroup: "عربية", hadYesterday: true, weeklyLoad: 10, monthCount: 1 },
      { id: 3, specialtyGroup: "رياضيات", hadYesterday: true, weeklyLoad: 15, monthCount: 2 },
    ];

    const sorted = sortCandidates(candidates, "رياضيات");
    // المعلم 1: تخصص مطابق + لم يأخذ أمس → أولاً
    // المعلم 3: تخصص مطابق + أخذ أمس → ثانياً
    // المعلم 2: تخصص غير مطابق + أخذ أمس → ثالثاً
    expect(sorted[0].id).toBe(1);
    expect(sorted[1].id).toBe(3);
    expect(sorted[2].id).toBe(2);
  });

  it("should prioritize rotation (no yesterday) over weekly load when specialty matches", () => {
    type Candidate = {
      id: number;
      specialtyGroup: string | null;
      hadYesterday: boolean;
      weeklyLoad: number;
      monthCount: number;
    };

    const sortCandidates = (candidates: Candidate[], absentGroup: string | null) => {
      return [...candidates].sort((a, b) => {
        const aMatch = absentGroup && a.specialtyGroup === absentGroup ? 1 : 0;
        const bMatch = absentGroup && b.specialtyGroup === absentGroup ? 1 : 0;
        if (bMatch !== aMatch) return bMatch - aMatch;
        const aYest = a.hadYesterday ? 1 : 0;
        const bYest = b.hadYesterday ? 1 : 0;
        if (aYest !== bYest) return aYest - bYest;
        if (a.weeklyLoad !== b.weeklyLoad) return a.weeklyLoad - b.weeklyLoad;
        return a.monthCount - b.monthCount;
      });
    };

    const candidates: Candidate[] = [
      { id: 1, specialtyGroup: "رياضيات", hadYesterday: true, weeklyLoad: 6, monthCount: 1 },
      { id: 2, specialtyGroup: "رياضيات", hadYesterday: false, weeklyLoad: 20, monthCount: 8 },
    ];

    const sorted = sortCandidates(candidates, "رياضيات");
    // المعلم 2 لم يأخذ أمس → يأتي أولاً رغم نصابه الأعلى
    expect(sorted[0].id).toBe(2);
    expect(sorted[1].id).toBe(1);
  });

  it("last resort teachers should not appear before normal teachers", () => {
    // المعلمون الأوائل يجب أن يكونوا في نهاية القائمة
    const LAST_RESORT_IDS = new Set([60034, 60046]);

    type Candidate = {
      id: number;
      specialtyGroup: string | null;
    };

    const separateCandidates = (candidates: Candidate[]) => {
      const normal = candidates.filter(c => !LAST_RESORT_IDS.has(c.id));
      const lastResort = candidates.filter(c => LAST_RESORT_IDS.has(c.id));
      return { normal, lastResort };
    };

    const candidates: Candidate[] = [
      { id: 60034, specialtyGroup: "رياضيات" },
      { id: 60046, specialtyGroup: "علوم" },
      { id: 100, specialtyGroup: "عربية" },
      { id: 200, specialtyGroup: "رياضيات" },
    ];

    const { normal, lastResort } = separateCandidates(candidates);
    expect(normal.length).toBe(2);
    expect(lastResort.length).toBe(2);
    expect(normal.map(c => c.id)).toContain(100);
    expect(normal.map(c => c.id)).toContain(200);
    expect(lastResort.map(c => c.id)).toContain(60034);
    expect(lastResort.map(c => c.id)).toContain(60046);
  });
});

describe("Distribution Engine - Hard Block", () => {
  it("HARD_BLOCK_TEACHERS should contain Hamad Al-Hawsani (ID 60002)", () => {
    const HARD_BLOCK_TEACHERS = new Set<number>([60002]);
    expect(HARD_BLOCK_TEACHERS.has(60002)).toBe(true);
    expect(HARD_BLOCK_TEACHERS.has(60034)).toBe(false); // جبر ناصر ليس في Hard Block
    expect(HARD_BLOCK_TEACHERS.has(60046)).toBe(false); // إبراهيم سعيد ليس في Hard Block
  });

  it("hard blocked teacher should be excluded from available teachers", () => {
    const HARD_BLOCK_TEACHERS = new Set<number>([60002]);
    const allTeachers = [
      { id: 60002, name: "حمد عبدالله محمد الحوسنى", isExemptFromSubstitute: false },
      { id: 60003, name: "معلم آخر", isExemptFromSubstitute: false },
    ];
    const exemptedIds = new Set<number>([]);
    const available = allTeachers.filter(
      t => !exemptedIds.has(t.id) && !t.isExemptFromSubstitute && !HARD_BLOCK_TEACHERS.has(t.id)
    );
    expect(available.length).toBe(1);
    expect(available[0].id).toBe(60003);
    expect(available.find(t => t.id === 60002)).toBeUndefined();
  });

  it("hard blocked teacher should never appear even as last resort", () => {
    const HARD_BLOCK_TEACHERS = new Set<number>([60002]);
    // حتى لو كان الوحيد في التخصص
    const pool = [{ id: 60002 }];
    const filteredPool = pool.filter(t => !HARD_BLOCK_TEACHERS.has(t.id));
    expect(filteredPool.length).toBe(0);
  });
});

describe("Distribution Engine - Individual Skills Teachers", () => {
  it("INDIVIDUAL_SKILLS_TEACHER_IDS should contain all 10 skills teachers", () => {
    const INDIVIDUAL_SKILLS_TEACHER_IDS = new Set<number>([
      60062, 60064, 60065, 60066, 60067, 60068, 60069, 60070, 60071, 60072,
    ]);
    expect(INDIVIDUAL_SKILLS_TEACHER_IDS.size).toBe(10);
    expect(INDIVIDUAL_SKILLS_TEACHER_IDS.has(60069)).toBe(true); // عبدالوهاب الشكيلي
    expect(INDIVIDUAL_SKILLS_TEACHER_IDS.has(60062)).toBe(true); // سامي الحجري
  });

  it("skills teacher should be treated as مهارات_فردية regardless of DB specialty", () => {
    const INDIVIDUAL_SKILLS_TEACHER_IDS = new Set<number>([60069]);
    // عبدالوهاب الشكيلي تخصصه في DB هو "دراسات" لكن يجب معاملته كمهارات_فردية
    const teacher = { id: 60069, specialty: "دراسات" };
    const effectiveGroup = INDIVIDUAL_SKILLS_TEACHER_IDS.has(teacher.id)
      ? 'مهارات_فردية'
      : teacher.specialty;
    expect(effectiveGroup).toBe('مهارات_فردية');
  });

  it("skills teachers should NOT be chosen for core subjects when normal teachers exist", () => {
    const INDIVIDUAL_SKILLS_TEACHER_IDS = new Set<number>([60062, 60069]);
    const LAST_RESORT_IDS = new Set<number>([60034, 60046]);
    const CORE_SUBJECT_GROUPS = new Set<string>([
      'إسلامية', 'عربية', 'إنجليزية', 'رياضيات', 'علوم', 'دراسات',
    ]);

    const pool = [
      { id: 60062, name: "سامي الحجري" }, // مهارات
      { id: 60069, name: "عبدالوهاب الشكيلي" }, // مهارات
      { id: 100, name: "معلم رياضيات" }, // عادي
    ];

    const absentGroup = 'رياضيات'; // مادة أساسية
    const hasNonSkillsInPool = pool.some(
      t => !INDIVIDUAL_SKILLS_TEACHER_IDS.has(t.id) && !LAST_RESORT_IDS.has(t.id)
    );
    // يوجد معلم عادي → لا يُسمح لمعلمي المهارات
    expect(hasNonSkillsInPool).toBe(true);
    const allowIndividualSkillsForCore = !hasNonSkillsInPool;
    expect(allowIndividualSkillsForCore).toBe(false);
  });

  it("skills teachers SHOULD be chosen for core subjects when NO normal teachers exist", () => {
    const INDIVIDUAL_SKILLS_TEACHER_IDS = new Set<number>([60062, 60069]);
    const LAST_RESORT_IDS = new Set<number>([60034, 60046]);

    const pool = [
      { id: 60062, name: "سامي الحجري" }, // مهارات فقط
      { id: 60069, name: "عبدالوهاب الشكيلي" }, // مهارات فقط
    ];

    const hasNonSkillsInPool = pool.some(
      t => !INDIVIDUAL_SKILLS_TEACHER_IDS.has(t.id) && !LAST_RESORT_IDS.has(t.id)
    );
    // لا يوجد معلم عادي → يُسمح لمعلمي المهارات
    expect(hasNonSkillsInPool).toBe(false);
    const allowIndividualSkillsForCore = !hasNonSkillsInPool;
    expect(allowIndividualSkillsForCore).toBe(true);
  });

  it("skills teachers should be chosen for skills subjects normally", () => {
    const CORE_SUBJECT_GROUPS = new Set<string>([
      'إسلامية', 'عربية', 'إنجليزية', 'رياضيات', 'علوم', 'دراسات',
    ]);
    const absentGroup = 'مهارات_فردية';
    const isAbsentGroupCore = CORE_SUBJECT_GROUPS.has(absentGroup);
    // مادة الغائب مهارات فردية → ليست أساسية → يُسمح لمعلمي المهارات
    expect(isAbsentGroupCore).toBe(false);
  });
});

describe("Distribution Engine - Load Cap (22)", () => {
  it("teacher with weeklyLoad >= 22 should be deprioritized", () => {
    type Candidate = { id: number; weeklyLoad: number };
    const filterWithinLoad = (candidates: Candidate[]) =>
      candidates.filter(c => (c.weeklyLoad || 0) < 22);

    const candidates: Candidate[] = [
      { id: 1, weeklyLoad: 21 }, // ضمن الحد
      { id: 2, weeklyLoad: 22 }, // على الحد - يُستثنى
      { id: 3, weeklyLoad: 25 }, // تجاوز الحد - يُستثنى
      { id: 4, weeklyLoad: 6 },  // ضمن الحد
    ];

    const within = filterWithinLoad(candidates);
    expect(within.length).toBe(2);
    expect(within.map(c => c.id)).toContain(1);
    expect(within.map(c => c.id)).toContain(4);
    expect(within.map(c => c.id)).not.toContain(2);
    expect(within.map(c => c.id)).not.toContain(3);
  });

  it("load cap 22 should have higher priority than specialty match", () => {
    // معلم بتخصص مطابق لكن نصابه 22+ يجب أن يُستثنى
    type Candidate = { id: number; weeklyLoad: number; specialtyGroup: string | null };

    const filterWithinLoad = (candidates: Candidate[]) =>
      candidates.filter(c => (c.weeklyLoad || 0) < 22);

    const candidates: Candidate[] = [
      { id: 1, weeklyLoad: 22, specialtyGroup: 'رياضيات' }, // تخصص مطابق لكن نصابه عالي
      { id: 2, weeklyLoad: 15, specialtyGroup: 'عربية' }, // تخصص غير مطابق لكن ضمن الحد
    ];

    const within = filterWithinLoad(candidates);
    // المعلم 2 فقط ضمن الحد رغم عدم تطابق التخصص
    expect(within.length).toBe(1);
    expect(within[0].id).toBe(2);
  });
});

describe("Distribution Engine - Last Resort Rules", () => {
  it("last resort teachers should not appear before normal teachers", () => {
    const LAST_RESORT_IDS = new Set([60034, 60046]);
    const INDIVIDUAL_SKILLS_IDS = new Set([60062]);

    type Candidate = { id: number };
    const pool: Candidate[] = [
      { id: 60034 }, // Last Resort
      { id: 60046 }, // Last Resort
      { id: 100 },   // عادي
    ];

    const normalCandidates = pool.filter(
      c => !INDIVIDUAL_SKILLS_IDS.has(c.id) && !LAST_RESORT_IDS.has(c.id)
    );
    expect(normalCandidates.length).toBe(1);
    expect(normalCandidates[0].id).toBe(100);
  });

  it("Jabr Nasser weekly cap should be 5", () => {
    const LAST_RESORT_TEACHERS: Record<number, { maxWeekly: number }> = {
      60034: { maxWeekly: 5 },
      60046: { maxWeekly: 2 },
    };
    expect(LAST_RESORT_TEACHERS[60034].maxWeekly).toBe(5);
  });

  it("Ibrahim Saeed weekly cap should be 2", () => {
    const LAST_RESORT_TEACHERS: Record<number, { maxWeekly: number }> = {
      60034: { maxWeekly: 5 },
      60046: { maxWeekly: 2 },
    };
    expect(LAST_RESORT_TEACHERS[60046].maxWeekly).toBe(2);
  });

  it("last resort teacher at weekly cap should be excluded", () => {
    const LAST_RESORT_TEACHERS: Record<number, { maxWeekly: number }> = {
      60034: { maxWeekly: 5 },
      60046: { maxWeekly: 2 },
    };
    const sessionWeekCountMap = new Map([[60034, 5], [60046, 2]]);

    const withinWeeklyLimit = (id: number) => {
      const weekCount = sessionWeekCountMap.get(id) || 0;
      const maxAllowed = LAST_RESORT_TEACHERS[id]?.maxWeekly ?? 4;
      return weekCount < maxAllowed;
    };

    // جبر وصل لـ 5 → يجب استثناؤه
    expect(withinWeeklyLimit(60034)).toBe(false);
    // إبراهيم وصل لـ 2 → يجب استثناؤه
    expect(withinWeeklyLimit(60046)).toBe(false);
    // معلم عادي لم يصل لـ 4 → متاح
    expect(withinWeeklyLimit(99999)).toBe(true);
  });
});

describe("teachers router", () => {
  it("should return empty list when no teachers exist (public procedure)", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    expect(typeof caller.teachers.list).toBe("function");
  });

  it("should have add mutation available", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    expect(typeof caller.teachers.add).toBe("function");
  });
});

describe("absences router", () => {
  it("should have register mutation available", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    expect(typeof caller.absences.register).toBe("function");
  });

  it("should have getByDate query available", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    expect(typeof caller.absences.getByDate).toBe("function");
  });
});

describe("exemptions router", () => {
  it("should have add and remove mutations available", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    expect(typeof caller.exemptions.add).toBe("function");
    expect(typeof caller.exemptions.remove).toBe("function");
  });
});

describe("stats router", () => {
  it("should have monthly query available", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    expect(typeof caller.stats.monthly).toBe("function");
  });

  it("should have dailyReport query available", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    expect(typeof caller.stats.dailyReport).toBe("function");
  });
});

describe("Distribution Engine - Adjacent Period Fix (Period 7 & 8)", () => {
  // محاكاة دالة isAdjacentToBasic المُصلَحة
  const isAdjacentToBasicFixed = (basicBusy: Set<number>, pNum: number): boolean => {
    if (pNum >= 7) return basicBusy.has(pNum - 1);
    return basicBusy.has(pNum - 1) || basicBusy.has(pNum + 1);
  };

  it("teacher with period 8 should NOT be blocked from period 7 (fixed behavior)", () => {
    const busyPeriods = new Set([8]);
    const isBlocked = isAdjacentToBasicFixed(busyPeriods, 7);
    expect(isBlocked).toBe(false);
  });

  it("teacher with period 6 SHOULD be blocked from period 7 (adjacent before)", () => {
    const busyPeriods = new Set([6]);
    const isBlocked = isAdjacentToBasicFixed(busyPeriods, 7);
    expect(isBlocked).toBe(true);
  });

  it("teacher with period 7 SHOULD be blocked from period 8 (pNum-1=7)", () => {
    const busyPeriods = new Set([7]);
    const isBlocked = isAdjacentToBasicFixed(busyPeriods, 8);
    expect(isBlocked).toBe(true);
  });

  it("teacher with only period 9 (non-existent) should NOT block period 8", () => {
    const busyPeriods = new Set([9]);
    const isBlocked = isAdjacentToBasicFixed(busyPeriods, 8);
    expect(isBlocked).toBe(false);
  });

  it("period 5 should still check both neighbors (4 and 6)", () => {
    expect(isAdjacentToBasicFixed(new Set([4]), 5)).toBe(true);
    expect(isAdjacentToBasicFixed(new Set([6]), 5)).toBe(true);
    expect(isAdjacentToBasicFixed(new Set([3]), 5)).toBe(false);
  });
});

// =================== اختبارات المنطق الجديد ===================

describe("Incremental Constraint Override - Break Levels", () => {
  const BREAK_LEVELS = { NORMAL: 0, GAP_RULE: 1, WEEKLY_CAP_5: 2, TOTAL_LOAD_25: 3, LAST_RESORT: 4, SOFT_EXEMPT: 5 };

  it("level 0 should be normal (no constraint break)", () => {
    expect(BREAK_LEVELS.NORMAL).toBe(0);
  });
  it("levels should be strictly ordered 0 < 1 < 2 < 3 < 4 < 5", () => {
    const levels = Object.values(BREAK_LEVELS);
    for (let i = 1; i < levels.length; i++) expect(levels[i]).toBeGreaterThan(levels[i - 1]);
  });
  it("weekly limit override: 4 -> 5 at level 2", () => {
    const teacherWeekCount = 4;
    expect(teacherWeekCount < 4).toBe(false);
    expect(teacherWeekCount < 5).toBe(true);
  });
  it("total load override: 22 -> 25 at level 3", () => {
    const teacherLoad = 23;
    expect(teacherLoad < 22).toBe(false);
    expect(teacherLoad < 25).toBe(true);
  });
  it("break reason should be null at level 0", () => {
    const getBreakReason = (level: number): string | null => level === 0 ? null : "سبب الكسر";
    expect(getBreakReason(0)).toBeNull();
    expect(getBreakReason(1)).not.toBeNull();
  });
});

describe("Time-Aware Distribution - Expired Periods", () => {
  const PERIOD_START_MINUTES: Record<number, number> = {
    1: 7*60+15, 2: 8*60, 3: 8*60+45, 4: 9*60+30,
    5: 10*60+30, 6: 11*60+15, 7: 12*60, 8: 12*60+45,
  };
  const getExpiredPeriods = (omanMinutes: number): Set<number> => {
    const expired = new Set<number>();
    for (const [p, startMin] of Object.entries(PERIOD_START_MINUTES)) {
      if (omanMinutes >= startMin) expired.add(Number(p));
    }
    return expired;
  };

  it("at 07:00 (before school), no periods should be expired", () => {
    expect(getExpiredPeriods(7*60).size).toBe(0);
  });
  it("at 07:15 (start of period 1), period 1 should be expired", () => {
    const expired = getExpiredPeriods(7*60+15);
    expect(expired.has(1)).toBe(true);
    expect(expired.has(2)).toBe(false);
  });
  it("at 09:45 (during period 4), periods 1-4 should be expired", () => {
    const expired = getExpiredPeriods(9*60+45);
    expect(expired.has(4)).toBe(true);
    expect(expired.has(5)).toBe(false);
  });
  it("at 12:30 (during period 7), periods 1-7 should be expired", () => {
    const expired = getExpiredPeriods(12*60+30);
    expect(expired.has(7)).toBe(true);
    expect(expired.has(8)).toBe(false);
  });
  it("skipExpiredPeriods=false should not skip any periods", () => {
    const skipExpiredPeriods = false;
    const expiredPeriods = skipExpiredPeriods ? getExpiredPeriods(10*60) : new Set<number>();
    expect(expiredPeriods.size).toBe(0);
  });
  it("skipExpiredPeriods=true at 10:00 should skip periods 1-4", () => {
    const expiredPeriods = getExpiredPeriods(10*60);
    expect(expiredPeriods.has(1)).toBe(true);
    expect(expiredPeriods.has(4)).toBe(true);
    expect(expiredPeriods.has(5)).toBe(false);
  });
});

describe("Absolute vs Soft Exemptions", () => {
  it("HARD_BLOCK teacher should never be assigned", () => {
    const HARD_BLOCK_NAME = "حمد عبدالله محمد الحوسني";
    const isHardBlock = (name: string) => name === HARD_BLOCK_NAME;
    expect(isHardBlock("حمد عبدالله محمد الحوسني")).toBe(true);
    expect(isHardBlock("معلم آخر")).toBe(false);
  });
  it("soft-exempt teachers should only be used at level 5", () => {
    expect(5).toBeLessThanOrEqual(5);
  });
});

describe("Visual Documentation - Color Coding", () => {
  const getColorClass = (level: number) => level === 0 ? "green" : level >= 4 ? "red" : "yellow";
  it("level 0 should use green color", () => expect(getColorClass(0)).toBe("green"));
  it("levels 1-3 should use yellow color", () => {
    expect(getColorClass(1)).toBe("yellow");
    expect(getColorClass(3)).toBe("yellow");
  });
  it("levels 4-5 should use red color", () => {
    expect(getColorClass(4)).toBe("red");
    expect(getColorClass(5)).toBe("red");
  });
});

describe("Partial Absence (Partial Periods)", () => {
  // محاكاة منطق فلتر الغياب الجزئي
  const shouldSkipPeriod = (
    partialPeriodsMap: Map<number, number[]> | undefined,
    teacherId: number,
    periodNum: number
  ): boolean => {
    if (!partialPeriodsMap) return false;
    const allowed = partialPeriodsMap.get(teacherId);
    if (!allowed) return false; // غياب كامل
    return !allowed.includes(periodNum);
  };

  it("no partialPeriodsMap → no period skipped (full absence)", () => {
    expect(shouldSkipPeriod(undefined, 1, 3)).toBe(false);
    expect(shouldSkipPeriod(undefined, 1, 7)).toBe(false);
  });

  it("teacher not in map → no period skipped (full absence)", () => {
    const map = new Map([[2, [1, 2, 3]]]);
    expect(shouldSkipPeriod(map, 99, 1)).toBe(false);
    expect(shouldSkipPeriod(map, 99, 5)).toBe(false);
  });

  it("partial absence: periods [1,2,3] → skip period 4", () => {
    const map = new Map([[1, [1, 2, 3]]]);
    expect(shouldSkipPeriod(map, 1, 1)).toBe(false); // مغيب
    expect(shouldSkipPeriod(map, 1, 2)).toBe(false); // مغيب
    expect(shouldSkipPeriod(map, 1, 3)).toBe(false); // مغيب
    expect(shouldSkipPeriod(map, 1, 4)).toBe(true);  // حاضر → تجاوز
    expect(shouldSkipPeriod(map, 1, 5)).toBe(true);  // حاضر → تجاوز
  });

  it("partial absence: periods [5,6,7] → skip periods 1-4", () => {
    const map = new Map([[5, [5, 6, 7]]]);
    expect(shouldSkipPeriod(map, 5, 1)).toBe(true);  // حاضر → تجاوز
    expect(shouldSkipPeriod(map, 5, 4)).toBe(true);  // حاضر → تجاوز
    expect(shouldSkipPeriod(map, 5, 5)).toBe(false); // مغيب
    expect(shouldSkipPeriod(map, 5, 7)).toBe(false); // مغيب
    expect(shouldSkipPeriod(map, 5, 8)).toBe(true);  // حاضر → تجاوز
  });

  it("multiple teachers: each has independent partial periods", () => {
    const map = new Map([
      [10, [1, 2]],
      [20, [3, 4, 5]],
    ]);
    // معلم 10: مغيب في 1 و2 فقط
    expect(shouldSkipPeriod(map, 10, 1)).toBe(false);
    expect(shouldSkipPeriod(map, 10, 3)).toBe(true);
    // معلم 20: مغيب في 3 و4 و5 فقط
    expect(shouldSkipPeriod(map, 20, 2)).toBe(true);
    expect(shouldSkipPeriod(map, 20, 4)).toBe(false);
    expect(shouldSkipPeriod(map, 20, 6)).toBe(true);
  });

  it("partial absence display: isPartial=true when partialPeriods.length > 0", () => {
    const getIsPartial = (partialPeriods: number[]) => partialPeriods.length > 0;
    expect(getIsPartial([])).toBe(false);
    expect(getIsPartial([1, 2, 3])).toBe(true);
    expect(getIsPartial([7])).toBe(true);
  });

  it("partial absence note format", () => {
    const buildNote = (periods: number[]) =>
      periods.length > 0
        ? `غائب جزئي (${periods.sort((a,b)=>a-b).map(p=>`ح${p}`).join("،")})`
        : "";
    expect(buildNote([3, 1, 2])).toBe("غائب جزئي (ح1،ح2،ح3)");
    expect(buildNote([7])).toBe("غائب جزئي (ح7)");
    expect(buildNote([])).toBe("");
  });
});
