import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);

  // ===== Scheduled Task: Weekly Reset Notification =====
  // يُستدعى كل خميس لإرسال تقرير نهاية الأسبوع للمدير
  app.post('/api/scheduled/weekly-reset', async (req, res) => {
    try {
      const { getSubstituteCountByWeek, getAllTeachers } = await import('../db');
      const { notifyOwner } = await import('./notification');

      // حساب نطاق الأسبوع المنتهي
      const now = new Date();
      const dayOfWeek = now.getDay();
      const sunday = new Date(now);
      sunday.setDate(now.getDate() - dayOfWeek);
      const thursday = new Date(sunday);
      thursday.setDate(sunday.getDate() + 4);
      const weekStart = sunday.toISOString().split('T')[0];
      const weekEnd = thursday.toISOString().split('T')[0];

      const allTeachers = await getAllTeachers();
      const weeklyCounts = await getSubstituteCountByWeek(weekStart, weekEnd);
      const countMap = new Map(weeklyCounts.map((c: any) => [c.substituteTeacherId, Number(c.totalCount)]));

      const totalAssignments = weeklyCounts.reduce((sum: number, c: any) => sum + Number(c.totalCount), 0);
      const teachersAtLimit = allTeachers.filter((t: any) => {
        const cnt = countMap.get(t.id) || 0;
        const max = t.id === 60034 ? 5 : t.id === 60046 ? 2 : 4;
        return cnt >= max;
      });

      const topTeachers = Array.from(countMap.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([id, cnt]) => {
          const teacher = allTeachers.find((t: any) => t.id === id);
          return `${teacher?.name || id}: ${cnt} حصص`;
        })
        .join('\n');

      const content = `تقرير نهاية الأسبوع (${weekStart} إلى ${weekEnd})\n\nإجمالي حصص الاحتياط هذا الأسبوع: ${totalAssignments} حصة\nعدد المعلمين الذين وصلوا للحد الأقصى: ${teachersAtLimit.length} معلم\n\nأكثر 5 معلمين احتياطاً هذا الأسبوع:\n${topTeachers}\n\nتنبيه: سيتم تصفير عداد الاحتياط الأسبوعي تلقائياً بدءً من الأحد القادم.`;

      await notifyOwner({
        title: `تقرير نهاية الأسبوع - إجمالي ${totalAssignments} حصة احتياط`,
        content,
      });

      res.json({ success: true, totalAssignments, teachersAtLimit: teachersAtLimit.length });
    } catch (err: any) {
      console.error('[weekly-reset]', err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // ===== PDF Generation Endpoint =====
  app.post('/api/generate-pdf', async (req, res) => {
    try {
      const { spawn } = await import('child_process');
      const path = await import('path');
      const scriptPath = path.join(process.cwd(), 'server', 'generate_pdf.py');
      const inputJson = JSON.stringify(req.body);
      
      // استخدام المسار المطلق لـ python3 لتجنب تعارض بيئات Python المتعددة
      const py = spawn('/usr/bin/python3', [scriptPath], { stdio: ['pipe', 'pipe', 'pipe'] });
      const chunks: Buffer[] = [];
      const errChunks: Buffer[] = [];
      
      py.stdout.on('data', (chunk: Buffer) => chunks.push(chunk));
      py.stderr.on('data', (chunk: Buffer) => errChunks.push(chunk));
      py.stdin.write(inputJson);
      py.stdin.end();
      
      py.on('close', (code: number) => {
        if (code !== 0) {
          const errMsg = Buffer.concat(errChunks).toString();
          console.error('[generate-pdf] Python error:', errMsg);
          res.status(500).json({ error: 'PDF generation failed', details: errMsg });
          return;
        }
        const pdfBuffer = Buffer.concat(chunks);
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'attachment; filename="daily-report.pdf"');
        res.setHeader('Content-Length', pdfBuffer.length);
        res.send(pdfBuffer);
      });
      
      py.on('error', (err: Error) => {
        console.error('[generate-pdf] Spawn error:', err);
        res.status(500).json({ error: 'Failed to spawn Python', details: err.message });
      });
    } catch (err: any) {
      console.error('[generate-pdf]', err);
      res.status(500).json({ error: err.message });
    }
  });

  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
