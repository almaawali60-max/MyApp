import { and, eq, gte, lte, sql, desc, asc, count, sum, like } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2";  // CallbackPool تدعم charset بشكل صحيح
import {
  InsertUser,
  users,
  teachers,
  teacherSchedule,
  absenceRecords,
  substituteAssignments,
  dailyExemptions,
  partialExemptions,
  rotationState,
  specialtyDomains,
  InsertTeacher,
  InsertTeacherSchedule,
  InsertAbsenceRecord,
  InsertSubstituteAssignment,
  InsertDailyExemption,
  InsertPartialExemption,
  Teacher,
  SpecialtyDomain,
  InsertSpecialtyDomain,
  schoolSettings,
  SchoolSettings,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      // إنشاء pool مع charset=utf8mb4 لدعم النصوص العربية (CallbackPool يدعمه drizzle-orm)
      const pool = mysql.createPool({
        uri: process.env.DATABASE_URL,
        charset: "utf8mb4",
        connectionLimit: 10,
      });
      _db = drizzle(pool);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// =================== TEACHERS ===================

export async function getAllTeachers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(teachers).where(eq(teachers.isActive, true)).orderBy(asc(teachers.name));
}

export async function getTeacherById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(teachers).where(eq(teachers.id, id)).limit(1);
  return result[0];
}

export async function insertTeacher(data: InsertTeacher) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(teachers).values(data);
}

export async function updateTeacher(id: number, data: Partial<InsertTeacher>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(teachers).set(data).where(eq(teachers.id, id));
}

export async function deleteTeacher(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  // Soft delete
  await db.update(teachers).set({ isActive: false }).where(eq(teachers.id, id));
}

export async function upsertTeacherByExternalId(data: InsertTeacher) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  // بحث أولاً بـ externalId
  if (data.externalId) {
    const existing = await db
      .select()
      .from(teachers)
      .where(eq(teachers.externalId, data.externalId))
      .limit(1);
    if (existing.length > 0) {
      await db
        .update(teachers)
        .set({ name: data.name, shortName: data.shortName, weeklyLoad: data.weeklyLoad, gender: data.gender, color: data.color, isActive: true, externalId: data.externalId })
        .where(eq(teachers.externalId, data.externalId));
      return existing[0].id;
    }
  }
  // بحث ثانياً بالاسم (حل جذري: يحافظ على id المعلم وبالتالي على استثناءاته)
  if (data.name) {
    const existingByName = await db
      .select()
      .from(teachers)
      .where(eq(teachers.name, data.name))
      .limit(1);
    if (existingByName.length > 0) {
      await db
        .update(teachers)
        .set({ shortName: data.shortName, weeklyLoad: data.weeklyLoad, gender: data.gender, color: data.color, isActive: true, externalId: data.externalId ?? existingByName[0].externalId })
        .where(eq(teachers.id, existingByName[0].id));
      return existingByName[0].id;
    }
  }
  // إنشاء جديد فقط إذا لم يوجد
  const result = await db.insert(teachers).values(data);
  return (result as any)[0]?.insertId as number;
}

// تعطيل المعلمين الغير موجودين في قائمة الأسماء (بدلاً من حذفهم - يحافظ على الاستثناءات)
export async function deactivateTeachersNotInList(activeNames: string[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  if (activeNames.length === 0) return;
  // جلب جميع المعلمين النشطين
  const allActive = await db.select({ id: teachers.id, name: teachers.name }).from(teachers).where(eq(teachers.isActive, true));
  // تعطيل من ليس في القائمة
  for (const t of allActive) {
    if (!activeNames.includes(t.name)) {
      await db.update(teachers).set({ isActive: false }).where(eq(teachers.id, t.id));
    }
  }
}

// =================== SCHEDULE ===================

export async function getTeacherSchedule(teacherId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(teacherSchedule)
    .where(eq(teacherSchedule.teacherId, teacherId))
    .orderBy(asc(teacherSchedule.dayOfWeek), asc(teacherSchedule.periodNumber));
}

export async function getScheduleByDayAndPeriod(dayOfWeek: string, periodNumber: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(teacherSchedule)
    .where(
      and(
        eq(teacherSchedule.dayOfWeek, dayOfWeek as any),
        eq(teacherSchedule.periodNumber, periodNumber)
      )
    );
}

export async function insertScheduleEntries(entries: InsertTeacherSchedule[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  if (entries.length === 0) return;
  await db.insert(teacherSchedule).values(entries);
}

export async function deleteTeacherSchedule(teacherId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(teacherSchedule).where(eq(teacherSchedule.teacherId, teacherId));
}

export async function clearAllSchedules() {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(teacherSchedule);
}

// حذف جميع المعلمين المستوردين من PDF (externalId يبدأ بـ pdf-)
export async function clearPdfTeachers() {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  // حذف حصصهم أولاً (foreign key)
  const pdfTeachers = await db
    .select({ id: teachers.id })
    .from(teachers)
    .where(like(teachers.externalId, "pdf-%"));
  for (const t of pdfTeachers) {
    await db.delete(teacherSchedule).where(eq(teacherSchedule.teacherId, t.id));
  }
  // ثم حذف المعلمين أنفسهم نهائياً
  await db.delete(teachers).where(like(teachers.externalId, "pdf-%"));
}

// حذف جميع المعلمين وبياناتهم المرتبطة نهائياً (للاستخدام عند بداية سنة دراسية جديدة)
export async function deleteAllTeachersAndData() {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  // حذف بالترتيب الصحيح (foreign keys)
  await db.delete(teacherSchedule);
  await db.delete(teachers);
}

// =================== ABSENCE RECORDS ===================

export async function insertAbsenceRecord(data: InsertAbsenceRecord) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(absenceRecords).values(data);
  return (result as any)[0]?.insertId as number;
}

export async function getAbsencesByDate(date: string) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(absenceRecords)
    .where(eq(absenceRecords.absenceDate, date as any));
}

export async function getAbsencesByMonth(year: number, month: number) {
  const db = await getDb();
  if (!db) return [];
  const startDate = `${year}-${String(month).padStart(2, "0")}-01`;
  const endDate = `${year}-${String(month).padStart(2, "0")}-31`;
  return db
    .select()
    .from(absenceRecords)
    .where(
      and(
        gte(absenceRecords.absenceDate, startDate as any),
        lte(absenceRecords.absenceDate, endDate as any)
      )
    )
    .orderBy(desc(absenceRecords.absenceDate));
}

export async function deleteAbsenceRecord(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(absenceRecords).where(eq(absenceRecords.id, id));
}

// =================== SUBSTITUTE ASSIGNMENTS ===================

export async function insertSubstituteAssignments(entries: InsertSubstituteAssignment[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  if (entries.length === 0) return;
  await db.insert(substituteAssignments).values(entries);
}

export async function getAssignmentsByDate(date: string) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(substituteAssignments)
    .where(eq(substituteAssignments.assignmentDate, date as any))
    .orderBy(asc(substituteAssignments.periodNumber));
}

export async function getAssignmentsByAbsenceRecord(absenceRecordId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(substituteAssignments)
    .where(eq(substituteAssignments.absenceRecordId, absenceRecordId))
    .orderBy(asc(substituteAssignments.periodNumber));
}

export async function updateSubstituteAssignment(
  assignmentId: number,
  newSubstituteTeacherId: number,
  isSpecialtyMatch: boolean = false,
  constraintBreakLevel: number = 0,
  constraintBreakReason?: string
) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db
    .update(substituteAssignments)
    .set({
      substituteTeacherId: newSubstituteTeacherId,
      isSpecialtyMatch,
      constraintBreakLevel,
      constraintBreakReason: constraintBreakReason || null
    })
    .where(eq(substituteAssignments.id, assignmentId));
}

export async function getAssignmentById(assignmentId: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db
    .select()
    .from(substituteAssignments)
    .where(eq(substituteAssignments.id, assignmentId))
    .limit(1);
  return rows[0] || null;
}

export async function deleteAssignmentsByAbsenceRecord(absenceRecordId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db
    .delete(substituteAssignments)
    .where(eq(substituteAssignments.absenceRecordId, absenceRecordId));
}

// احتساب عدد حصص الاحتياط لكل معلم في شهر معين
export async function getSubstituteCountByMonth(year: number, month: number) {
  const db = await getDb();
  if (!db) return [];
  const startDate = `${year}-${String(month).padStart(2, "0")}-01`;
  const endDate = `${year}-${String(month).padStart(2, "0")}-31`;
  return db
    .select({
      substituteTeacherId: substituteAssignments.substituteTeacherId,
      totalCount: count(substituteAssignments.id),
    })
    .from(substituteAssignments)
    .where(
      and(
        gte(substituteAssignments.assignmentDate, startDate as any),
        lte(substituteAssignments.assignmentDate, endDate as any)
      )
    )
    .groupBy(substituteAssignments.substituteTeacherId);
}

// =================== DAILY EXEMPTIONS ===================

export async function insertDailyExemption(data: InsertDailyExemption) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(dailyExemptions).values(data);
}

export async function getExemptionsByDate(date: string) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(dailyExemptions)
    .where(eq(dailyExemptions.exemptionDate, date as any));
}

export async function deleteExemption(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(dailyExemptions).where(eq(dailyExemptions.id, id));
}

export async function deleteExemptionByTeacherAndDate(teacherId: number, date: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db
    .delete(dailyExemptions)
    .where(
      and(
        eq(dailyExemptions.teacherId, teacherId),
        eq(dailyExemptions.exemptionDate, date as any)
      )
    );
}

// =================== PARTIAL EXEMPTIONS ===================

export async function getAllPartialExemptions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(partialExemptions).orderBy(asc(partialExemptions.teacherId));
}

export async function getPartialExemptionByTeacher(teacherId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(partialExemptions)
    .where(eq(partialExemptions.teacherId, teacherId))
    .limit(1);
  return result[0];
}

export async function upsertPartialExemption(data: InsertPartialExemption) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const existing = await db
    .select()
    .from(partialExemptions)
    .where(eq(partialExemptions.teacherId, data.teacherId))
    .limit(1);
  if (existing.length > 0) {
    await db
      .update(partialExemptions)
      .set({ exemptDays: data.exemptDays, exemptPeriods: data.exemptPeriods, reason: data.reason })
      .where(eq(partialExemptions.teacherId, data.teacherId));
  } else {
    await db.insert(partialExemptions).values(data);
  }
}

export async function deletePartialExemption(teacherId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(partialExemptions).where(eq(partialExemptions.teacherId, teacherId));
}

// احتساب عدد حصص الاحتياط لكل معلم في أسبوع معين (من startDate إلى endDate)
export async function getSubstituteCountByWeek(weekStart: string, weekEnd: string) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      substituteTeacherId: substituteAssignments.substituteTeacherId,
      totalCount: count(substituteAssignments.id),
    })
    .from(substituteAssignments)
    .where(
      and(
        gte(substituteAssignments.assignmentDate, weekStart as any),
        lte(substituteAssignments.assignmentDate, weekEnd as any)
      )
    )
    .groupBy(substituteAssignments.substituteTeacherId);
}

// جلب تواريخ الاحتياط لمعلم معين في نطاق زمني (لمبدأ التدوير)
export async function getSubstituteAssignmentDates(teacherId: number, weekStart: string, weekEnd: string) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ assignmentDate: substituteAssignments.assignmentDate })
    .from(substituteAssignments)
    .where(
      and(
        eq(substituteAssignments.substituteTeacherId, teacherId),
        gte(substituteAssignments.assignmentDate, weekStart as any),
        lte(substituteAssignments.assignmentDate, weekEnd as any)
      )
    );
}

// =================== ROTATION STATE ===================

/**
 * جلب حالة الدورة لجميع المعلمين
 */
export async function getAllRotationStates() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(rotationState);
}

/**
 * جلب حالة الدورة لمعلم واحد
 */
export async function getRotationStateByTeacher(teacherId: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(rotationState).where(eq(rotationState.teacherId, teacherId)).limit(1);
  return rows[0] || null;
}

/**
 * تسجيل أن معلماً أخذ حصة احتياط (يُستدعى بعد كل توزيع ناجح)
 */
export async function markTeacherTookSubstitute(teacherId: number, assignmentDate: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const existing = await getRotationStateByTeacher(teacherId);
  if (existing) {
    await db.update(rotationState).set({
      takenInCurrentRound: true,
      totalRoundAssignments: existing.totalRoundAssignments + 1,
      lastAssignmentDate: assignmentDate as any,
    }).where(eq(rotationState.teacherId, teacherId));
  } else {
    await db.insert(rotationState).values({
      teacherId,
      roundNumber: 1,
      takenInCurrentRound: true,
      totalRoundAssignments: 1,
      lastAssignmentDate: assignmentDate as any,
    });
  }
}

/**
 * إعادة تعيين الدورة: عندما يأخذ الجميع حصة، نبدأ دورة جديدة
 * يُستدعى تلقائياً عندما تكتمل الدورة الأولى
 */
export async function resetRotationRound(newRoundNumber: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(rotationState).set({
    takenInCurrentRound: false,
    totalRoundAssignments: 0,
    roundNumber: newRoundNumber,
  });
}

/**
 * جلب معرفات المعلمين الذين أخذوا حصة في الدورة الحالية
 */
export async function getTeachersWhoTookInCurrentRound(): Promise<Set<number>> {
  const db = await getDb();
  if (!db) return new Set();
  const rows = await db.select({ teacherId: rotationState.teacherId })
    .from(rotationState)
    .where(eq(rotationState.takenInCurrentRound, true));
  return new Set(rows.map(r => r.teacherId));
}

/**
 * جلب عدد المعلمين الذين لم يأخذوا حصة بعد في الدورة الحالية
 */
export async function getRotationQueueStatus(eligibleTeacherIds: number[]) {
  const db = await getDb();
  if (!db) return { took: [], waiting: eligibleTeacherIds };
  const tookRows = await db.select({ teacherId: rotationState.teacherId })
    .from(rotationState)
    .where(eq(rotationState.takenInCurrentRound, true));
  const tookSet = new Set(tookRows.map(r => r.teacherId));
  const took = eligibleTeacherIds.filter(id => tookSet.has(id));
  const waiting = eligibleTeacherIds.filter(id => !tookSet.has(id));
  return { took, waiting };
}

// =================== SCHEDULE CRUD (يدوي) ===================
/**
 * إضافة حصة واحدة يدوياً لجدول معلم
 */
export async function insertSingleScheduleEntry(entry: {
  teacherId: number;
  dayOfWeek: "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday";
  periodNumber: number;
  subjectName?: string;
  className?: string;
}): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(teacherSchedule).values({
    teacherId: entry.teacherId,
    dayOfWeek: entry.dayOfWeek,
    periodNumber: entry.periodNumber,
    subjectName: entry.subjectName || null,
    className: entry.className || null,
  });
  // إعادة حساب النصاب الأسبوعي
  const allEntries = await db.select({ id: teacherSchedule.id })
    .from(teacherSchedule)
    .where(eq(teacherSchedule.teacherId, entry.teacherId));
  await db.update(teachers).set({ weeklyLoad: allEntries.length })
    .where(eq(teachers.id, entry.teacherId));
  return (result as any).insertId || 0;
}

/**
 * تعديل حصة موجودة في جدول معلم
 */
export async function updateSingleScheduleEntry(id: number, update: {
  subjectName?: string;
  className?: string;
  dayOfWeek?: "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday";
  periodNumber?: number;
}): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(teacherSchedule).set({
    ...(update.subjectName !== undefined ? { subjectName: update.subjectName } : {}),
    ...(update.className !== undefined ? { className: update.className } : {}),
    ...(update.dayOfWeek !== undefined ? { dayOfWeek: update.dayOfWeek } : {}),
    ...(update.periodNumber !== undefined ? { periodNumber: update.periodNumber } : {}),
  }).where(eq(teacherSchedule.id, id));
}

/**
 * حذف حصة واحدة من جدول معلم
 */
export async function deleteSingleScheduleEntry(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  // جلب teacherId قبل الحذف لتحديث النصاب
  const entry = await db.select({ teacherId: teacherSchedule.teacherId })
    .from(teacherSchedule)
    .where(eq(teacherSchedule.id, id))
    .limit(1);
  await db.delete(teacherSchedule).where(eq(teacherSchedule.id, id));
  if (entry.length > 0) {
    const tid = entry[0].teacherId;
    const remaining = await db.select({ id: teacherSchedule.id })
      .from(teacherSchedule)
      .where(eq(teacherSchedule.teacherId, tid));
    await db.update(teachers).set({ weeklyLoad: remaining.length })
      .where(eq(teachers.id, tid));
  }
}

/**
 * جلب جدول معلم كامل بتنسيق 5×8 (يوم × حصة)
 */
export async function getTeacherScheduleGrid(teacherId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select()
    .from(teacherSchedule)
    .where(eq(teacherSchedule.teacherId, teacherId))
    .orderBy(asc(teacherSchedule.dayOfWeek), asc(teacherSchedule.periodNumber));
}

// =================== SPECIALTY DOMAINS ===================
export async function getAllSpecialtyDomains(): Promise<SpecialtyDomain[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(specialtyDomains).orderBy(asc(specialtyDomains.domainLabel));
}

export async function upsertSpecialtyDomain(data: {
  domainKey: string;
  domainLabel: string;
  specialties: string[];
  color?: string;
  isCore?: boolean;
}): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const existing = await db.select({ id: specialtyDomains.id })
    .from(specialtyDomains)
    .where(eq(specialtyDomains.domainKey, data.domainKey))
    .limit(1);
  if (existing.length > 0) {
    await db.update(specialtyDomains).set({
      domainLabel: data.domainLabel,
      specialties: JSON.stringify(data.specialties),
      color: data.color,
      isCore: data.isCore ?? false,
    }).where(eq(specialtyDomains.domainKey, data.domainKey));
  } else {
    await db.insert(specialtyDomains).values({
      domainKey: data.domainKey,
      domainLabel: data.domainLabel,
      specialties: JSON.stringify(data.specialties),
      color: data.color,
      isCore: data.isCore ?? false,
    });
  }
}

export async function deleteSpecialtyDomain(domainKey: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(specialtyDomains).where(eq(specialtyDomains.domainKey, domainKey));
}

export async function seedDefaultSpecialtyDomains(): Promise<void> {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select({ id: specialtyDomains.id }).from(specialtyDomains).limit(1);
  if (existing.length > 0) return; // لا تُعيد البذر إذا كانت البيانات موجودة
  const defaults: InsertSpecialtyDomain[] = [
    { domainKey: 'إسلامية', domainLabel: 'التربية الإسلامية', specialties: JSON.stringify(['تربية إسلامية','التربية الإسلامية','إسلامية']), color: 'oklch(0.45 0.18 140)', isCore: true },
    { domainKey: 'عربية', domainLabel: 'اللغة العربية', specialties: JSON.stringify(['لغة عربية','اللغة العربية','عربي']), color: 'oklch(0.5 0.2 30)', isCore: true },
    { domainKey: 'إنجليزية', domainLabel: 'اللغة الإنجليزية', specialties: JSON.stringify(['لغة إنجليزية','اللغة الإنجليزية','إنجليزي']), color: 'oklch(0.5 0.18 200)', isCore: true },
    { domainKey: 'رياضيات', domainLabel: 'الرياضيات', specialties: JSON.stringify(['رياضيات','الرياضيات']), color: 'oklch(0.5 0.2 260)', isCore: true },
    { domainKey: 'علوم', domainLabel: 'مجال العلوم', specialties: JSON.stringify(['علوم','كيمياء','فيزياء','أحياء','العلوم','الكيمياء','الفيزياء','الأحياء']), color: 'oklch(0.55 0.18 155)', isCore: true },
    { domainKey: 'دراسات', domainLabel: 'الدراسات الاجتماعية', specialties: JSON.stringify(['دراسات اجتماعية','الدراسات الاجتماعية','الدراسات']), color: 'oklch(0.5 0.18 60)', isCore: true },
    { domainKey: 'مهارات_فردية', domainLabel: 'مجال المهارات الفردية', specialties: JSON.stringify(['رياضة مدرسية','الرياضة المدرسية','رياضة','تربية بدنية','التربية البدنية','فنون تشكيلية','الفنون التشكيلية','فنون بصرية','الفنون البصرية','فنون','فن','مهارات موسيقية','المهارات الموسيقية','موسيقى','الفنون الموسيقية','مهارات حياتية','المهارات الحياتية','حياتية','تقنية المعلومات','تقنية','حاسوب']), color: 'oklch(0.5 0.2 310)', isCore: false },
  ];
  await db.insert(specialtyDomains).values(defaults);
}

// =================== SCHEDULE COUNT ===================
export async function getScheduleCountByTeacher(): Promise<Map<number, number>> {
  const db = await getDb();
  if (!db) return new Map();
  const rows = await db
    .select({
      teacherId: teacherSchedule.teacherId,
      cnt: count(teacherSchedule.id),
    })
    .from(teacherSchedule)
    .groupBy(teacherSchedule.teacherId);
  const map = new Map<number, number>();
  for (const r of rows) {
    map.set(r.teacherId, Number(r.cnt));
  }
  return map;
}

// =================== DYNAMIC SPECIALTY GROUPS ===================
/**
 * بناء خريطة SPECIALTY_GROUPS من قاعدة البيانات
 * تُعيد: { subjectName -> domainKey, ... } و { domainKey -> isCore }
 */
export async function buildSpecialtyGroupsFromDB(): Promise<{
  groups: Record<string, string>;
  coreGroups: Set<string>;
}> {
  const domains = await getAllSpecialtyDomains();
  const groups: Record<string, string> = {};
  const coreGroups = new Set<string>();
  for (const domain of domains) {
    let specialties: string[] = [];
    try { specialties = JSON.parse(domain.specialties); } catch { specialties = []; }
    for (const sp of specialties) {
      groups[sp] = domain.domainKey;
    }
    if (domain.isCore) coreGroups.add(domain.domainKey);
  }
  return { groups, coreGroups };
}

// =================== SCHOOL SETTINGS ===================
export async function getSchoolSettings() {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(schoolSettings).limit(1);
  if (rows.length === 0) {
    await db.insert(schoolSettings).values({ id: 1 }).onDuplicateKeyUpdate({ set: { id: 1 } });
    const newRows = await db.select().from(schoolSettings).limit(1);
    return newRows[0] || null;
  }
  return rows[0];
}
export async function updateSchoolSettings(data: Partial<{
  schoolName: string;
  schoolSubtitle: string;
  directorate: string;
  ministry: string;
  country: string;
  logoUrl: string;
  adminContact: string;
  adminPhone: string;
}>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(schoolSettings).set(data).where(eq(schoolSettings.id, 1));
  return getSchoolSettings();;
}

// =================== CUMULATIVE ASSIGNMENTS ===================
/**
 * جلب الرصيد التراكمي لحصص الاحتياط لجميع المعلمين
 * يُستخدم بدلاً من getSubstituteCountByWeek للعدالة التراكمية
 */
export async function getTotalSubstituteCountCumulative() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: teachers.id,
      totalAssignmentsCumulative: teachers.totalAssignmentsCumulative,
    })
    .from(teachers)
    .where(eq(teachers.isActive, true));
}

/**
 * زيادة الرصيد التراكمي لمعلم بعد تكليفه بحصة احتياط
 */
export async function incrementCumulativeCount(teacherId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.execute(
    sql`UPDATE teachers SET total_assignments_cumulative = total_assignments_cumulative + 1 WHERE id = ${teacherId}`
  );
}

/**
 * إعادة تعيين الرصيد التراكمي لمعلم معين (للاستخدام الإداري)
 */
export async function resetCumulativeCount(teacherId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(teachers).set({ totalAssignmentsCumulative: 0 }).where(eq(teachers.id, teacherId));
}

/**
 * إعادة تعيين الرصيد التراكمي لجميع المعلمين (للاستخدام الإداري)
 */
export async function resetAllCumulativeCounts() {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.execute(sql`UPDATE teachers SET total_assignments_cumulative = 0`);
}

// =================== SUBJECT HEAD (المعلم الأول) ===================
/**
 * تعيين كلمة مرور المعلم الأول
 */
export async function setSubjectHeadPassword(teacherId: number, passwordHash: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(teachers).set({
    passwordHash,
    teacherRole: "subject_head",
  }).where(eq(teachers.id, teacherId));
}

/**
 * التحقق من دخول المعلم الأول
 * يُعيد بيانات المعلم إذا كان الرقم السري صحيحاً، أو null إذا كان خاطئاً
 */
export async function getSubjectHeadByIdForLogin(teacherId: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db
    .select()
    .from(teachers)
    .where(
      and(
        eq(teachers.id, teacherId),
        eq(teachers.teacherRole, "subject_head")
      )
    )
    .limit(1);
  return rows[0] || null;
}

/**
 * جلب جميع المعلمين الأوائل
 */
export async function getAllSubjectHeads() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(teachers)
    .where(
      and(
        eq(teachers.teacherRole, "subject_head"),
        eq(teachers.isActive, true)
      )
    );
}

/**
 * إزالة صلاحية المعلم الأول وإعادته لمعلم عادي
 */
export async function removeSubjectHead(teacherId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(teachers).set({
    teacherRole: "teacher",
    passwordHash: null,
  }).where(eq(teachers.id, teacherId));
}

// =================== ROTATION ROUNDS (الجولات التراكمية) ===================

/**
 * جلب الجولة التراكمية الحالية النشطة
 */
export async function getCurrentRotationRound() {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.execute(
    sql`SELECT * FROM rotation_rounds WHERE is_current = 1 AND status = 'active' LIMIT 1`
  );
  const result = rows as any;
  const data = Array.isArray(result) ? result[0] : result;
  if (!data || !Array.isArray(data) || data.length === 0) return null;
  return data[0] as { id: number; name: string; start_date: string; end_date: string; day_count: number; status: string; is_current: number };
}

/**
 * جلب roundAssignmentsCount لجميع المعلمين النشطين
 * يُستخدم كأولوية أولى في العدالة التراكمية
 */
export async function getRoundAssignmentsCounts() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: teachers.id,
      roundAssignmentsCount: teachers.roundAssignmentsCount,
    })
    .from(teachers)
    .where(eq(teachers.isActive, true));
}

/**
 * زيادة عداد الجولة الحالية لمعلم بعد تكليفه
 */
export async function incrementRoundCount(teacherId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.execute(
    sql`UPDATE teachers SET round_assignments_count = round_assignments_count + 1 WHERE id = ${teacherId}`
  );
}

/**
 * تصفير عداد الجولة لجميع المعلمين (عند بدء جولة جديدة)
 */
export async function resetRoundCounts() {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.execute(sql`UPDATE teachers SET round_assignments_count = 0`);
}

/**
 * إنشاء جولة تراكمية جديدة وتفعيلها
 */
export async function createNewRotationRound(name: string, startDate: string, endDate: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  // إنهاء الجولة الحالية
  await db.execute(sql`UPDATE rotation_rounds SET is_current = 0, status = 'completed' WHERE is_current = 1`);
  // إنشاء جولة جديدة
  await db.execute(
    sql`INSERT INTO rotation_rounds (name, start_date, end_date, day_count, status, is_current) 
        VALUES (${name}, ${startDate}, ${endDate}, 3, 'active', 1)`
  );
  // تصفير عداد الجولة لجميع المعلمين
  await resetRoundCounts();
  return getCurrentRotationRound();
}

// =================== COMPENSATION TRACKING (تتبع التعويض) ===================

/**
 * إنشاء سجل تعويض إلزامي للمعلم العائد من غياب
 */
export async function createCompensationRecord(
  teacherId: number,
  absenceRecordId: number,
  compensationDate: string,
  period: number
) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.execute(
    sql`INSERT INTO compensation_tracking (teacherId, absenceRecordId, compensation_date, period, compensation_status)
        VALUES (${teacherId}, ${absenceRecordId}, ${compensationDate}, ${period}, 'pending')`
  );
}

/**
 * جلب سجلات التعويض المعلقة لتاريخ معين
 */
export async function getPendingCompensations(date: string) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.execute(
    sql`SELECT ct.*, t.name as teacher_name, t.specialty
        FROM compensation_tracking ct
        JOIN teachers t ON ct.teacherId = t.id
        WHERE ct.compensation_date = ${date} AND ct.compensation_status = 'pending'`
  );
  const result = rows as any;
  const data = Array.isArray(result) ? result[0] : result;
  return Array.isArray(data) ? data : [];
}

/**
 * تحديث حالة التعويض إلى مكتمل
 */
export async function completeCompensation(compensationId: number, substituteTeacherId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.execute(
    sql`UPDATE compensation_tracking 
        SET compensation_status = 'completed', substituteTeacherId = ${substituteTeacherId}
        WHERE id = ${compensationId}`
  );
}

// =================== EMERGENCY SYSTEM (نظام الطوارئ القصوى) ===================

/**
 * جلب المعلمين المتاحين لحصة معينة (مع خيار تجاهل حماية النصاب 22+)
 * يُستخدم في وضع الطوارئ
 */
export async function getEmergencyCandidates(params: {
  date: string;
  absentTeacherId: number;
  period: number;
  ignoreFullLoad: boolean;
  ignoreRoundCap: boolean;
}) {
  const db = await getDb();
  if (!db) return [];

  // جلب المعلمين الذين لديهم حصة في هذا الوقت (مشغولون)
  const busyRows = await db.execute(
    sql`SELECT DISTINCT teacher_id FROM teacher_schedule 
        WHERE day_of_week = DAYNAME(${params.date}) AND period_number = ${params.period}`
  );
  const busyResult = busyRows as any;
  const busyData = Array.isArray(busyResult) ? busyResult[0] : busyResult;
  const busyIds = new Set<number>(
    Array.isArray(busyData) ? busyData.map((r: any) => Number(r.teacher_id)) : []
  );

  // جلب المعلمين المكلفين بالفعل في هذه الحصة اليوم
  const assignedRows = await db.execute(
    sql`SELECT DISTINCT substitute_teacher_id FROM substitute_assignments 
        WHERE assignment_date = ${params.date} AND period_number = ${params.period}`
  );
  const assignedResult = assignedRows as any;
  const assignedData = Array.isArray(assignedResult) ? assignedResult[0] : assignedResult;
  const assignedIds = new Set<number>(
    Array.isArray(assignedData) ? assignedData.map((r: any) => Number(r.substitute_teacher_id)) : []
  );

  // جلب المعلمين الغائبين اليوم
  const absentRows = await db.execute(
    sql`SELECT DISTINCT teacher_id FROM absence_records 
        WHERE absence_date = ${params.date}`
  );
  const absentResult = absentRows as any;
  const absentData = Array.isArray(absentResult) ? absentResult[0] : absentResult;
  const absentIds = new Set<number>(
    Array.isArray(absentData) ? absentData.map((r: any) => Number(r.teacher_id)) : []
  );
  absentIds.add(params.absentTeacherId);

  // جلب جميع المعلمين النشطين
  const allRows = await db.execute(
    sql`SELECT id, name, specialty, weekly_load, total_assignments_cumulative, 
               round_assignments_count, is_hard_blocked, individual_cap
        FROM teachers 
        WHERE is_active = 1 AND (is_exempt_from_substitute IS NULL OR is_exempt_from_substitute = 0)
        ORDER BY round_assignments_count ASC, total_assignments_cumulative ASC`
  );
  const allResult = allRows as any;
  const allData = Array.isArray(allResult) ? allResult[0] : allResult;
  if (!Array.isArray(allData)) return [];

  return allData.filter((t: any) => {
    const id = Number(t.id);
    // القيود الصارمة التي لا تُكسر حتى في الطوارئ
    if (t.is_hard_blocked) return false;       // Hard Block مطلق
    if (absentIds.has(id)) return false;        // لا يُكلف الغائب نفسه
    if (busyIds.has(id)) return false;          // مشغول بحصة أساسية
    if (assignedIds.has(id)) return false;      // مكلف بالفعل في هذه الحصة
    // القيود التي تُكسر في الطوارئ
    if (!params.ignoreFullLoad && Number(t.weekly_load) >= 22) return false;
    if (!params.ignoreRoundCap) {
      const cap = Number(t.individual_cap) || 4;
      if (Number(t.round_assignments_count) >= cap) return false;
    }
    return true;
  });
}

/**
 * جلب أي معلم متاح (آخر ملاذ - الطوارئ القصوى)
 */
export async function findAnyAvailableTeacher(
  date: string,
  period: number,
  absentTeacherId: number
): Promise<{ id: number; name: string; specialty: string | null; weeklyLoad: number } | null> {
  const candidates = await getEmergencyCandidates({
    date,
    period,
    absentTeacherId,
    ignoreFullLoad: true,
    ignoreRoundCap: true,
  });
  if (candidates.length === 0) return null;
  const t = candidates[0];
  return {
    id: Number(t.id),
    name: String(t.name),
    specialty: t.specialty ? String(t.specialty) : null,
    weeklyLoad: Number(t.weekly_load) || 0,
  };
}

/**
 * إحصائيات الطوارئ: عدد الحصص الموزعة والشاغرة لتاريخ معين
 */
export async function getEmergencyStats(date: string) {
  const db = await getDb();
  if (!db) return { totalAbsences: 0, totalPeriods: 0, distributed: 0, vacant: 0 };

  // جلب إجمالي الحصص الغائبة
  const absenceRows = await db.execute(
    sql`SELECT COUNT(*) as cnt FROM absence_records WHERE absence_date = ${date}`
  );
  const absResult = absenceRows as any;
  const absData = Array.isArray(absResult) ? absResult[0] : absResult;
  const totalAbsences = Array.isArray(absData) ? Number(absData[0]?.cnt || 0) : 0;

  // جلب عدد التوزيعات
  const assignRows = await db.execute(
    sql`SELECT COUNT(*) as cnt FROM substitute_assignments WHERE assignment_date = ${date}`
  );
  const assignResult = assignRows as any;
  const assignData = Array.isArray(assignResult) ? assignResult[0] : assignResult;
  const distributed = Array.isArray(assignData) ? Number(assignData[0]?.cnt || 0) : 0;

  return {
    totalAbsences,
    distributed,
    vacant: Math.max(0, totalAbsences * 8 - distributed), // تقدير تقريبي
  };
}

/**
 * تصفير سقف الجولة لجميع المعلمين (استعادة القيود الطبيعية)
 */
export async function restoreNormalLimits() {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  // لا نغير round_assignments_count - فقط نتأكد من أن السقف الفردي طبيعي
  // القيود تُطبق في الخوارزمية عبر individual_cap
  // هذه الدالة تُعيد علامة الطوارئ في الجولة الحالية
  await db.execute(
    sql`UPDATE rotation_rounds 
        SET name = REPLACE(name, ' [طوارئ]', '')
        WHERE is_current = 1 AND name LIKE '%[طوارئ]%'`
  );
}

/**
 * جلب المعلمين المتاحين في حصة معينة:
 * - ليس لديهم حصة أصلية في ذلك اليوم والحصة
 * - ليسوا غائبين في ذلك التاريخ
 * - يمكن استثناء معلمين محددين (مثل المعلم الغائب نفسه)
 */
export async function getAvailableTeachersForPeriod(
  dayOfWeek: string,
  periodNumber: number,
  date: string,
  excludeTeacherIds: number[] = [],
  absentTeacherId?: number
) {
  const db = await getDb();
  if (!db) return [];
  // 1. جلب جميع المعلمين النشطين
  const allTeachers = await db
    .select()
    .from(teachers)
    .where(eq(teachers.isActive, true))
    .orderBy(asc(teachers.name));
  // 2. جلب المعلمين الذين لديهم حصة أصلية في ذلك اليوم والحصة
  const busyRows = await db
    .select({ teacherId: teacherSchedule.teacherId })
    .from(teacherSchedule)
    .where(
      and(
        eq(teacherSchedule.dayOfWeek, dayOfWeek as any),
        eq(teacherSchedule.periodNumber, periodNumber)
      )
    );
  const busyIds = new Set(busyRows.map(r => r.teacherId));
  // 3. جلب المعلمين الغائبين في ذلك التاريخ
  const absentRows = await db
    .select({ teacherId: absenceRecords.teacherId })
    .from(absenceRecords)
    .where(eq(absenceRecords.absenceDate, date as any));
  const absentIds = new Set(absentRows.map(r => r.teacherId));
  // 4. جلب تخصص المعلم الغائب لمقارنة التخصص
  let absentSpecialty: string | null = null;
  if (absentTeacherId) {
    const absentTeacher = allTeachers.find(t => t.id === absentTeacherId);
    absentSpecialty = absentTeacher?.specialty ?? null;
  }
  // 5. تصفية: المتاحون = ليسوا مشغولين + ليسوا غائبين + ليسوا في قائمة الاستثناء
  const excludeSet = new Set(excludeTeacherIds);
  const available = allTeachers.filter(
    t => !busyIds.has(t.id) && !absentIds.has(t.id) && !excludeSet.has(t.id)
  );
  // 6. إضافة حقل sameSubject لكل معلم وترتيب المتطابقين أولاً
  const withMatch = available.map(t => ({
    ...t,
    sameSubject: !!(absentSpecialty && t.specialty && t.specialty === absentSpecialty),
  }));
  // المتطابقون في التخصص أولاً ثم الباقي حسب الاسم
  return withMatch.sort((a, b) => {
    if (a.sameSubject && !b.sameSubject) return -1;
    if (!a.sameSubject && b.sameSubject) return 1;
    return a.name.localeCompare(b.name, 'ar');
  });
}
