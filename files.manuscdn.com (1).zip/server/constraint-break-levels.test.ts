/**
 * اختبارات نظام كسر القيود المتدرج - المستويات 6 و7
 * المستوى 6: أي معلم فارغ في الحصة له صلة بالصف (نفس المرحلة الدراسية)
 * المستوى 7: أي معلم فارغ في الحصة مطلقاً (أقل تراكمي)
 */
import { describe, it, expect } from "vitest";

// =================== اختبار منطق استخراج المرحلة الدراسية ===================
describe("استخراج المرحلة الدراسية من className", () => {
  const GRADE_REGEX = /(الخامس|السادس|السابع|الثامن|التاسع|الرابع|الثالث|الثاني|الأول)/i;

  it("يستخرج المرحلة من className بشكل صحيح", () => {
    const testCases = [
      { className: "السابع أساسي/3", expected: "السابع" },
      { className: "التاسع أساسي/7", expected: "التاسع" },
      { className: "الخامس أساسي/1", expected: "الخامس" },
      { className: "الثامن أساسي/2", expected: "الثامن" },
      { className: "السادس أساسي/4", expected: "السادس" },
    ];

    for (const { className, expected } of testCases) {
      const match = className.match(GRADE_REGEX);
      expect(match).not.toBeNull();
      expect(match![1]).toBe(expected);
    }
  });

  it("يُرجع null عند عدم وجود مرحلة في className", () => {
    const className = "فصل غير معروف";
    const match = className.match(GRADE_REGEX);
    expect(match).toBeNull();
  });
});

// =================== اختبار منطق فلترة المستوى 6 ===================
describe("فلترة المستوى 6: المعلمون الفارغون من نفس المرحلة", () => {
  // محاكاة بيانات المعلمين والجداول
  const mockTeachers = [
    { id: 1, name: "معلم أ", specialty: "رياضيات" },
    { id: 2, name: "معلم ب", specialty: "علوم" },
    { id: 3, name: "معلم ج", specialty: "عربية" },
    { id: 4, name: "معلم د", specialty: "تقنية" },
  ];

  // جداول المعلمين (className يحتوي على المرحلة)
  const mockSchedules: Record<number, Array<{className: string | null; subjectName: string | null}>> = {
    1: [{ className: "السابع أساسي/1", subjectName: "رياضيات" }],
    2: [{ className: "الثامن أساسي/2", subjectName: "علوم" }],
    3: [{ className: "السابع أساسي/3", subjectName: "عربية" }],
    4: [{ className: "التاسع أساسي/5", subjectName: "تقنية" }],
  };

  it("يُرجع فقط المعلمين الذين يدرسون نفس المرحلة", () => {
    const absentGrade = "السابع"; // المعلم الغائب يدرس السابع
    const GRADE_REGEX = new RegExp(absentGrade, 'i');

    const filtered = mockTeachers.filter(t => {
      const tSch = mockSchedules[t.id] || [];
      return tSch.some(s => {
        const cn = (s.className ?? "").trim();
        return GRADE_REGEX.test(cn);
      });
    });

    // معلم أ (السابع) ومعلم ج (السابع) يجب أن يظهرا
    expect(filtered.map(t => t.id)).toContain(1);
    expect(filtered.map(t => t.id)).toContain(3);
    // معلم ب (الثامن) ومعلم د (التاسع) يجب ألا يظهرا
    expect(filtered.map(t => t.id)).not.toContain(2);
    expect(filtered.map(t => t.id)).not.toContain(4);
  });

  it("يُرجع جميع المعلمين الفارغين عند عدم وجود مرحلة محددة", () => {
    const absentGrade = null; // لا يوجد مرحلة محددة

    const filtered = mockTeachers.filter(t => {
      if (absentGrade) {
        const tSch = mockSchedules[t.id] || [];
        return tSch.some(s => {
          const cn = (s.className ?? "").trim();
          return new RegExp(absentGrade, 'i').test(cn);
        });
      }
      return true; // بدون قيد المرحلة
    });

    expect(filtered.length).toBe(mockTeachers.length);
  });
});

// =================== اختبار منطق المستوى 7 ===================
describe("فلترة المستوى 7: أي معلم فارغ في الحصة", () => {
  const mockTeachers = [
    { id: 1, name: "معلم أ", totalAssignmentsCumulative: 5 },
    { id: 2, name: "معلم ب", totalAssignmentsCumulative: 2 },
    { id: 3, name: "معلم ج", totalAssignmentsCumulative: 8 },
  ];

  // الحصة 6: معلم أ مشغول، معلم ب وج فارغان
  const busyInPeriod6 = new Set([1]);

  it("يُرجع المعلمين الفارغين في الحصة فقط", () => {
    const filtered = mockTeachers.filter(t => {
      return !busyInPeriod6.has(t.id);
    });

    expect(filtered.map(t => t.id)).not.toContain(1);
    expect(filtered.map(t => t.id)).toContain(2);
    expect(filtered.map(t => t.id)).toContain(3);
  });

  it("يُرتّب المعلمين حسب أقل تراكمي", () => {
    const filtered = mockTeachers
      .filter(t => !busyInPeriod6.has(t.id))
      .sort((a, b) => a.totalAssignmentsCumulative - b.totalAssignmentsCumulative);

    // معلم ب (2) يجب أن يكون أولاً، ثم معلم ج (8)
    expect(filtered[0].id).toBe(2);
    expect(filtered[1].id).toBe(3);
  });
});

// =================== اختبار ترتيب الأولويات في كسر القيود ===================
describe("ترتيب أولويات كسر القيود", () => {
  it("يتحقق من ترتيب المستويات 0 → 7", () => {
    const levels = [0, 1, 2, 3, 4, 5, 6, 7];
    // التحقق من أن كل مستوى أعلى من السابق (كسر أكثر للقيود)
    for (let i = 1; i < levels.length; i++) {
      expect(levels[i]).toBeGreaterThan(levels[i - 1]);
    }
  });

  it("المستوى 6 يأتي قبل المستوى 7 في الأولوية", () => {
    // المستوى 6 (صلة بالصف) أفضل من المستوى 7 (أي معلم)
    expect(6).toBeLessThan(7);
  });

  it("المستوى 7 هو الملاذ الأخير قبل ترك الحصة بدون بديل", () => {
    const MAX_LEVEL = 7;
    expect(MAX_LEVEL).toBe(7);
  });
});
