import { COOKIE_NAME } from "@shared/const";
import bcrypt from "bcryptjs";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getAllTeachers,
  getTeacherById,
  insertTeacher,
  updateTeacher,
  deleteTeacher,
  upsertTeacherByExternalId,
  getTeacherSchedule,
  getScheduleByDayAndPeriod,
  insertScheduleEntries,
  deleteTeacherSchedule,
  clearAllSchedules,
  clearPdfTeachers,
  deactivateTeachersNotInList,
  deleteAllTeachersAndData,
  insertAbsenceRecord,
  getAbsencesByDate,
  getAbsencesByMonth,
  deleteAbsenceRecord,
  insertSubstituteAssignments,
  getAssignmentsByDate,
  getAssignmentsByAbsenceRecord,
  deleteAssignmentsByAbsenceRecord,
  getSubstituteCountByMonth,
  insertDailyExemption,
  getExemptionsByDate,
  deleteExemption,
  deleteExemptionByTeacherAndDate,
  getAllPartialExemptions,
  getPartialExemptionByTeacher,
  upsertPartialExemption,
  deletePartialExemption,
  updateSubstituteAssignment,
  getAssignmentById,
  getSubstituteCountByWeek,
  getTeachersWhoTookInCurrentRound,
  markTeacherTookSubstitute,
  resetRotationRound,
  getRotationQueueStatus,
  getAllRotationStates,
  insertSingleScheduleEntry,
  updateSingleScheduleEntry,
  deleteSingleScheduleEntry,
  getTeacherScheduleGrid,
  getAllSpecialtyDomains,
  upsertSpecialtyDomain,
  deleteSpecialtyDomain,
  seedDefaultSpecialtyDomains,
  getScheduleCountByTeacher,
  buildSpecialtyGroupsFromDB,
  getSchoolSettings,
  updateSchoolSettings,
  getTotalSubstituteCountCumulative,
  incrementCumulativeCount,
  resetAllCumulativeCounts,
  setSubjectHeadPassword,
  getSubjectHeadByIdForLogin,
  getAllSubjectHeads,
  removeSubjectHead,
  getRoundAssignmentsCounts,
  incrementRoundCount,
  resetRoundCounts,
  createNewRotationRound,
  getCurrentRotationRound,
  getPendingCompensations,
  createCompensationRecord,
  completeCompensation,
  getEmergencyCandidates,
  findAnyAvailableTeacher,
  getEmergencyStats,
  restoreNormalLimits,
  getAvailableTeachersForPeriod,
} from "./db";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"] as const;
type DayOfWeek = (typeof DAYS)[number];

const DAY_LABELS: Record<DayOfWeek, string> = {
  Sunday: "الأحد",
  Monday: "الاثنين",
  Tuesday: "الثلاثاء",
  Wednesday: "الأربعاء",
  Thursday: "الخميس",
};

// =================== XML PARSER ===================
function parseXmlTeachersAndSchedule(xmlContent: string) {
  // تنظيف إعلان الترميز من XML حتى لا يتدخل في معالجة النصوص
  // استبدال إعلان الترميز بـ UTF-8 حتى لا تتعارض مع النصوص العربية التي تم تحويلها مسبقاً
  // تطبيع CRLF (Windows) إلى LF لضمان عمل regex بشكل صحيح
  const normalizedContent = xmlContent
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(
      /<\?xml[^?]*\?>/,
      '<?xml version="1.0" encoding="UTF-8"?>'
    );

  // استخراج المعلمين
  const teacherRegex = /<teacher\s+([^>]+)\/>/g;
  const teachersMap = new Map<string, { id: string; name: string; shortName: string; gender: string; color: string }>();

  let match;
  while ((match = teacherRegex.exec(normalizedContent)) !== null) {
    const attrs = match[1];
    const getId = attrs.match(/\bid="([^"]+)"/);
    const getName = attrs.match(/\bname="([^"]+)"/);
    const getShort = attrs.match(/\bshort="([^"]+)"/);
    const getGender = attrs.match(/\bgender="([^"]+)"/);
    const getColor = attrs.match(/\bcolor="([^"]+)"/);
    if (getId && getName) {
      teachersMap.set(getId[1], {
        id: getId[1],
        name: getName[1],
        shortName: getShort ? getShort[1] : getName[1],
        gender: getGender ? getGender[1] : "M",
        color: getColor ? getColor[1] : "#669900",
      });
    }
  }

  // استخراج المواد
  const subjectRegex = /<subject\s+([^>]+)\/>/g;
  const subjectsMap = new Map<string, string>();
  while ((match = subjectRegex.exec(normalizedContent)) !== null) {
    const attrs = match[1];
    const getId = attrs.match(/\bid="([^"]+)"/);
    const getName = attrs.match(/\bname="([^"]+)"/);
    if (getId && getName) subjectsMap.set(getId[1], getName[1]);
  }

  // استخراج الفصول (يدعم <class> من aSc و<classroom> من وزارة التعليم)
  const classRegex = /<class\s+([^>]+)\/>/g;
  const classesMap = new Map<string, string>();
  while ((match = classRegex.exec(normalizedContent)) !== null) {
    const attrs = match[1];
    const getId = attrs.match(/\bid="([^"]+)"/);
    const getName = attrs.match(/\bname="([^"]+)"/);
    if (getId && getName) classesMap.set(getId[1], getName[1]);
  }
  // دعم <classroom> من ملفات وزارة التعليم العُمانية
  const classroomRegex = /<classroom\s+([^>]+)\/>/g;
  while ((match = classroomRegex.exec(normalizedContent)) !== null) {
    const attrs = match[1];
    const getId = attrs.match(/\bid="([^"]+)"/);
    const getName = attrs.match(/\bname="([^"]+)"/);
    if (getId && getName) classesMap.set(getId[1], getName[1]);
  }

  // استخراج الدروس - يدعم كلا الصيغتين: teacherids (جمع) و teacherid (مفرد)
  const lessonRegex = /<lesson\s+([^>]+)\/>/g;
  const lessonsMap = new Map<string, { teacherIds: string[]; subjectId: string; classIds: string[]; periodsPerWeek: number }>();
  while ((match = lessonRegex.exec(normalizedContent)) !== null) {
    const attrs = match[1];
    const getId = attrs.match(/\bid="([^"]+)"/);
    // دعم كلا الصيغتين: teacherids (aSc قديم) و teacherid (aSc جديد)
    const getTeachersPlural = attrs.match(/\bteacherids="([^"]+)"/i);
    const getTeacherSingular = attrs.match(/(?<![s])\bteacherid="([^"]+)"/i);
    const getSubject = attrs.match(/\bsubjectid="([^"]+)"/i);
    const getClasses = attrs.match(/\bclassids="([^"]+)"/i);
    const getPeriods = attrs.match(/\bperiodsperweek="([^"]+)"/i);

    const teacherIdsRaw = getTeachersPlural
      ? getTeachersPlural[1].split(",").filter(Boolean)
      : getTeacherSingular
      ? [getTeacherSingular[1]]
      : [];

    if (getId && teacherIdsRaw.length > 0 && getSubject) {
      lessonsMap.set(getId[1], {
        teacherIds: teacherIdsRaw,
        subjectId: getSubject[1],
        classIds: getClasses ? getClasses[1].split(",").filter(Boolean) : [],
        periodsPerWeek: getPeriods ? parseFloat(getPeriods[1]) : 0,
      });
    }
  }

  // استخراج البطاقات (cards) - الجدول الفعلي
  // يدعم كلا النمطين:
  //   1) النمط القديم: البطاقة تحتوي على lessonid فقط ويتم استخراج المعلم من الدرس
  //   2) النمط الجديد: البطاقة تحتوي على teacherid مباشرة في البطاقة
  const cardRegex = /<card\s+([^>]+)\/>/g;
  const scheduleEntries: Array<{
    teacherId: string;
    dayOfWeek: DayOfWeek;
    periodNumber: number;
    subjectName: string;
    className: string;
  }> = [];

  const dayMap: Record<string, DayOfWeek> = {
    "1": "Sunday",
    "2": "Monday",
    "3": "Tuesday",
    "4": "Wednesday",
    "5": "Thursday",
  };

  while ((match = cardRegex.exec(normalizedContent)) !== null) {
    const attrs = match[1];
    const getLessonId = attrs.match(/\blessonid="([^"]+)"/i);
    const getDay = attrs.match(/\bday="([^"]+)"/i);
    const getPeriod = attrs.match(/\bperiod="([^"]+)"/i);
    // استخراج teacherid مباشرة من البطاقة (النمط الجديد)
    const getCardTeacher = attrs.match(/(?<![s])\bteacherid="([^"]+)"/i);
    // استخراج subjectid و classids مباشرة من البطاقة (النمط الجديد)
    const getCardSubject = attrs.match(/\bsubjectid="([^"]+)"/i);
    const getCardClasses = attrs.match(/\bclassids="([^"]+)"/i);

    if (getDay && getPeriod) {
      const dayKey = getDay[1];
      const periodNum = parseInt(getPeriod[1]);

      if (dayMap[dayKey] && periodNum >= 1 && periodNum <= 8) {
        const dayOfWeek = dayMap[dayKey];

        if (getCardTeacher && getCardSubject) {
          // النمط الجديد: بيانات المعلم والمادة مباشرة في البطاقة
          const tid = getCardTeacher[1];
          const subjectName = subjectsMap.get(getCardSubject[1]) || "";
          const classIds = getCardClasses ? getCardClasses[1].split(",").filter(Boolean) : [];
          const className = classIds.map((cid) => classesMap.get(cid) || "").join(", ");

          if (teachersMap.has(tid)) {
            scheduleEntries.push({ teacherId: tid, dayOfWeek, periodNumber: periodNum, subjectName, className });
          }
        } else if (getLessonId) {
          // النمط القديم: استخراج بيانات المعلم من الدرس
          const lesson = lessonsMap.get(getLessonId[1]);
          if (lesson) {
            const subjectName = subjectsMap.get(lesson.subjectId) || "";
            const className = lesson.classIds.map((cid) => classesMap.get(cid) || "").join(", ");
            for (const tid of lesson.teacherIds) {
              if (teachersMap.has(tid)) {
                scheduleEntries.push({ teacherId: tid, dayOfWeek, periodNumber: periodNum, subjectName, className });
              }
            }
          }
        }
      }
    }
  }

  // =================== دعم صيغة TimeTableSchedule (وزارة التعليم العُمانية) ===================
  // هذه الصيغة تستخدم SubjectGradeID (= subject id) بدلاً من subjectid
  // وتستخدم DayID وPeriod بدلاً من day وperiod
  const ttsRegex = /<TimeTableSchedule\s+([^>]+)\/>/g;
  const dayMapTTS: Record<string, DayOfWeek> = {
    "1": "Sunday",
    "2": "Monday",
    "3": "Tuesday",
    "4": "Wednesday",
    "5": "Thursday",
  };
  while ((match = ttsRegex.exec(normalizedContent)) !== null) {
    const attrs = match[1];
    const getDayId = attrs.match(/\bDayID="([^"]+)"/i);
    const getPeriod = attrs.match(/\bPeriod="([^"]+)"/i);
    const getTeacherId = attrs.match(/\bTeacherID="([^"]+)"/i);
    const getSubjectGradeId = attrs.match(/\bSubjectGradeID="([^"]+)"/i);
    const getClassId = attrs.match(/\bClassID="([^"]+)"/i);
    if (getDayId && getPeriod && getTeacherId) {
      const dayKey = getDayId[1];
      const periodNum = parseInt(getPeriod[1]);
      const tid = getTeacherId[1];
      if (dayMapTTS[dayKey] && periodNum >= 1 && periodNum <= 8 && teachersMap.has(tid)) {
        const dayOfWeek = dayMapTTS[dayKey];
        const subjectName = getSubjectGradeId ? (subjectsMap.get(getSubjectGradeId[1]) || "") : "";
        const classId = getClassId ? getClassId[1] : "";
        const className = classId ? (classesMap.get(classId) || "") : "";
        // تجنب التكرار: نفس المعلم + نفس اليوم + نفس الحصة
        const duplicate = scheduleEntries.some(
          (e) => e.teacherId === tid && e.dayOfWeek === dayOfWeek && e.periodNumber === periodNum
        );
        if (!duplicate) {
          scheduleEntries.push({ teacherId: tid, dayOfWeek, periodNumber: periodNum, subjectName, className });
        }
      }
    }
  }

  // احتساب النصاب الأسبوعي لكل معلم
  const weeklyLoadMap = new Map<string, number>();
  for (const entry of scheduleEntries) {
    weeklyLoadMap.set(entry.teacherId, (weeklyLoadMap.get(entry.teacherId) || 0) + 1);
  }

  return { teachersMap, scheduleEntries, weeklyLoadMap };
}

// =================== SPECIALTY GROUPS ===================
// تجميع التخصصات المتقاربة في مجموعات
const SPECIALTY_GROUPS: Record<string, string> = {
  // العلوم (تشمل الكيمياء والفيزياء والأحياء)
  'علوم': 'علوم',
  'كيمياء': 'علوم',
  'فيزياء': 'علوم',
  'أحياء': 'علوم',
  'العلوم': 'علوم',
  'الكيمياء': 'علوم',
  'الفيزياء': 'علوم',
  'الأحياء': 'علوم',
  // الدراسات الاجتماعية
  'دراسات اجتماعية': 'دراسات',
  'الدراسات الاجتماعية': 'دراسات',
  'الدراسات': 'دراسات',
  // اللغة العربية
  'لغة عربية': 'عربية',
  'اللغة العربية': 'عربية',
  'عربي': 'عربية',
  // اللغة الإنجليزية
  'لغة إنجليزية': 'إنجليزية',
  'اللغة الإنجليزية': 'إنجليزية',
  'إنجليزي': 'إنجليزية',
  // المهارات الفردية: تقنية + حياتية + رياضة + موسيقى + فنون (يتبادلون الاحتياط)
  'مهارات موسيقية': 'مهارات_فردية',
  'المهارات الموسيقية': 'مهارات_فردية',
  'الفنون الموسيقية': 'مهارات_فردية',
  'فنون موسيقية': 'مهارات_فردية',
  'موسيقى': 'مهارات_فردية',
  'مهارات حياتية': 'مهارات_فردية',
  'المهارات الحياتية': 'مهارات_فردية',
  'حياتية': 'مهارات_فردية',
  'رياضة مدرسية': 'مهارات_فردية',
  'الرياضة المدرسية': 'مهارات_فردية',
  'رياضة': 'مهارات_فردية',
  'تربية بدنية': 'مهارات_فردية',
  'التربية البدنية': 'مهارات_فردية',
  'التربية البدنية والصحية': 'مهارات_فردية',
  'تقنية المعلومات': 'مهارات_فردية',
  'تقنية': 'مهارات_فردية',
  'حاسوب': 'مهارات_فردية',
  'فنون تشكيلية': 'مهارات_فردية',
  'الفنون التشكيلية': 'مهارات_فردية',
  'الفنون البصرية': 'مهارات_فردية',
  'فنون بصرية': 'مهارات_فردية',
  'فنون': 'مهارات_فردية',
  'فن': 'مهارات_فردية',
  // الرياضيات (مستقلة)
  'رياضيات': 'رياضيات',
  'الرياضيات': 'رياضيات',
  // التربية الإسلامية
  'تربية إسلامية': 'إسلامية',
  'التربية الإسلامية': 'إسلامية',
  'إسلامية': 'إسلامية',
};

// دالة للحصول على مجموعة التخصص من اسم المادة
function getSpecialtyGroup(subjectName: string): string | null {
  if (!subjectName) return null;
  const normalized = subjectName.trim();
  // بحث مباشر
  if (SPECIALTY_GROUPS[normalized]) return SPECIALTY_GROUPS[normalized];
  // بحث جزئي
  for (const [key, group] of Object.entries(SPECIALTY_GROUPS)) {
    if (normalized.includes(key) || key.includes(normalized)) return group;
  }
  return null;
}

// =================== HARD BLOCK TEACHERS ===================
// معلمون محظورون كلياً من الاختيار الآلي (استثناء دائم كلي)
// لا يُختارون حتى لو كانوا البديل الوحيد في التخصص
const HARD_BLOCK_TEACHERS = new Set<number>([
  60002, // حمد عبدالله محمد الحوسنى - استثناء دائم كلي
]);

// =================== INDIVIDUAL SKILLS TEACHERS ===================
// معلمو المهارات الفردية (تقنية + حياتية + رياضة + موسيقى + فنون)
// أولويتهم: تغطية بعضهم البعض فقط
// لا يُكلَّفون بمواد أساسية إلا عند تعذر وجود أي معلم أساسي آخر
const INDIVIDUAL_SKILLS_TEACHER_IDS = new Set<number>([
  60062, // سامى على حمدان الحجرى
  60063, // سعود سالم موسى الشبلي - تقنية معلومات / مهارات فردية
  60064, // ايمن ثابت حمود السعدي
  60065, // خالد الكلباني
  60066, // الوليد عوض مرهون الريامي
  60067, // عوف عبدالله مصبح المعمري
  60068, // راشد سالم سعيد ال فنه العريمي
  60069, // عبدالوهاب سعيد محمد حميد الشكيلي (مهارات فردية - تخصصه في DB خاطئ)
  60070, // ابراهيم ابراهيم السيد محمد
  60071, // أحمد عبدالمجيد عبدالفتاح عبدالمجيد
  60072, // سليمان محمد محمد سالم
]);

// المواد الأساسية (لا يُكلَّف بها معلمو المهارات إلا كملاذ أخير)
const CORE_SUBJECT_GROUPS = new Set<string>([
  'إسلامية', 'عربية', 'إنجليزية', 'رياضيات', 'علوم', 'دراسات',
]);

// =================== LAST RESORT TEACHERS ===================
// المعلمون الأوائل الذين يُعاملون كخيار أخير فقط مع حدود خاصة
const LAST_RESORT_TEACHERS: Record<number, { maxWeekly: number }> = {
  60034: { maxWeekly: 5 }, // جبر ناصر خميس السعدى - حد أقصى 5 أسبوعياً
  60046: { maxWeekly: 2 }, // إبراهيم سعيد درويش أولادثاني - حد أقصى 2 أسبوعياً
};

// =================== normalizeClassName ===================
// إصلاح أسماء الفصول لمعلمي تقنية المعلومات:
// عندما يكون className يحتوي على "بوساح" (= حاسوب مقلوب) أو "حاسوب"
// نستخرج اسم الصف الحقيقي من subjectName (الجزء بعد "تقنية المعلومات")
// مثال: subjectName="تقنية المعلومات أساسي/5", className="2 بوساح الخامس"
//   → نُرجع "الخامس أساسي/5"
function normalizeClassName(className: string, subjectName: string): string {
  if (!className) return className;
  const cn = className.trim();
  // تحقق من وجود نمط المختبر (حاسوب 1/2 أو بوساح 1/2)
  const isLabPattern = /بوساح|حاسوب/i.test(cn);
  if (!isLabPattern) return cn;
  // استخراج اسم الصف من subjectName
  // النمط: "تقنية المعلومات أساسي/5" → نستخرج "أساسي/5"
  // أو نستخرج الصف من className نفسه
  const subj = (subjectName || "").trim();
  // محاولة 1: استخراج من subjectName مثل "تقنية المعلومات أساسي/5"
  const subjMatch = subj.match(/(?:تقنية المعلومات|تقنية|حاسوب)\s+(.*)/i);
  if (subjMatch && subjMatch[1]) {
    const suffix = subjMatch[1].trim(); // مثل "أساسي/5"
    // استخراج اسم الصف من className: "2 بوساح الخامس" → "الخامس"
    const classMatch = cn.match(/(الخامس|السادس|السابع|الثامن|التاسع|الرابع|الثالث|الثاني|الأول)/i);
    if (classMatch) {
      return `${classMatch[1]} ${suffix}`;
    }
    return suffix;
  }
  // محاولة 2: استخراج اسم الصف من className فقط
  const classMatch2 = cn.match(/(الخامس|السادس|السابع|الثامن|التاسع|الرابع|الثالث|الثاني|الأول)\s*(أساسي)?\s*\/?\s*(\d+)?/i);
  if (classMatch2) {
    const grade = classMatch2[1];
    const div = classMatch2[3] ? `/${classMatch2[3]}` : "";
    return `${grade} أساسي${div}`;
  }
  return cn;
}

// حساب بداية ونهاية الأسبوع (الأحد - الخميس) لتاريخ معين
function getWeekRange(dateStr: string): { weekStart: string; weekEnd: string } {
  const date = new Date(dateStr);
  const day = date.getDay(); // 0=Sunday, 1=Monday, ..., 6=Saturday
  // الأسبوع الدراسي: الأحد (0) إلى الخميس (4)
  const daysFromSunday = day === 0 ? 0 : day <= 4 ? day : day - 7;
  const sunday = new Date(date);
  sunday.setDate(date.getDate() - daysFromSunday);
  const thursday = new Date(sunday);
  thursday.setDate(sunday.getDate() + 4);
  const fmt = (d: Date) => d.toISOString().split('T')[0];
  return { weekStart: fmt(sunday), weekEnd: fmt(thursday) };
}

// =================== DISTRIBUTION ALGORITHM ===================
// =================== PERIOD SCHEDULE (Oman school day) ===================
// الحصة 1: 07:15-08:00 | 2: 08:00-08:45 | 3: 08:45-09:30 | 4: 09:30-10:15
// 5: 10:30-11:15 | 6: 11:15-12:00 | 7: 12:00-12:45 | 8: 12:45-13:30
const PERIOD_START_MINUTES: Record<number, number> = {
  1: 7 * 60 + 15,
  2: 8 * 60,
  3: 8 * 60 + 45,
  4: 9 * 60 + 30,
  5: 10 * 60 + 30,
  6: 11 * 60 + 15,
  7: 12 * 60,
  8: 12 * 60 + 45,
};

/** الحصص التي انتهى وقتها بالنسبة للوقت الحالي (Oman UTC+4) */
function getExpiredPeriods(nowUtcMs?: number): Set<number> {
  const now = nowUtcMs ? new Date(nowUtcMs) : new Date();
  // عمان UTC+4
  const omanMinutes = (now.getUTCHours() + 4) * 60 + now.getUTCMinutes();
  const expired = new Set<number>();
  for (const [p, startMin] of Object.entries(PERIOD_START_MINUTES)) {
    if (omanMinutes >= startMin) expired.add(Number(p));
  }
  return expired;
}

async function distributeSubstitutes(
  absentTeacherIds: number[],
  absenceDate: string,
  dayOfWeek: DayOfWeek,
  skipExpiredPeriods: boolean = false,
  nowUtcMs?: number,
  // غياب جزئي: Map<teacherId, number[]> تحدد الحصص المغيبة فقط (null/undefined = غياب كامل)
  partialPeriodsMap?: Map<number, number[]>,
  distributionMode: 'general' | 'specialty' = 'general',
): Promise<Array<{
  absentTeacherId: number;
  substituteTeacherId: number;
  periodNumber: number;
  subjectName: string;
  className: string;
  isSpecialtyMatch: boolean;
  constraintBreakLevel: number;
  constraintBreakReason: string | null;
}>> {
  const allTeachers = await getAllTeachers();
  // تحميل مجموعات التخصص ديناميكياً من قاعدة البيانات (مع fallback للثوابت الصلبة)
  let dynamicGroups: Record<string, string> = {};
  let dynamicCoreGroups: Set<string> = new Set();
  try {
    const dbResult = await buildSpecialtyGroupsFromDB();
    if (Object.keys(dbResult.groups).length > 0) {
      dynamicGroups = dbResult.groups;
      dynamicCoreGroups = dbResult.coreGroups;
    }
  } catch { /* استخدام الثوابت الصلبة كـ fallback */ }
  // دالة محلية تستخدم البيانات الديناميكية أولاً ثم الثوابت الصلبة
  const resolveSpecialtyGroup = (subjectName: string): string | null => {
    if (!subjectName) return null;
    const normalized = subjectName.trim();
    if (Object.keys(dynamicGroups).length > 0) {
      if (dynamicGroups[normalized]) return dynamicGroups[normalized];
      for (const [key, group] of Object.entries(dynamicGroups)) {
        if (normalized.includes(key) || key.includes(normalized)) return group;
      }
    }
    return getSpecialtyGroup(subjectName);
  };
  const resolveCoreGroup = (group: string): boolean => {
    if (dynamicCoreGroups.size > 0) return dynamicCoreGroups.has(group);
    return CORE_SUBJECT_GROUPS.has(group);
  };
  const exemptions = await getExemptionsByDate(absenceDate);
  const exemptedIds = new Set([
    ...absentTeacherIds,
    ...exemptions.map((e) => e.teacherId),
  ]);

  // تحميل الاستثناءات الجزئية لجميع المعلمين
  const allPartialExemptions = await getAllPartialExemptions();
  const partialExemptionMap = new Map<number, { exemptDays: string[]; exemptPeriods: number[] }>();
  for (const pe of allPartialExemptions) {
    try {
      const days: string[] = JSON.parse(pe.exemptDays || '[]');
      const periods: number[] = JSON.parse(pe.exemptPeriods || '[]');
      partialExemptionMap.set(pe.teacherId, { exemptDays: days, exemptPeriods: periods });
    } catch {
      // تجاهل الأخطاء في تحليل JSON
    }
  }

  // دالة للتحقق من الاستثناء الجزئي لمعلم في يوم وحصة معينة
  const isPartiallyExempt = (teacherId: number, day: string, period: number): boolean => {
    const pe = partialExemptionMap.get(teacherId);
    if (!pe) return false;
    if (!pe.exemptDays.includes(day)) return false;
    // إذا كانت exemptPeriods فارغة → مستثنى من كل الحصص في هذا اليوم
    if (pe.exemptPeriods.length === 0) return true;
    // وإلا → مستثنى فقط من الحصص المحددة
    return pe.exemptPeriods.includes(period);
  };

  // المعلمون المتاحون للاحتياط:
  // - غير الغائبين
  // - غير المستثنين يومياً
  // - غير المستثنين دائماً (isExemptFromSubstitute)
  // - غير المحظورين كلياً (HARD_BLOCK_TEACHERS) ← أعلى سلطة
  const availableTeachers = allTeachers.filter(
    (t) => !exemptedIds.has(t.id) && !t.isExemptFromSubstitute && !HARD_BLOCK_TEACHERS.has(t.id)
  );

  // تحميل جداول جميع المعلمين المتاحين لهذا اليوم مرة واحدة
  const teacherDayScheduleMap = new Map<number, Set<number>>();
  for (const teacher of availableTeachers) {
    const schedule = await getTeacherSchedule(teacher.id);
    const busyPeriods = new Set(
      schedule
        .filter((s) => s.dayOfWeek === dayOfWeek)
        .map((s) => s.periodNumber)
    );
    teacherDayScheduleMap.set(teacher.id, busyPeriods);
  }

  // =================== احتساب الأسبوع الحالي ===================
  const { weekStart, weekEnd } = getWeekRange(absenceDate);

  // احتساب عدد حصص الاحتياط لكل معلم في الأسبوع الحالي (للحد الأقصى 4 حصص)
  const weekCounts = await getSubstituteCountByWeek(weekStart, weekEnd);
  const weekCountMap = new Map<number, number>();
  for (const wc of weekCounts) {
    weekCountMap.set(wc.substituteTeacherId, Number(wc.totalCount));
  }

  // احتساب عدد حصص الاحتياط لكل معلم في الشهر الحالي (للترتيب)
  const now = new Date(absenceDate);
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const monthCounts = await getSubstituteCountByMonth(year, month);
  const monthCountMap = new Map<number, number>();
  for (const mc of monthCounts) {
    monthCountMap.set(mc.substituteTeacherId, Number(mc.totalCount));
  }

  // =================== الرصيد التراكمي (Cumulative) ===================
  // جلب الرصيد التراكمي لكل معلم (لا يُصفّر أسبوعياً)
  const cumulativeCounts = await getTotalSubstituteCountCumulative();
  const cumulativeMap = new Map<number, number>();
  for (const cc of cumulativeCounts) {
    cumulativeMap.set(cc.id, Number(cc.totalAssignmentsCumulative || 0));
  }

  // =================== عداد الجولة (roundAssignmentsCount) ===================
  // الأولوية الأولى في العدالة التراكمية: الأقل عدداً في الجولة الحالية يأتي أولاً
  const roundCounts = await getRoundAssignmentsCounts();
  const roundCountMap = new Map<number, number>();
  for (const rc of roundCounts) {
    roundCountMap.set(rc.id, Number(rc.roundAssignmentsCount || 0));
  }

  // =================== مبدأ التدوير ===================
  // جلب تواريخ الاحتياط لكل معلم في الأسبوع الحالي لمعرفة من أخذ احتياطاً أمس
  const yesterday = new Date(absenceDate);
  yesterday.setDate(yesterday.getDate() - 1);
  // تخطي عطلة نهاية الأسبوع (الجمعة والسبت)
  if (yesterday.getDay() === 6) yesterday.setDate(yesterday.getDate() - 1); // السبت → الخميس
  if (yesterday.getDay() === 5) yesterday.setDate(yesterday.getDate() - 1); // الجمعة → الخميس
  const yesterdayStr = yesterday.toISOString().split('T')[0];
  const yesterdayAssignments = await getAssignmentsByDate(yesterdayStr);
  // من أخذ احتياطاً أمس يُستثنى اليوم قدر الإمكان (مبدأ التدوير)
  const hadSubstituteYesterday = new Set<number>(yesterdayAssignments.map(a => a.substituteTeacherId));

  // =================== نظام الدورة الأولى/الثانية ===================
  // جلب قائمة المعلمين الذين أخذوا حصة في الدورة الحالية
  const tookInCurrentRound = await getTeachersWhoTookInCurrentRound();
  // المعلمون المؤهلون (غير مستثنين وغير محظورين)
  const eligibleIds = availableTeachers.map(t => t.id);
  // هل اكتملت الدورة الأولى؟ (جميع المؤهلين أخذوا حصة)
  const allTookRound1 = eligibleIds.length > 0 && eligibleIds.every(id => tookInCurrentRound.has(id));
  // إذا اكتملت الدورة → نبدأ دورة جديدة
  let currentRoundTook = tookInCurrentRound;
  if (allTookRound1) {
    // احتساب رقم الدورة الجديدة
    const allStates = await getAllRotationStates();
    const maxRound = allStates.length > 0 ? Math.max(...allStates.map(s => s.roundNumber || 1)) : 1;
    await resetRotationRound(maxRound + 1);
    currentRoundTook = new Set<number>(); // الدورة الجديدة فارغة
  }

  // احتساب حصص الاحتياط المُعطاة اليوم بالفعل (من سجلات اليوم السابقة)
  const todayAssignments = await getAssignmentsByDate(absenceDate);
  const todayAssignedSet = new Set<number>();
  const todaySubstitutePeriods = new Map<number, Set<number>>();
  for (const ta of todayAssignments) {
    todayAssignedSet.add(ta.substituteTeacherId);
    if (!todaySubstitutePeriods.has(ta.substituteTeacherId)) {
      todaySubstitutePeriods.set(ta.substituteTeacherId, new Set());
    }
    todaySubstitutePeriods.get(ta.substituteTeacherId)!.add(ta.periodNumber);
  }

  // الحصص المنتهية (للتوزيع الزمني)
  const expiredPeriods: Set<number> = skipExpiredPeriods ? getExpiredPeriods(nowUtcMs) : new Set();

  const assignments: Array<{
    absentTeacherId: number;
    substituteTeacherId: number;
    periodNumber: number;
    subjectName: string;
    className: string;
    isSpecialtyMatch: boolean;
    constraintBreakLevel: number;
    constraintBreakReason: string | null;
  }> = [];

  // تتبع التعيينات في هذه الجلسة
  const sessionAssignedSet = new Set<number>(todayAssignedSet);
  const sessionSubstitutePeriods = new Map<number, Set<number>>(todaySubstitutePeriods);
  // تتبع عدد الاحتياطات الأسبوعية في الجلسة الحالية
  const sessionWeekCountMap = new Map<number, number>(weekCountMap);
  // تتبع الرصيد التراكمي في الجلسة الحالية
  const sessionCumulativeMap = new Map<number, number>(cumulativeMap);
  // تتبع عداد الجولة في الجلسة الحالية
  const sessionRoundCountMap = new Map<number, number>(roundCountMap);

  // =================== دالة التحقق من الاستثناء الجزئي ===================
  const isAdjacentToBasic = (teacherId: number, pNum: number): boolean => {
    const basicBusy = teacherDayScheduleMap.get(teacherId);
    if (!basicBusy) return false;
    // للحصتين 7 و8 (آخر حصتين في اليوم): لا يوجد حصص بعدهما
    // لذا نتحقق فقط من الحصة السابقة (pNum - 1) لتجنب الفراغ قبل الحصة
    if (pNum >= 7) return basicBusy.has(pNum - 1);
    // للحصص الأخرى: نتحقق من الحصة السابقة والحصة اللاحقة
    return basicBusy.has(pNum - 1) || basicBusy.has(pNum + 1);
  };

  // =================== دالة التخصص ===================
  const teacherSpecialtyGroupMap = new Map<number, string | null>();
  const getTeacherSpecialtyGroup = async (t: typeof availableTeachers[0]): Promise<string | null> => {
    if (teacherSpecialtyGroupMap.has(t.id)) return teacherSpecialtyGroupMap.get(t.id)!;
    const sp = (t as any).specialty as string | null;
    if (sp) {
      const g = SPECIALTY_GROUPS[sp] || sp;
      teacherSpecialtyGroupMap.set(t.id, g);
      return g;
    }
    const sch = await getTeacherSchedule(t.id);
    const subjects = sch.map(s => s.subjectName || "").filter(Boolean).filter((v, i, a) => a.indexOf(v) === i);
    const groups = subjects.map(getSpecialtyGroup).filter(Boolean) as string[];
    const g = groups.length > 0 ? groups[0] : null;
    teacherSpecialtyGroupMap.set(t.id, g);
    return g;
  };

  // =================== دالة الفلتر الأساسي ===================
  // تتحقق من: لا تعارض أساسي + لا تعارض احتياط متزامن + لا استثناء جزئي
  const baseFilter = (t: typeof availableTeachers[0], periodNum: number) => {
    if (isPartiallyExempt(t.id, dayOfWeek, periodNum)) return false;
    const basicBusy = teacherDayScheduleMap.get(t.id);
    if (basicBusy && basicBusy.has(periodNum)) return false;
    const subBusy = sessionSubstitutePeriods.get(t.id);
    if (subBusy && subBusy.has(periodNum)) return false;
    return true;
  };

  // =================== دالة اختيار المرشح الأفضل ===================
  // تسلسل الأولويات (من الأعلى للأدنى):
  // 1. الحظر الدائم (HARD_BLOCK) - مُطبَّق قبل الوصول لهذه الدالة
  // 2. سقف النصاب 22 حصة (weeklyLoad >= 22 → مستثنى)
  // 3. مطابقة التخصص
  // 4. مبدأ التدوير (لم يأخذ أمس)
  // 5. أقل نصاب أسبوعي
  // 6. أقل حصص احتياط شهرياً
  const selectBest = async (
    pool: typeof availableTeachers,
    absentGroup: string | null,
    periodNum: number,
    allowLastResort: boolean,
    allowIndividualSkills: boolean,
    absentClassName: string = ""
  ): Promise<{ teacher: typeof availableTeachers[0]; specialtyGroup: string | null } | null> => {
    if (pool.length === 0) return null;

    const withSpecialty = await Promise.all(
      pool.map(async (t) => {
        // معلمو المهارات الفردية: نعاملهم كمجموعة مهارات_فردية بغض النظر عن تخصصهم في DB
        let sg: string | null;
        if (INDIVIDUAL_SKILLS_TEACHER_IDS.has(t.id)) {
          sg = 'مهارات_فردية';
        } else {
          sg = await getTeacherSpecialtyGroup(t);
        }
        return { teacher: t, specialtyGroup: sg };
      })
    );

    // فصل المعلمين حسب الفئة:
    // 1. المعلمون الأوائل (Last Resort)
    // 2. معلمو المهارات الفردية
    // 3. المعلمون العاديون
    const lastResortCandidates = withSpecialty.filter(c => c.teacher.id in LAST_RESORT_TEACHERS);
    const skillsCandidates = withSpecialty.filter(
      c => INDIVIDUAL_SKILLS_TEACHER_IDS.has(c.teacher.id) && !(c.teacher.id in LAST_RESORT_TEACHERS)
    );
    const normalCandidates = withSpecialty.filter(
      c => !INDIVIDUAL_SKILLS_TEACHER_IDS.has(c.teacher.id) && !(c.teacher.id in LAST_RESORT_TEACHERS)
    );

    // دالة الترتيب الداخلي - نظام العدالة التراكمية
    // القاعدة: roundAssignmentsCount ASC ثم totalAssignmentsCumulative ASC ثم weekly_load ASC
    const sortFn = (a: typeof withSpecialty[0], b: typeof withSpecialty[0]) => {
      // حساب نقاط الأولوية لكل مرشح
      let aScore = 0;
      let bScore = 0;

      // أولوية 0: تطابق التخصص (+150 نقطة)
      if (absentGroup && a.specialtyGroup === absentGroup) aScore += 150;
      if (absentGroup && b.specialtyGroup === absentGroup) bScore += 150;

      // أولوية 1: تطابق الصف (Class Match) (+250 نقطة)
      if ((a.teacher as any)._classesSet && (a.teacher as any)._classesSet.has(absentClassName)) aScore += 250;
      if ((b.teacher as any)._classesSet && (b.teacher as any)._classesSet.has(absentClassName)) bScore += 250;

      // إذا كانت النقاط مختلفة نرتب تنازلياً (الأعلى أولاً)
      if (bScore !== aScore) return bScore - aScore;

      // === العدالة التراكمية: الأولوية الحقيقية ===
      // أولوية 2 (عداد الجولة): الأقل حصصاً في الجولة الحالية يأتي أولاً
      // يمنع تكرار اختيار نفس المعلم لمجرد تطابق التخصص
      const aRound = (sessionRoundCountMap.get(a.teacher.id) ?? roundCountMap.get(a.teacher.id)) || 0;
      const bRound = (sessionRoundCountMap.get(b.teacher.id) ?? roundCountMap.get(b.teacher.id)) || 0;
      if (aRound !== bRound) return aRound - bRound;

      // أولوية 3 (الرصيد التراكمي): الأقل رصيداً تراكمياً يأتي أولاً
      const aCumulative = (sessionCumulativeMap.get(a.teacher.id) ?? cumulativeMap.get(a.teacher.id)) || 0;
      const bCumulative = (sessionCumulativeMap.get(b.teacher.id) ?? cumulativeMap.get(b.teacher.id)) || 0;
      if (aCumulative !== bCumulative) return aCumulative - bCumulative;

      // أولوية 4 (نظام الدورة): لم يأخذ حصة في الدورة الحالية بعد
      const aTookRound = currentRoundTook.has(a.teacher.id) ? 1 : 0;
      const bTookRound = currentRoundTook.has(b.teacher.id) ? 1 : 0;
      if (aTookRound !== bTookRound) return aTookRound - bTookRound;

      // أولوية 4: لم يأخذ احتياطاً أمس (مبدأ التدوير اليومي)
      const aYest = hadSubstituteYesterday.has(a.teacher.id) ? 1 : 0;
      const bYest = hadSubstituteYesterday.has(b.teacher.id) ? 1 : 0;
      if (aYest !== bYest) return aYest - bYest;

      // أولوية 5: أقل نصاب أسبوعي (النصاب الأساسي)
      const aWeekly = a.teacher.weeklyLoad || 0;
      const bWeekly = b.teacher.weeklyLoad || 0;
      if (aWeekly !== bWeekly) return aWeekly - bWeekly;

      // أولوية 6: أقل حصص احتياط في الشهر
      const aMonth = monthCountMap.get(a.teacher.id) || 0;
      const bMonth = monthCountMap.get(b.teacher.id) || 0;
      if (aMonth !== bMonth) return aMonth - bMonth;

      // أولوية 7: عشوائية منضبطة (Fair Randomness) - عند تساوي الرصيد التراكمي
      return Math.random() - 0.5;
    };

    // =================== تسلسل الاختيار ===================
    // المرحلة أ: المعلمون العاديون (غير مهارات فردية وغير أوائل)
    // سقف النصاب 22 حصة: حظر صارم - لا يُختار من وصل لـ 22+ إلا في حالة طوارئ كاملة
    const normalWithinLoad = normalCandidates.filter(
      c => (c.teacher.weeklyLoad || 0) < 22
    );
    if (normalWithinLoad.length > 0) {
      const sorted = [...normalWithinLoad].sort(sortFn);
      return sorted[0];
    }

    // المرحلة ب: معلمو المهارات الفردية (ضمن سقف 22 أيضاً)
    // - إذا كانت المادة الغائبة من مهارات_فردية: يُختارون بأولوية عادية
    // - إذا كانت المادة الغائبة أساسية: يُختارون فقط إذا لم يوجد أي معلم عادي ضمن الحد (allowIndividualSkills)
    const isAbsentGroupCore = absentGroup ? resolveCoreGroup(absentGroup) : false;
    const skillsWithinLoad = skillsCandidates.filter(
      c => (c.teacher.weeklyLoad || 0) < 22
    );
    if (skillsWithinLoad.length > 0) {
      if (!isAbsentGroupCore || allowIndividualSkills) {
        const sorted = [...skillsWithinLoad].sort(sortFn);
        return sorted[0];
      }
    }

    // المرحلة ج: المعلمون الأوائل (Last Resort)
    if (allowLastResort && lastResortCandidates.length > 0) {
      const sorted = [...lastResortCandidates].sort(sortFn);
      return sorted[0];
    }

    // المرحلة د (طوارئ كاملة): المعلمون العاديون الذين تجاوزوا سقف 22
    // لا يُستخدم إلا عند استنفاد جميع الخيارات الأخرى
    if (normalCandidates.length > 0) {
      const sorted = [...normalCandidates].sort(sortFn);
      return sorted[0];
    }

    // المرحلة هـ (طوارئ كاملة): معلمو المهارات الذين تجاوزوا سقف 22
    if (skillsCandidates.length > 0 && (!isAbsentGroupCore || allowIndividualSkills)) {
      const sorted = [...skillsCandidates].sort(sortFn);
      return sorted[0];
    }

    return null;
  };

  // =================== حلقة التوزيع الرئيسية ===================
  for (const absentId of absentTeacherIds) {
    const schedule = await getTeacherSchedule(absentId);
    const daySchedule = schedule
      .filter((s) => s.dayOfWeek === dayOfWeek)
      .sort((a, b) => a.periodNumber - b.periodNumber);
    console.log(`[DEBUG distribute] absentId=${absentId} dayOfWeek="${dayOfWeek}" scheduleTotal=${schedule.length} daySchedule=${daySchedule.length} partialAllowed=${JSON.stringify(partialPeriodsMap?.get(absentId))}`);

    for (const period of daySchedule) {
      const periodNum = period.periodNumber;

      // =================== غياب جزئي: تجاوز الحصص غير المحددة ===================
      if (partialPeriodsMap) {
        const allowedPeriods = partialPeriodsMap.get(absentId);
        // إذا كان المعلم لديه غياب جزئي وهذه الحصة ليست ضمن الحصص المحددة → تجاوزها
        if (allowedPeriods && !allowedPeriods.includes(periodNum)) continue;
      }

      // =================== إدراك الوقت: تجاوز الحصص المنتهية ===================
      if (skipExpiredPeriods && expiredPeriods.has(periodNum)) continue;

      const absentSubject = period.subjectName || "";
      const absentGroup = resolveSpecialtyGroup(absentSubject);

      // =================== نظام كسر القيود المتدرج ===================
      // المستوى 0 (عادي): جميع القيود مطبقة
      // المستوى 1: كسر قاعدة الفجوة (isAdjacentToBasic)
      // المستوى 2: رفع سقف الاحتياط الأسبوعي من 4 إلى 5
      // المستوى 3: رفع سقف النصاب الكلي من 22 إلى 25
      // المستوى 4: الاستعانة بالمعلمين الأوائل
      // المستوى 5: المستثنىن الدائمون (سوفت)

      // دوال مساعدة لكسر القيود
      const withinWeeklyLimit = (t: typeof availableTeachers[0], maxOverride?: number) => {
        const weekCount = sessionWeekCountMap.get(t.id) || 0;
        // السقف الفردي: individual_cap لكل معلم (افتراضي: 4) أو maxWeekly للمعلمين الأوائل
        const cap = (t as any).individualCap ?? 4;
        const maxAllowed = maxOverride ?? (LAST_RESORT_TEACHERS[t.id]?.maxWeekly ?? cap);
        return weekCount < maxAllowed;
      };
      const withinTotalLoad = (t: typeof availableTeachers[0], maxLoad: number) => {
        return (t.weeklyLoad || 0) < maxLoad;
      };

      // المستثنىن الدائمون (سوفت): معلمون لديهم isExemptFromSubstitute ولكن لم يتم إضافتهم لـ HARD_BLOCK
      // هؤلاء تم حذفهم من availableTeachers. نحتاج لإعادة تحميلهم في المستوى 5
      const softExemptTeachers = allTeachers.filter(
        (t) => !exemptedIds.has(t.id) && t.isExemptFromSubstitute && !HARD_BLOCK_TEACHERS.has(t.id)
      );

      let candidatePool: typeof availableTeachers = [];
      let breakLevel = 0;
      let breakReason: string | null = null;

      // --- حماية النصاب الكامل (The 22 Rule) + سقف المعلم الأول ---
      const withinTotalLoadForLevel = (t: typeof availableTeachers[0], constraintLvl: number) => {
        // المعلم الأول (Subject Head): سقف خاص = 2 حصة احتياط فقط
        if ((t as any).teacherRole === 'subject_head') {
          const cumCount = sessionCumulativeMap.get(t.id) || 0;
          const weekCount = sessionWeekCountMap.get(t.id) || 0;
          if (weekCount >= 2) return false; // سقف أسبوعي 2
        }
        // حماية النصاب الكامل 22: استبعاد إلا في constraintLevel >= 3
        if ((t.weeklyLoad || 0) >= 22 && constraintLvl < 3) return false;
        return true;
      };

      // --- المستوى 0: جميع القيود مطبقة ---
      // مرحلة 1: لا تعارض + لم يُكلَّف اليوم + ليست ملاصقة + ضمن الحد الأسبوعي + حماية 22
      candidatePool = availableTeachers.filter((t) => {
        if (!baseFilter(t, periodNum)) return false;
        if (!withinWeeklyLimit(t)) return false;
        if (!withinTotalLoadForLevel(t, 0)) return false;
        if (sessionAssignedSet.has(t.id)) return false;
        if (isAdjacentToBasic(t.id, periodNum)) return false;
        return true;
      });
      if (candidatePool.length === 0) {
        // مرحلة 2: تخلَّ عن شرط الملاصقة مع الحفاظ على تفضيل من لم يُكلَّف اليوم
        candidatePool = availableTeachers.filter((t) => {
          if (!baseFilter(t, periodNum)) return false;
          if (!withinWeeklyLimit(t)) return false;
          if (!withinTotalLoadForLevel(t, 0)) return false;
          if (sessionAssignedSet.has(t.id)) return false;
          return true;
        });
      }
      if (candidatePool.length === 0) {
        // مرحلة 3: تخلَّ عن شرط عدم التكليف اليومي مع تجنب الملاصقة
        candidatePool = availableTeachers.filter((t) => {
          if (!baseFilter(t, periodNum)) return false;
          if (!withinWeeklyLimit(t)) return false;
          if (!withinTotalLoadForLevel(t, 0)) return false;
          if (isAdjacentToBasic(t.id, periodNum)) return false;
          return true;
        });
      }
      if (candidatePool.length === 0) {
        // مرحلة 4: تخلَّ عن الملاصقة وشرط عدم التكليف اليومي (ضمن الحد الأسبوعي + حماية 22)
        candidatePool = availableTeachers.filter((t) => {
          if (!baseFilter(t, periodNum)) return false;
          if (!withinWeeklyLimit(t)) return false;
          if (!withinTotalLoadForLevel(t, 0)) return false;
          return true;
        });
      }

      // --- المستوى 1: كسر قاعدة الفجوة ---
      // السماح بالتكليف بين حصتين أساسيتين (isAdjacentToBasic متجاهلة)
      if (candidatePool.length === 0) {
        breakLevel = 1;
        breakReason = "تم كسر قاعدة الفجوة لعدم توفر بديل مناسب";
        candidatePool = availableTeachers.filter((t) => {
          if (!baseFilter(t, periodNum)) return false;
          if (!withinWeeklyLimit(t)) return false;
          if (!withinTotalLoadForLevel(t, 1)) return false;
          return true; // كسر الفجوة
        });
      }

      // --- المستوى 2: رفع سقف الاحتياط الأسبوعي بمقدار +1 فوق السقف الفردي ---
      if (candidatePool.length === 0) {
        breakLevel = 2;
        breakReason = "تم رفع سقف الاحتياط الأسبوعي بمقدار حصة إضافية";
        candidatePool = availableTeachers.filter((t) => {
          if (!baseFilter(t, periodNum)) return false;
          if (!withinTotalLoadForLevel(t, 2)) return false;
          // رفع السقف بمقدار +1 فوق السقف الفردي
          const cap = (t as any).individualCap ?? 4;
          const weekCount = sessionWeekCountMap.get(t.id) || 0;
          if (weekCount >= cap + 1) return false;
          return true;
        });
      }

      // --- المستوى 3: رفع سقف النصاب الكلي من 22 إلى 25 (يُفتح حماية 22) ---
      if (candidatePool.length === 0) {
        breakLevel = 3;
        breakReason = "تم رفع سقف النصاب الكلي من 22 إلى 25 حصة";
        candidatePool = availableTeachers.filter((t) => {
          if (!baseFilter(t, periodNum)) return false;
          // constraintLevel 3 يفتح حماية 22
          if (!withinTotalLoadForLevel(t, 3)) return false;
          // استخدام السقف الفردي +1 أيضاً في هذا المستوى
          const cap = (t as any).individualCap ?? 4;
          const weekCount = sessionWeekCountMap.get(t.id) || 0;
          if (weekCount >= cap + 1) return false;
          return withinTotalLoad(t, 25); // رفع سقف النصاب لـ 25
        });
      }

      // --- المستوى 4: الاستعانة بالمعلمين الأوائل ---
      if (candidatePool.length === 0) {
        breakLevel = 4;
        breakReason = "تم الاستعانة بالمعلمين الأوائل (جبر ناصر / إبراهيم سعيد)";
        // تحميل جميع المعلمين الأوائل المتاحين (غير غائبين وغير محظورين كلياً)
        const lastResortAvailable = allTeachers.filter(
          (t) => (t.id in LAST_RESORT_TEACHERS) && !exemptedIds.has(t.id) && !HARD_BLOCK_TEACHERS.has(t.id)
        );
        candidatePool = lastResortAvailable.filter((t) => {
          if (isPartiallyExempt(t.id, dayOfWeek, periodNum)) return false;
          const basicBusy = teacherDayScheduleMap.get(t.id);
          if (basicBusy && basicBusy.has(periodNum)) return false;
          const subBusy = sessionSubstitutePeriods.get(t.id);
          if (subBusy && subBusy.has(periodNum)) return false;
          return true;
        });
      }

      // --- المستوى 5: المستثنىن الدائمون (سوفت) ---
      if (candidatePool.length === 0) {
        breakLevel = 5;
        breakReason = "تم اللجوء للمستثنى بشكل دائم بعد استنفاد جميع الخيارات";
        candidatePool = softExemptTeachers.filter((t) => {
          if (isPartiallyExempt(t.id, dayOfWeek, periodNum)) return false;
          const basicBusy = teacherDayScheduleMap.get(t.id);
          if (basicBusy && basicBusy.has(periodNum)) return false;
          const subBusy = sessionSubstitutePeriods.get(t.id);
          if (subBusy && subBusy.has(periodNum)) return false;
          return true;
        });
        // تحميل جدول المستثنى الدائم إذا لم يكن محملاً بعد
        for (const t of candidatePool) {
          if (!teacherDayScheduleMap.has(t.id)) {
            const sch = await getTeacherSchedule(t.id);
            const busy = new Set(sch.filter(s => s.dayOfWeek === dayOfWeek).map(s => s.periodNumber));
            teacherDayScheduleMap.set(t.id, busy);
          }
        }
      }

      // --- المستوى 6: أي معلم فارغ في الحصة له صلة بالصف (نفس المرحلة الدراسية) ---
      // يتجاوز التخصص والعبء ويبحث عن معلم فارغ في الحصة يدرس نفس المرحلة
      if (candidatePool.length === 0) {
        breakLevel = 6;
        breakReason = "تم كسر قيد التخصص - اختيار معلم فارغ من نفس المرحلة الدراسية";
        // استخراج المرحلة من className الغائب
        const absentClassNorm = (period.className || "").trim();
        const gradeMatch = absentClassNorm.match(/(\u0627\u0644\u062e\u0627\u0645\u0633|\u0627\u0644\u0633\u0627\u062f\u0633|\u0627\u0644\u0633\u0627\u0628\u0639|\u0627\u0644\u062b\u0627\u0645\u0646|\u0627\u0644\u062a\u0627\u0633\u0639|\u0627\u0644\u0631\u0627\u0628\u0639|\u0627\u0644\u062b\u0627\u0644\u062b|\u0627\u0644\u062b\u0627\u0646\u064a|\u0627\u0644\u0623\u0648\u0644)/i);
        const absentGrade = gradeMatch ? gradeMatch[1] : null;
        // جميع المعلمين غير المحظورين كلياً (HARD_BLOCK) + غير الغائبين
        const allNonBlocked6 = allTeachers.filter(
          t => !HARD_BLOCK_TEACHERS.has(t.id) && !exemptedIds.has(t.id)
        );
        // تحميل جداول من لم يتم تحميلها بعد
        for (const t of allNonBlocked6) {
          if (!teacherDayScheduleMap.has(t.id)) {
            const sch = await getTeacherSchedule(t.id);
            const busy = new Set(sch.filter(s => s.dayOfWeek === dayOfWeek).map(s => s.periodNumber));
            teacherDayScheduleMap.set(t.id, busy);
          }
        }
        // جلب الجداول الكاملة لتحديد صلة المعلم بالصف
        const teacherFullScheduleMap = new Map<number, Array<{dayOfWeek: string; className: string | null; subjectName: string | null}>>();
        for (const t of allNonBlocked6) {
          if (!(t as any)._fullSchedule) {
            const sch = await getTeacherSchedule(t.id);
            (t as any)._fullSchedule = sch;
            teacherFullScheduleMap.set(t.id, sch);
          } else {
            teacherFullScheduleMap.set(t.id, (t as any)._fullSchedule);
          }
        }
        candidatePool = allNonBlocked6.filter(t => {
          // لا تعارض في الحصة (أساسي أو احتياط)
          const basicBusy = teacherDayScheduleMap.get(t.id);
          if (basicBusy && basicBusy.has(periodNum)) return false;
          const subBusy = sessionSubstitutePeriods.get(t.id);
          if (subBusy && subBusy.has(periodNum)) return false;
          // له صلة بالصف (نفس المرحلة الدراسية)
          if (absentGrade) {
            const tFullSch = teacherFullScheduleMap.get(t.id) || [];
            return tFullSch.some(s => {
              const cn = (s.className ?? "").trim();
              return new RegExp(absentGrade, 'i').test(cn);
            });
          }
          return true;
        });
      }

      // --- المستوى 7: أي معلم فارغ في الحصة مطلقاً (أقل تراكمي) - الشرط: لا تعارض في الحصة ---
      if (candidatePool.length === 0) {
        breakLevel = 7;
        breakReason = "تم كسر جميع القيود - اختيار أي معلم فارغ في الحصة (أقل تراكمي)";
        const allNonBlocked7 = allTeachers.filter(
          t => !HARD_BLOCK_TEACHERS.has(t.id) && !exemptedIds.has(t.id)
        );
        for (const t of allNonBlocked7) {
          if (!teacherDayScheduleMap.has(t.id)) {
            const sch = await getTeacherSchedule(t.id);
            const busy = new Set(sch.filter(s => s.dayOfWeek === dayOfWeek).map(s => s.periodNumber));
            teacherDayScheduleMap.set(t.id, busy);
          }
        }
        candidatePool = allNonBlocked7.filter(t => {
          const basicBusy = teacherDayScheduleMap.get(t.id);
          if (basicBusy && basicBusy.has(periodNum)) return false;
          const subBusy = sessionSubstitutePeriods.get(t.id);
          if (subBusy && subBusy.has(periodNum)) return false;
          return true;
        });
      }

      if (candidatePool.length === 0) continue; // لا يوجد بديل متاح بأي حال

      // =================== اختيار الأفضل ===================
      const isEmergencyPhase = breakLevel >= 2; // مستوى 2+ = طوارئ
      const hasNonSkillsInPool = candidatePool.some(
        t => !INDIVIDUAL_SKILLS_TEACHER_IDS.has(t.id) && !(t.id in LAST_RESORT_TEACHERS)
      );
      const allowIndividualSkillsForCore = !hasNonSkillsInPool;

      // بناء classesSet لكل معلم في المجموعة (لأولوية تطابق الصف)
      const absentClassNameNorm = normalizeClassName(period.className || "", period.subjectName || "");
      for (const t of candidatePool) {
        if (!(t as any)._classesSet) {
          const tSch = await getTeacherSchedule(t.id);
          const classNames = new Set(
            tSch
              .filter(s => s.dayOfWeek === dayOfWeek)
              .map(s => normalizeClassName(s.className || "", s.subjectName || ""))
              .filter(Boolean)
          );
          (t as any)._classesSet = classNames;
        }
      }

      const chosen = await selectBest(candidatePool, absentGroup, periodNum, isEmergencyPhase, allowIndividualSkillsForCore, absentClassNameNorm);
      if (!chosen) continue;

      const isSpecialtyMatch = !!(absentGroup && chosen.specialtyGroup === absentGroup);

      assignments.push({
        absentTeacherId: absentId,
        substituteTeacherId: chosen.teacher.id,
        periodNumber: periodNum,
        subjectName: period.subjectName || "",
        className: normalizeClassName(period.className || "", period.subjectName || ""),
        isSpecialtyMatch,
        constraintBreakLevel: breakLevel,
        constraintBreakReason: breakLevel > 0 ? breakReason : null,
      });

      // تحديث العدادات
      monthCountMap.set(chosen.teacher.id, (monthCountMap.get(chosen.teacher.id) || 0) + 1);
      sessionWeekCountMap.set(chosen.teacher.id, (sessionWeekCountMap.get(chosen.teacher.id) || 0) + 1);
      // تحديث عداد الجولة (الأولوية الأولى في العدالة التراكمية)
      sessionRoundCountMap.set(chosen.teacher.id, (sessionRoundCountMap.get(chosen.teacher.id) || 0) + 1);
      await incrementRoundCount(chosen.teacher.id);
      // تحديث الرصيد التراكمي (في الجلسة + قاعدة البيانات)
      sessionCumulativeMap.set(chosen.teacher.id, (sessionCumulativeMap.get(chosen.teacher.id) || 0) + 1);
      await incrementCumulativeCount(chosen.teacher.id);
      sessionAssignedSet.add(chosen.teacher.id);
      // تسجيل المعلم في نظام الدورة (يأخذ حصة في الدورة الحالية)
      if (!currentRoundTook.has(chosen.teacher.id)) {
        currentRoundTook.add(chosen.teacher.id);
        await markTeacherTookSubstitute(chosen.teacher.id, absenceDate);
      }
      if (!sessionSubstitutePeriods.has(chosen.teacher.id)) {
        sessionSubstitutePeriods.set(chosen.teacher.id, new Set());
      }
      sessionSubstitutePeriods.get(chosen.teacher.id)!.add(periodNum);
    }
  }

  return assignments;
}

// =================== ROUTER ===================
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // =================== TEACHERS ===================
  teachers: router({
    list: publicProcedure.query(async () => {
      return getAllTeachers();
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getTeacherById(input.id);
      }),

    add: publicProcedure
      .input(
        z.object({
          name: z.string().min(1),
          shortName: z.string().optional(),
          gender: z.enum(["M", "F"]).optional(),
          weeklyLoad: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await insertTeacher({
          name: input.name,
          shortName: input.shortName,
          gender: input.gender || "M",
          weeklyLoad: input.weeklyLoad || 0,
          isActive: true,
        });
        return { success: true };
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().min(1).optional(),
          shortName: z.string().optional(),
          weeklyLoad: z.number().optional(),
          monthlyCapacity: z.number().optional(),
          individualCap: z.number().min(1).max(20).optional(),
          isExemptFromSubstitute: z.boolean().optional(),
          specialty: z.string().nullable().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await updateTeacher(id, data as any);
        return { success: true };
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteTeacher(input.id);
        return { success: true };
      }),

    getSchedule: publicProcedure
      .input(z.object({ teacherId: z.number() }))
      .query(async ({ input }) => {
        return getTeacherSchedule(input.teacherId);
      }),

    getScheduleByDay: publicProcedure
      .input(z.object({ teacherId: z.number(), dayOfWeek: z.string() }))
      .query(async ({ input }) => {
        const schedule = await getTeacherSchedule(input.teacherId);
        return schedule.filter((s) => s.dayOfWeek === input.dayOfWeek)
          .sort((a, b) => a.periodNumber - b.periodNumber);
      }),

    // =================== PARTIAL EXEMPTIONS ===================
    getPartialExemptions: publicProcedure.query(async () => {
      return getAllPartialExemptions();
    }),

    getPartialExemptionByTeacher: publicProcedure
      .input(z.object({ teacherId: z.number() }))
      .query(async ({ input }) => {
        return getPartialExemptionByTeacher(input.teacherId);
      }),

    setPartialExemption: publicProcedure
      .input(
        z.object({
          teacherId: z.number(),
          exemptDays: z.array(z.enum(["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"])),
          exemptPeriods: z.array(z.number().min(1).max(8)),
          reason: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await upsertPartialExemption({
          teacherId: input.teacherId,
          exemptDays: JSON.stringify(input.exemptDays),
          exemptPeriods: JSON.stringify(input.exemptPeriods),
          reason: input.reason,
        });
        return { success: true };
      }),

    removePartialExemption: publicProcedure
      .input(z.object({ teacherId: z.number() }))
      .mutation(async ({ input }) => {
        await deletePartialExemption(input.teacherId);
        return { success: true };
      }),

    // =================== SCHEDULE CRUD (يدوي) ===================
    getScheduleGrid: publicProcedure
      .input(z.object({ teacherId: z.number() }))
      .query(async ({ input }) => {
        return getTeacherScheduleGrid(input.teacherId);
      }),

    addScheduleEntry: publicProcedure
      .input(z.object({
        teacherId: z.number(),
        dayOfWeek: z.enum(["Sunday","Monday","Tuesday","Wednesday","Thursday"]),
        periodNumber: z.number().min(1).max(8),
        subjectName: z.string().optional(),
        className: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const newId = await insertSingleScheduleEntry(input);
        return { success: true, id: newId };
      }),

    updateScheduleEntry: publicProcedure
      .input(z.object({
        id: z.number(),
        subjectName: z.string().optional(),
        className: z.string().optional(),
        dayOfWeek: z.enum(["Sunday","Monday","Tuesday","Wednesday","Thursday"]).optional(),
        periodNumber: z.number().min(1).max(8).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...update } = input;
        await updateSingleScheduleEntry(id, update);
        return { success: true };
      }),

    deleteScheduleEntry: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteSingleScheduleEntry(input.id);
        return { success: true };
      }),

    // رفع ملف XML
    importXml: publicProcedure
      .input(z.object({ xmlContent: z.string() }))
      .mutation(async ({ input }) => {
        const { teachersMap, scheduleEntries, weeklyLoadMap } = parseXmlTeachersAndSchedule(
          input.xmlContent
        );

        // مسح الجداول القديمة
        await clearAllSchedules();

        let importedCount = 0;
        const teacherIdMap = new Map<string, number>();

        for (const [extId, teacher] of Array.from(teachersMap.entries())) {
          const weeklyLoad = weeklyLoadMap.get(extId) || 0;
          const dbId = await upsertTeacherByExternalId({
            externalId: extId,
            name: teacher.name,
            shortName: teacher.shortName,
            gender: teacher.gender as "M" | "F",
            weeklyLoad,
            color: teacher.color,
            isActive: true,
          });
          if (dbId) {
            teacherIdMap.set(extId, dbId);
            importedCount++;
          }
        }

        // إدخال الجداول
        const scheduleToInsert = scheduleEntries
          .map((entry) => {
            const dbTeacherId = teacherIdMap.get(entry.teacherId);
            if (!dbTeacherId) return null;
            return {
              teacherId: dbTeacherId,
              dayOfWeek: entry.dayOfWeek,
              periodNumber: entry.periodNumber,
              subjectName: entry.subjectName,
              className: entry.className,
            };
          })
          .filter(Boolean) as any[];

        if (scheduleToInsert.length > 0) {
          await insertScheduleEntries(scheduleToInsert);
        }

        return {
          success: true,
          teachersImported: importedCount,
          scheduleEntriesImported: scheduleToInsert.length,
        };
      }),
    // رفع ملف PDF جدول المعلمين
      // الخطوة 1أ: فتح PDF وإرجاع عدد الصفحات (سريع جداً)
    importPdfInit: publicProcedure
      .input(z.object({
        pdfBase64: z.string(),
        clearOld: z.boolean().default(true), // محجوظ للتوافق الخلفي - التعطيل يتم بعد اكتمال الاستيراد
      }))
      .mutation(async ({ input }) => {
        const mupdf = await import("mupdf");
        const pdfBuffer = Buffer.from(input.pdfBase64, "base64");
        const doc = mupdf.default.Document.openDocument(pdfBuffer, "application/pdf");
        const pageCount = doc.countPages();
        // ملاحظة: لا نحذف هنا - سيتم تعطيل المعلمين الغير موجودين بعد اكتمال الاستيراد
        return { success: true, pageCount };
      }),

    // الخطوة 1ب: تحويل صفحة واحدة إلى PNG (طلب مستقل لكل صفحة)
    importPdfConvertPage: publicProcedure
      .input(z.object({
        pdfBase64: z.string(),
        pageIndex: z.number(),
      }))
      .mutation(async ({ input }) => {
        const mupdf = await import("mupdf");
        const pdfBuffer = Buffer.from(input.pdfBase64, "base64");
        const doc = mupdf.default.Document.openDocument(pdfBuffer, "application/pdf");
        const page = doc.loadPage(input.pageIndex);
        const pixmap = page.toPixmap(
          mupdf.default.Matrix.scale(1.5, 1.5),
          mupdf.default.ColorSpace.DeviceRGB,
          false,
          true
        );
        const pngBytes = pixmap.asPNG();
        return {
          success: true,
          pageIndex: input.pageIndex,
          imageBase64: Buffer.from(pngBytes).toString("base64"),
        };
      }),

    // للتوافق الخلفي - لا يُستخدم
    importPdfConvert: publicProcedure
      .input(z.object({ pdfBase64: z.string(), clearOld: z.boolean().default(true) }))
      .mutation(async () => {
        return { success: false, message: "استخدم importPdfInit + importPdfConvertPage + importPdfPage" };
      }),

    // الخطوة 2: تحليل صفحة واحدة بـ LLM وحفظها (يُستدعى لكل صفحة على حدة)
    importPdfPage: publicProcedure
      .input(z.object({
        pageImageBase64: z.string(), // PNG base64 بدون data URL prefix
        pageIndex: z.number(),
      }))
      .mutation(async ({ input }) => {
        const { invokeLLM } = await import("./_core/llm");

        const arabicDayMap: Record<string, DayOfWeek> = {
          "الأحد": "Sunday", "الاحد": "Sunday",
          "الاثنين": "Monday", "الأثنين": "Monday", "الإثنين": "Monday",
          "الثلاثاء": "Tuesday",
          "الأربعاء": "Wednesday", "الاربعاء": "Wednesday",
          "الخميس": "Thursday",
        };
        const arabicToWestern = (s: string) =>
          s.replace(/[٠١٢٣٤٥٦٧٨٩]/g, (d: string) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));

        const dataUrl = `data:image/png;base64,${input.pageImageBase64}`;
        try {
          const result = await invokeLLM({
            messages: [
              {
                role: "user",
                content: [
                  { type: "image_url", image_url: { url: dataUrl, detail: "high" } } as any,
                  {
                    type: "text",
                    text: `أنت نظام استخراج بيانات متخصص في جداول المعلمين العُمانية. مهمتك استخراج بيانات الجدول بدقة 100% وإرجاع JSON فقط.

## بنية الجدول (مهم جداً):
الجدول عربي يُقرأ من اليمين لليسار. ترتيب الأعمدة من اليمين:
- العمود الأول (أقصى اليمين): اسم اليوم
- ثم بالترتيب: ح1، ح2، ح3، ح4، فسحة (9:25-9:40)، ح5، ح6، ح7، ح8

## كيف تحدد رقم الحصة:
انظر للرقم في رأس العمود (الصف الأول). الأرقام هي: 1، 2، 3، 4، فسحة، 5، 6، 7، 8.
عمود "فسحة" لا تُدرج منه أي شيء إطلاقاً.

## محتوى الخلية المملوءة:
كل خلية مملوءة = حصة واحدة فقط تحتوي على:
- السطر الأول: اسم الفصل (مثال: التاسع أساسي/1)
- السطر الثاني: اسم المادة (مثال: اللغة العربية)
هذان السطران = حصة واحدة، لا تعدّهما حصتين.

## الخلايا الفارغة:
تحتوي على "—" أو فارغة. لا تُدرجها إطلاقاً.

## قواعد صارمة:
1. اسم المعلم: العنوان الكبير في أعلى الصفحة
2. الأيام: الأحد، الاثنين، الثلاثاء، الأربعاء، الخميس فقط
3. حوّل الأرقام العربية (١٢٣٤٥٦٧٨٩) إلى غربية (123456789)
4. إذا خلية تحتوي على فصلين = سجلان منفصلان بنفس اليوم والحصة
5. لا تُكرر حصة موجودة
6. لا تخترع حصصاً غير موجودة في الصورة

## المخرج (JSON فقط بدون أي نص إضافي):
{"teacherName":"الاسم الكامل","schedule":[{"day":"الأحد","period":1,"className":"التاسع أساسي/1","subject":"اللغة العربية"}]}\``
                  }
                ]
              }
            ],
            response_format: { type: "json_object" }
          });
          const content = result.choices[0].message.content;
          const parsed = JSON.parse(typeof content === "string" ? content : JSON.stringify(content));

          if (!parsed.teacherName || !Array.isArray(parsed.schedule)) {
            return { success: false, skipped: true, pageIndex: input.pageIndex };
          }

          // حفظ المعلم وجدوله في قاعدة البيانات
          const dbId = await upsertTeacherByExternalId({
            externalId: `pdf-${parsed.teacherName.replace(/\s+/g, '-')}`,
            name: parsed.teacherName,
            shortName: parsed.teacherName.split(' ').slice(0, 2).join(' '),
            gender: "M" as const,
            weeklyLoad: parsed.schedule.length,
            color: `#${Math.floor(Math.random()*0xFFFFFF).toString(16).padStart(6,'0')}`,
            isActive: true,
          });
          if (!dbId) return { success: false, skipped: true, pageIndex: input.pageIndex };

          // تنظيف وتحقق من الحصص المستخرجة
          const seenSlots = new Set<string>();
          const entries = (parsed.schedule as Array<{ day: string; period: number | string; className: string; subject: string }>)
            .map(s => {
              const dayEn = arabicDayMap[s.day];
              if (!dayEn) return null;
              const periodNum = parseInt(arabicToWestern(String(s.period)));
              if (isNaN(periodNum) || periodNum < 1 || periodNum > 8) return null;
              // تجاهل الفسحة إذا أرجعها LLM بشكل خاطئ
              if (periodNum === 0) return null;
              // إزالة التكرارات (نفس اليوم + نفس الحصة + نفس الفصل)
              const slotKey = `${dayEn}-${periodNum}-${s.className}`;
              if (seenSlots.has(slotKey)) return null;
              seenSlots.add(slotKey);
              return {
                teacherId: dbId,
                dayOfWeek: dayEn,
                periodNumber: periodNum,
                subjectName: s.subject || "غير محدد",
                className: arabicToWestern(s.className || ""),
              };
            })
            .filter((e): e is NonNullable<typeof e> => e !== null);

          if (entries.length > 0) {
            await insertScheduleEntries(entries);
          }

          return {
            success: true,
            skipped: false,
            pageIndex: input.pageIndex,
            teacherName: parsed.teacherName,
            entriesCount: entries.length,
          };
        } catch {
          return { success: false, skipped: true, pageIndex: input.pageIndex };
        }
      }),

    // الإجراء القديم (للتوافق الخلفي - يُستخدم الآن فقط للملفات الصغيرة)
    importPdf: publicProcedure
      .input(z.object({
        pdfBase64: z.string(),
        clearOld: z.boolean().default(true),
      }))
      .mutation(async ({ input }) => {
        // يُعيد توجيه للإجراء الجديد - لا يُستخدم مباشرة
        return { success: false, message: "استخدم importPdfConvert + importPdfPage بدلاً من هذا" };
      }),
    // حذف جميع المعلمين نهائياً (لبداية سنة دراسية جديدة)
    deleteAllTeachers: protectedProcedure
      .mutation(async () => {
        await deleteAllTeachersAndData();
        return { success: true };
      }),
    // الخطوة النهائية: تعطيل المعلمين الغير موجودين في الجدول الجديد (يحافظ على الاستثناءات)
    importPdfFinalize: publicProcedure
      .input(z.object({
        importedTeacherNames: z.array(z.string()), // أسماء المعلمين المستوردين فعلاً
        clearOld: z.boolean().default(true),
      }))
      .mutation(async ({ input }) => {
        if (input.clearOld && input.importedTeacherNames.length > 0) {
          await deactivateTeachersNotInList(input.importedTeacherNames);
        }
        return { success: true, deactivated: true };
      }),
    getAvailableForPeriod: publicProcedure
      .input(z.object({
        dayOfWeek: z.enum(["Sunday","Monday","Tuesday","Wednesday","Thursday"]),
        periodNumber: z.number().min(1).max(8),
        date: z.string(),
        excludeTeacherIds: z.array(z.number()).optional(),
        absentTeacherId: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return getAvailableTeachersForPeriod(
          input.dayOfWeek,
          input.periodNumber,
          input.date,
          input.excludeTeacherIds || [],
          input.absentTeacherId
        );
      }),
  }),
  // =================== ABSENCES ====================
  absences: router({
    getByDate: publicProcedure
      .input(z.object({ date: z.string() }))
      .query(async ({ input }) => {
        const records = await getAbsencesByDate(input.date);
        const result = [];
        for (const r of records) {
          const teacher = await getTeacherById(r.teacherId);
          const assignments = await getAssignmentsByAbsenceRecord(r.id);
          result.push({ ...r, teacher, assignments });
        }
        return result;
      }),

    getByMonth: publicProcedure
      .input(z.object({ year: z.number(), month: z.number() }))
      .query(async ({ input }) => {
        const records = await getAbsencesByMonth(input.year, input.month);
        const result = [];
        for (const r of records) {
          const teacher = await getTeacherById(r.teacherId);
          const assignments = await getAssignmentsByAbsenceRecord(r.id);
          result.push({ ...r, teacher, assignments });
        }
        return result;
      }),

    register: publicProcedure
      .input(
        z.object({
          teacherIds: z.array(z.number()).min(1),
          date: z.string(),
          dayOfWeek: z.enum(["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"]),
          reason: z.string().optional(),
          skipExpiredPeriods: z.boolean().optional().default(false), // تجاوز الحصص المنتهية (للغياب في منتصف اليوم)
          nowUtcMs: z.number().optional(), // وقت التسجيل بالمليثانية (UTC) لحساب الحصص المنتهية
          // غياب جزئي: مصفوفة من { teacherId, periods[] } تحدد الحصص المغيبة فقط لكل معلم
          // إذا لم يذكر معلم هنا = غياب كامل
          partialAbsences: z.array(z.object({
            teacherId: z.number(),
            periods: z.array(z.number().min(1).max(8)),
          })).optional(),
          distributionMode: z.enum(["general", "specialty"]).optional().default("general"), // وضع التوزيع: عام أو تخصصي
        })
      )
      .mutation(async ({ input }) => {
        // بناء Map الغياب الجزئي من المدخل
        const partialPeriodsMap = input.partialAbsences && input.partialAbsences.length > 0
          ? new Map(input.partialAbsences.map(pa => [pa.teacherId, pa.periods]))
          : undefined;

        // الخطوة 1: جلب جميع الغائبين السابقين في نفس اليوم من قاعدة البيانات
        const existingAbsences = await getAbsencesByDate(input.date);
        const existingAbsentIds = existingAbsences.map((a) => a.teacherId);

        // الخطوة 2: تسجيل غياب المعلمين الجدد أولاً (مع حفظ partialPeriods)
        const absenceIdMap = new Map<number, number>(); // teacherId -> absenceId
        for (const teacherId of input.teacherIds) {
          const partialPeriods = partialPeriodsMap?.get(teacherId);
          const absenceId = await insertAbsenceRecord({
            teacherId,
            absenceDate: input.date as any,
            reason: input.reason,
            partialPeriods: partialPeriods ? JSON.stringify(partialPeriods) : undefined,
          });
          absenceIdMap.set(teacherId, absenceId);
        }

        // الخطوة 3: بناء قائمة شاملة بجميع الغائبين في اليوم (السابقين + الجدد)
        const combinedSet = new Set<number>(existingAbsentIds);
        for (const id of input.teacherIds) combinedSet.add(id);
        const allAbsentIds = Array.from(combinedSet);

        // بناء partialPeriodsMap شامل يجمع الغياب الجزئي الجديد مع السابق من قاعدة البيانات
        const fullPartialMap = new Map<number, number[]>();
        // أضف الغياب الجزئي السابق من قاعدة البيانات
        for (const ea of existingAbsences) {
          if (ea.partialPeriods) {
            try {
              const pp: number[] = JSON.parse(ea.partialPeriods);
              if (pp.length > 0) fullPartialMap.set(ea.teacherId, pp);
            } catch { /* ignore */ }
          }
        }
        // أضف الغياب الجزئي الجديد
        if (partialPeriodsMap) {
          Array.from(partialPeriodsMap.entries()).forEach(([tid, periods]) => {
            if (periods.length > 0) fullPartialMap.set(tid, periods);
          });
        }

        // الخطوة 4: توزيع الاحتياط لجميع الغائبين الجدد مع استبعاد الكل
        const allAssignments = await distributeSubstitutes(
          allAbsentIds,
          input.date,
          input.dayOfWeek,
          input.skipExpiredPeriods ?? false,
          input.nowUtcMs,
          fullPartialMap.size > 0 ? fullPartialMap : undefined,
          input.distributionMode ?? "general"
        );

        // الخطوة 5: حفظ التوزيعات للمعلمين الجدد فقط
        const results = [];
        for (const teacherId of input.teacherIds) {
          const absenceId = absenceIdMap.get(teacherId)!;
          const teacherAssignments = allAssignments.filter(
            (a) => a.absentTeacherId === teacherId
          );

          if (teacherAssignments.length > 0) {
            await insertSubstituteAssignments(
              teacherAssignments.map((a) => ({
                absenceRecordId: absenceId,
                absentTeacherId: a.absentTeacherId,
                substituteTeacherId: a.substituteTeacherId,
                assignmentDate: input.date as any,
                periodNumber: a.periodNumber,
                dayOfWeek: input.dayOfWeek,
                subjectName: a.subjectName,
                className: a.className,
                isSpecialtyMatch: a.isSpecialtyMatch,
                constraintBreakLevel: a.constraintBreakLevel,
                constraintBreakReason: a.constraintBreakReason ?? undefined,
              }))
            );
          }

          results.push({ teacherId, absenceId, assignmentsCount: teacherAssignments.length });
        }
        return { success: true, results };
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteAssignmentsByAbsenceRecord(input.id);
        await deleteAbsenceRecord(input.id);
        return { success: true };
      }),
    // =================== توزيع يدوي إلزامي ===================
    manualAssign: publicProcedure
      .input(z.object({
        absenceRecordId: z.number(),
        absentTeacherId: z.number(),
        substituteTeacherId: z.number(),
        periodNumber: z.number().min(1).max(8),
        date: z.string(),
        dayOfWeek: z.enum(["Sunday","Monday","Tuesday","Wednesday","Thursday"]),
        subjectName: z.string().optional(),
        className: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const subTeacher = await getTeacherById(input.substituteTeacherId);
        if (!subTeacher) throw new Error("المعلم البديل غير موجود");
        // جلب بيانات الحصة من جدول المعلم الغائب إذا لم تُرسل
        let subjectName = input.subjectName;
        let className = input.className;
        if (!subjectName || !className) {
          const schedule = await getTeacherSchedule(input.absentTeacherId);
          const periodEntry = schedule.find(
            s => s.dayOfWeek === input.dayOfWeek && s.periodNumber === input.periodNumber
          );
          if (periodEntry) {
            subjectName = subjectName || periodEntry.subjectName || "";
            className = className || periodEntry.className || "";
          }
        }
        // حذف التوزيع القديم لنفس الحصة في نفس سجل الغياب إن وجد
        const existingAssignments = await getAssignmentsByAbsenceRecord(input.absenceRecordId);
        const duplicate = existingAssignments.find(a => a.periodNumber === input.periodNumber);
        if (duplicate) {
          await deleteAssignmentsByAbsenceRecord(0); // placeholder
          const db2 = await import("./db").then(m => m.getDb());
          if (db2) {
            const { substituteAssignments: saTable } = await import("../drizzle/schema");
            const { eq: eqOp } = await import("drizzle-orm");
            await db2.delete(saTable).where(eqOp(saTable.id, duplicate.id));
          }
        }
        // التحقق من تعارض المعلم البديل في نفس الحصة (تحذير فقط)
        const allAssignmentsToday = await getAssignmentsByDate(input.date);
        const hasConflict = allAssignmentsToday.some(
          a => a.substituteTeacherId === input.substituteTeacherId &&
               a.periodNumber === input.periodNumber &&
               a.absenceRecordId !== input.absenceRecordId
        );
        // حفظ التوزيع اليدوي الإلزامي
        await insertSubstituteAssignments([{
          absenceRecordId: input.absenceRecordId,
          absentTeacherId: input.absentTeacherId,
          substituteTeacherId: input.substituteTeacherId,
          assignmentDate: input.date as any,
          periodNumber: input.periodNumber,
          dayOfWeek: input.dayOfWeek,
          subjectName: subjectName || "",
          className: className || "",
          isSpecialtyMatch: false,
          constraintBreakLevel: 99,
          constraintBreakReason: "توزيع يدوي إلزامي من الإدارة",
        }]);
        try { await incrementRoundCount(input.substituteTeacherId); } catch {}
        try { await incrementCumulativeCount(input.substituteTeacherId); } catch {}
        return { success: true, hasConflict, subjectName, className };
      }),
    deleteAssignment: publicProcedure
      .input(z.object({ assignmentId: z.number() }))
      .mutation(async ({ input }) => {
        const db3 = await import("./db").then(m => m.getDb());
        if (!db3) throw new Error("DB not available");
        const { substituteAssignments: saTable2 } = await import("../drizzle/schema");
        const { eq: eqOp2 } = await import("drizzle-orm");
        await db3.delete(saTable2).where(eqOp2(saTable2.id, input.assignmentId));
        return { success: true };
      }),
  }),
  // =================== EXEMPTIONS ====================
  exemptions: router({
    getByDate: publicProcedure
      .input(z.object({ date: z.string() }))
      .query(async ({ input }) => {
        const exemptions = await getExemptionsByDate(input.date);
        const result = [];
        for (const e of exemptions) {
          const teacher = await getTeacherById(e.teacherId);
          result.push({ ...e, teacher });
        }
        return result;
      }),

    add: publicProcedure
      .input(
        z.object({
          teacherId: z.number(),
          date: z.string(),
          reason: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await insertDailyExemption({
          teacherId: input.teacherId,
          exemptionDate: input.date as any,
          reason: input.reason,
        });
        return { success: true };
      }),

    remove: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteExemption(input.id);
        return { success: true };
      }),

    removeByTeacherAndDate: publicProcedure
      .input(z.object({ teacherId: z.number(), date: z.string() }))
      .mutation(async ({ input }) => {
        await deleteExemptionByTeacherAndDate(input.teacherId, input.date);
        return { success: true };
      }),
  }),

  // =================== STATISTICS ===================
  stats: router({
    weeklyStats: publicProcedure
      .query(async () => {
        // حساب بداية الأسبوع الحالي (الأحد)
        const now = new Date();
        const dayOfWeek = now.getDay(); // 0=الأحد
        const sunday = new Date(now);
        sunday.setDate(now.getDate() - dayOfWeek);
        const thursday = new Date(sunday);
        thursday.setDate(sunday.getDate() + 4);
        const weekStart = sunday.toISOString().split('T')[0];
        const weekEnd = thursday.toISOString().split('T')[0];
        const allTeachers = await getAllTeachers();
        const weeklyCounts = await getSubstituteCountByWeek(weekStart, weekEnd);
        const countMap = new Map(weeklyCounts.map((c) => [c.substituteTeacherId, Number(c.totalCount)]));
        // تحديد الحد الأقصى لكل معلم
        const JABR_ID = 60034;
        const IBRAHIM_ID = 60046;
        return allTeachers.map((t) => {
          const weeklyCount = countMap.get(t.id) || 0;
          const maxAllowed = t.id === JABR_ID ? 5 : t.id === IBRAHIM_ID ? 2 : 4;
          return {
            teacherId: t.id,
            teacherName: t.name,
            weeklyCount,
            maxAllowed,
            weekStart,
            weekEnd,
          };
        });
      }),
    monthly: publicProcedure
      .input(z.object({ year: z.number(), month: z.number() }))
      .query(async ({ input }) => {
        const allTeachers = await getAllTeachers();
        const counts = await getSubstituteCountByMonth(input.year, input.month);
        const countMap = new Map(counts.map((c) => [c.substituteTeacherId, Number(c.totalCount)]));
        const absences = await getAbsencesByMonth(input.year, input.month);

        // عدد أيام غياب كل معلم
        const absenceCountMap = new Map<number, number>();
        for (const a of absences) {
          absenceCountMap.set(a.teacherId, (absenceCountMap.get(a.teacherId) || 0) + 1);
        }

        return allTeachers.map((t) => ({
          teacher: t,
          substituteCount: countMap.get(t.id) || 0,
          absenceCount: absenceCountMap.get(t.id) || 0,
        }));
      }),

    updateSubstituteTeacher: protectedProcedure
      .input(z.object({ assignmentId: z.number(), newSubstituteTeacherId: z.number() }))
      .mutation(async ({ input }) => {
        // جلب بيانات التكليف الحالي
        const assignment = await getAssignmentById(input.assignmentId);
        if (!assignment) throw new Error("التكليف غير موجود");

        // جلب سجلات الغياب للتاريخ نفسه والبحث عن سجل الغياب المطابق
        const dateStr = String(assignment.assignmentDate).split("T")[0];
        const absencesByDate = await getAbsencesByDate(dateStr);
        const absenceRecord = absencesByDate.find((a) => a.id === assignment.absenceRecordId) || null;

        // حساب isSpecialtyMatch: مقارنة تخصص البديل الجديد مع تخصص الغائب
        let isSpecialtyMatch = false;
        if (absenceRecord) {
          const absentTeacher = await getTeacherById(absenceRecord.teacherId);
          const newSubTeacher = await getTeacherById(input.newSubstituteTeacherId);
          if (absentTeacher?.specialty && newSubTeacher?.specialty &&
              absentTeacher.specialty === newSubTeacher.specialty) {
            isSpecialtyMatch = true;
          }
        }

        await updateSubstituteAssignment(input.assignmentId, input.newSubstituteTeacherId, isSpecialtyMatch);
        return { success: true, isSpecialtyMatch };
      }),

    dailyReport: publicProcedure
      .input(z.object({ date: z.string() }))
      .query(async ({ input }) => {
        const absences = await getAbsencesByDate(input.date);
        const result = [];
        for (const absence of absences) {
          const absentTeacher = await getTeacherById(absence.teacherId);
          const assignments = await getAssignmentsByAbsenceRecord(absence.id);
          const assignmentsWithTeachers = [];
          for (const a of assignments) {
            const subTeacher = await getTeacherById(a.substituteTeacherId);
            assignmentsWithTeachers.push({ ...a, substituteTeacher: subTeacher });
          }
          result.push({
            absence,
            absentTeacher,
            assignments: assignmentsWithTeachers,
          });
        }
        return result;
      }),
   }),

  // =================== قائمة الانتظار ===================
  rotationQueue: publicProcedure.query(async () => {
    const allTeachers = await getAllTeachers();
    const tookInCurrentRound = await getTeachersWhoTookInCurrentRound();
    const allStates = await getAllRotationStates();
    const currentRoundNumber = allStates.length > 0
      ? Math.max(...allStates.map(s => s.roundNumber || 1))
      : 1;

    // تصفية المعلمين المؤهلين - نفس منطق distributeSubstitutes تماماً
    // HARD_BLOCK_TEACHERS: حمد عبدالله محمد الحوسنى (60002) - محظور مطلقاً
    const exemptions = await getAllPartialExemptions();
    // النصاب الحقيقي من الجدول
    const scheduleCountMap = await getScheduleCountByTeacher();
    // المستثنى كلياً: من لديه استثناء بدون تحديد أيام (استثناء دائم)
    const exemptSet = new Set(
      exemptions
        .filter(e => {
          try {
            const days = JSON.parse(e.exemptDays || '[]') as string[];
            return days.length === 0; // بدون تحديد أيام = مستثنى دائماً
          } catch { return false; }
        })
        .map(e => e.teacherId)
    );
    // المؤهلون: غير محظورين (HARD_BLOCK_TEACHERS) + غير مستثنين دائماً + نشطون + غير مستثنين بـ isExemptFromSubstitute
    const eligible = allTeachers.filter(t =>
      !HARD_BLOCK_TEACHERS.has(t.id) &&
      !exemptSet.has(t.id) &&
      t.isActive !== false &&
      !t.isExemptFromSubstitute
    );

    const waiting = eligible.filter(t => !tookInCurrentRound.has(t.id));
    const done = eligible.filter(t => tookInCurrentRound.has(t.id));

    // ترتيب قائمة الانتظار حسب النصاب الحقيقي من الجدول (الأقل أولاً)
    const sortByRealLoad = (a: typeof eligible[0], b: typeof eligible[0]) => {
      const aLoad = scheduleCountMap.get(a.id) ?? (a.weeklyLoad || 0);
      const bLoad = scheduleCountMap.get(b.id) ?? (b.weeklyLoad || 0);
      return aLoad - bLoad;
    };
    waiting.sort(sortByRealLoad);
    done.sort(sortByRealLoad);

    return {
      currentRoundNumber,
      totalEligible: eligible.length,
      waitingCount: waiting.length,
      doneCount: done.length,
      waiting: waiting.map(t => ({
        id: t.id,
        name: t.name,
        specialty: t.specialty,
        weeklyLoad: t.weeklyLoad,
        realLoad: scheduleCountMap.get(t.id) ?? t.weeklyLoad ?? 0,
      })),
      done: done.map(t => ({
        id: t.id,
        name: t.name,
        specialty: t.specialty,
        weeklyLoad: t.weeklyLoad,
        realLoad: scheduleCountMap.get(t.id) ?? t.weeklyLoad ?? 0,
      })),
    };
  }),

  // =================== SPECIALTY DOMAINS ===================
  specialtyDomains: router({
    getAll: publicProcedure.query(async () => {
      const rows = await getAllSpecialtyDomains();
      return rows.map(r => ({
        ...r,
        specialties: (() => { try { return JSON.parse(r.specialties); } catch { return []; } })(),
      }));
    }),

    upsert: publicProcedure
      .input(z.object({
        domainKey: z.string().min(1),
        domainLabel: z.string().min(1),
        specialties: z.array(z.string()),
        color: z.string().optional(),
        isCore: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        await upsertSpecialtyDomain(input);
        return { success: true };
      }),

    delete: publicProcedure
      .input(z.object({ domainKey: z.string() }))
      .mutation(async ({ input }) => {
        await deleteSpecialtyDomain(input.domainKey);
        return { success: true };
      }),

    seedDefaults: publicProcedure.mutation(async () => {
      await seedDefaultSpecialtyDomains();
      return { success: true };
    }),
  }),

  admin: router({
    // تسجيل دخول المعلم الأول (صلاحية تتبع مادة واحدة فقط)
    headTeacherLogin: publicProcedure
      .input(z.object({ password: z.string(), subject: z.string() }))
      .mutation(async ({ input }) => {
        const adminPw = process.env.ADMIN_PASSWORD;
        if (!adminPw) throw new Error('ADMIN_PASSWORD not configured');
        // كلمة مرور المعلم الأول = كلمة مرور الإدارة + "_ht"
        const headTeacherPw = adminPw + '_ht';
        const { timingSafeEqual } = await import('crypto');
        const a = Buffer.from(input.password);
        const b = Buffer.from(headTeacherPw);
        const valid = a.length === b.length && timingSafeEqual(a, b);
        if (!valid) throw new Error('كلمة المرور غير صحيحة');
        if (!input.subject.trim()) throw new Error('يرجى تحديد المادة التي تتابعها');
        return { success: true, subject: input.subject.trim() };
      }),
    // تسجيل دخول الإدارة بكلمة مرور محلية
    login: publicProcedure
      .input(z.object({ password: z.string() }))
      .mutation(async ({ input }) => {
        const adminPw = process.env.ADMIN_PASSWORD;
        if (!adminPw) throw new Error('ADMIN_PASSWORD not configured');
        // مقارنة آمنة باستخدام timingSafeEqual لمنع timing attacks
        const { timingSafeEqual } = await import('crypto');
        const a = Buffer.from(input.password);
        const b = Buffer.from(adminPw);
        const valid = a.length === b.length && timingSafeEqual(a, b);
        if (!valid) {
          throw new Error('كلمة المرور غير صحيحة');
        }
        return { success: true };
      }),
    // التحقق من صحة كلمة المرور (للتحقق من الجلسة)
    verify: publicProcedure
      .input(z.object({ password: z.string() }))
      .query(async ({ input }) => {
        const adminPw = process.env.ADMIN_PASSWORD;
        if (!adminPw) return { valid: false };
        const { timingSafeEqual } = await import('crypto');
        const a = Buffer.from(input.password);
        const b = Buffer.from(adminPw);
        const valid = a.length === b.length && timingSafeEqual(a, b);
        return { valid };
      }),
  }),

  schoolSettings: router({
    get: publicProcedure.query(async () => {
      return await getSchoolSettings();
    }),
    update: protectedProcedure
      .input(z.object({
        schoolName: z.string().min(1).optional(),
        schoolSubtitle: z.string().optional(),
        directorate: z.string().optional(),
        ministry: z.string().optional(),
        country: z.string().optional(),
        logoUrl: z.string().optional(),
        adminContact: z.string().optional(),
        adminPhone: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await updateSchoolSettings(input);
      }),
  }),

  // =================== SUBJECT HEAD (المعلم الأول) ===================
  subjectHead: router({
    // تعيين معلم كمعلم أول مع رقم سري
    assign: protectedProcedure
      .input(z.object({
        teacherId: z.number(),
        password: z.string().min(4),
      }))
      .mutation(async ({ input }) => {
        const hash = await bcrypt.hash(input.password, 10);
        await setSubjectHeadPassword(input.teacherId, hash);
        return { success: true };
      }),

    // إزالة صلاحية المعلم الأول
    remove: protectedProcedure
      .input(z.object({ teacherId: z.number() }))
      .mutation(async ({ input }) => {
        await removeSubjectHead(input.teacherId);
        return { success: true };
      }),

    // جلب قائمة المعلمين الأوائل
    list: publicProcedure.query(async () => {
      return getAllSubjectHeads();
    }),

    // تسجيل دخول المعلم الأول
    login: publicProcedure
      .input(z.object({
        teacherId: z.number(),
        password: z.string(),
      }))
      .mutation(async ({ input }) => {
        const teacher = await getSubjectHeadByIdForLogin(input.teacherId);
        if (!teacher || !teacher.passwordHash) {
          return { success: false, error: "المعلم غير مسجل كمعلم أول" };
        }
        const valid = await bcrypt.compare(input.password, teacher.passwordHash);
        if (!valid) {
          return { success: false, error: "الرقم السري غير صحيح" };
        }
        return {
          success: true,
          teacher: {
            id: teacher.id,
            name: teacher.name,
            specialty: teacher.specialty,
            teacherRole: teacher.teacherRole,
          },
        };
      }),
  }),

  // =================== CUMULATIVE MANAGEMENT ===================
  cumulative: router({
    // إعادة تعيين الرصيد التراكمي لجميع المعلمين (إداري)
    resetAll: protectedProcedure
      .mutation(async () => {
        await resetAllCumulativeCounts();
        return { success: true };
      }),
  }),

  // =================== ROTATION ROUNDS (الجولات التراكمية) ===================
  rotationRounds: router({
    // جلب الجولة الحالية
    getCurrent: publicProcedure.query(async () => {
      return getCurrentRotationRound();
    }),

    // إنشاء جولة جديدة (ينهي الحالية ويصفّر عدادات الجولة)
    createNew: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        startDate: z.string(), // YYYY-MM-DD
        endDate: z.string(),   // YYYY-MM-DD
      }))
      .mutation(async ({ input }) => {
        const round = await createNewRotationRound(input.name, input.startDate, input.endDate);
        return { success: true, round };
      }),

    // تصفير عدادات الجولة فقط (دون إنشاء جولة جديدة)
    resetCounts: protectedProcedure
      .mutation(async () => {
        await resetRoundCounts();
        return { success: true };
      }),
  }),

  // =================== EMERGENCY SYSTEM (نظام الطوارئ القصوى) ===================
  emergency: router({
    // جلب إحصائيات الطوارئ
    getStats: publicProcedure
      .input(z.object({ date: z.string() }))
      .query(async ({ input }) => {
        return getEmergencyStats(input.date);
      }),

    /**
     * كسر القيود الشامل - رفع السقف الفردي لجميع المعلمين +2
     * يُستخدم في حالات الطوارئ فقط
     */
    breakAllLimits: protectedProcedure
      .input(z.object({
        date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
        reason: z.string().min(1),
      }))
      .mutation(async ({ input }) => {
        const db = await import("./db").then(m => m.getDb());
        if (!db) throw new Error("DB not available");
        const { sql: sqlFn } = await import("drizzle-orm");
        // رفع السقف الفردي لجميع المعلمين بمقدار +2 (mاكس 8)
        await db.execute(
          sqlFn`UPDATE teachers SET individual_cap = LEAST(COALESCE(individual_cap, 4) + 2, 8) WHERE is_active = 1`
        );
        // تسجيل حالة الطوارئ في الجولة الحالية
        await db.execute(
          sqlFn`UPDATE rotation_rounds SET name = CONCAT(name, ' [طوارئ]') WHERE is_current = 1 AND name NOT LIKE '%[طوارئ]%'`
        );
        return {
          success: true,
          message: "تم تفعيل كسر القيود الشامل",
          details: {
            date: input.date,
            reason: input.reason,
            emergencyCap: 6,
            normalCap: 4,
            additionalSlots: 2,
          },
        };
      }),

    /**
     * توزيع حصة واحدة مع تجاهل حماية النصاب 22+
     */
    distributeIgnoreFullLoad: protectedProcedure
      .input(z.object({
        date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
        absentTeacherId: z.number(),
        period: z.number().min(1).max(8),
        className: z.string(),
        subjectName: z.string(),
      }))
      .mutation(async ({ input }) => {
        const { date, absentTeacherId, period, className, subjectName } = input;
        // التحقق من عدم وجود تكليف سابق
        const existingAssignments = await getAssignmentsByDate(date);
        const alreadyAssigned = existingAssignments.some(
          (a: any) => a.absentTeacherId === absentTeacherId && a.periodNumber === period
        );
        if (alreadyAssigned) {
          throw new Error("يوجد تكليف سابق لهذه الحصة");
        }
        // جلب المرشحين (مع تجاهل حماية 22)
        const candidates = await getEmergencyCandidates({
          date,
          absentTeacherId,
          period,
          ignoreFullLoad: true,
          ignoreRoundCap: false,
        });
        let selected = candidates[0];
        let source = "emergency";
        // إذا لم يوجد مرشح: الطوارئ القصوى
        if (!selected) {
          const lastResort = await findAnyAvailableTeacher(date, period, absentTeacherId);
          if (!lastResort) {
            throw new Error("لا يوجد أي معلم متاح حتى في الطوارئ القصوى");
          }
          selected = lastResort;
          source = "emergency_extreme";
        }
        // جلب سجل الغياب
        const absences = await getAbsencesByDate(date);
        const absence = absences.find((a: any) => a.teacherId === absentTeacherId);
        if (!absence) throw new Error("لم يتم العثور على سجل غياب المعلم");
        // تسجيل التكليف
        await insertSubstituteAssignments([{
          absenceRecordId: absence.id,
          absentTeacherId,
          substituteTeacherId: Number(selected.id),
          assignmentDate: date as any,
          periodNumber: period,
          dayOfWeek: (() => { const [y,m,d] = date.split('-').map(Number); return new Date(y,m-1,d).toLocaleDateString("en-US", { weekday: "long" }); })() as any,
          subjectName,
          className,
          isSpecialtyMatch: false,
          constraintBreakLevel: 3,
          constraintBreakReason: "طوارئ قصوى - تجاهل حماية النصاب 22",
        }]);
        // تحديث العدادات
        await incrementCumulativeCount(Number(selected.id));
        await incrementRoundCount(Number(selected.id));
        return {
          success: true,
          selectedTeacher: { id: Number(selected.id), name: selected.name },
          source,
          warning: source === "emergency_extreme"
            ? "تم التكليف في وضع الطوارئ القصوى - تجاوز جميع القيود"
            : "تم التكليف في وضع الطوارئ - تجاهل حماية النصاب 22",
        };
      }),

    /**
     * التوزيع القسري - توزيع جميع الحصص الشاغرة لتاريخ معين
     */
    forceDistributeRemaining: protectedProcedure
      .input(z.object({
        date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
        reason: z.string().min(1),
      }))
      .mutation(async ({ input }) => {
        const { date, reason } = input;
        const absences = await getAbsencesByDate(date);
        const existingAssignments = await getAssignmentsByDate(date);
        const results: Array<{ absentTeacherId: number; period: number; substituteName: string }> = [];
        const errors: string[] = [];

        for (const absence of absences) {
          // تحديد الحصص الغائبة من سجل الغياب
          let absentPeriods: number[] = [];
          try {
            const pp = absence.partialPeriods ? JSON.parse(absence.partialPeriods) : [];
            absentPeriods = pp.length > 0 ? pp : [1, 2, 3, 4, 5, 6, 7, 8];
          } catch {
            absentPeriods = [1, 2, 3, 4, 5, 6, 7, 8];
          }

          for (const period of absentPeriods) {
            // تحقق: هل الحصة موزعة بالفعل?
            const alreadyAssigned = existingAssignments.some(
              (a: any) => a.absentTeacherId === absence.teacherId && a.periodNumber === period
            );
            if (alreadyAssigned) continue;

            // بحث عن بديل (طوارئ قصوى: تجاهل جميع القيود)
            const substitute = await findAnyAvailableTeacher(date, period, absence.teacherId);
            if (!substitute) {
              errors.push(`لا يوجد بديل للحصة ${period} للمعلم ${absence.teacherId}`);
              continue;
            }

            try {
              await insertSubstituteAssignments([{
                absenceRecordId: absence.id,
                absentTeacherId: absence.teacherId,
                substituteTeacherId: substitute.id,
                assignmentDate: date as any,
                periodNumber: period,
                dayOfWeek: (() => { const [y,m,d] = date.split('-').map(Number); return new Date(y,m-1,d).toLocaleDateString("en-US", { weekday: "long" }); })() as any,
                subjectName: "طوارئ",
                className: "طوارئ",
                isSpecialtyMatch: false,
                constraintBreakLevel: 3,
                constraintBreakReason: `توزيع قسري - ${reason}`,
              }]);
              await incrementCumulativeCount(substitute.id);
              await incrementRoundCount(substitute.id);
              results.push({
                absentTeacherId: absence.teacherId,
                period,
                substituteName: substitute.name,
              });
            } catch (err: any) {
              errors.push(`خطأ في الحصة ${period}: ${err.message}`);
            }
          }
        }

        return {
          success: true,
          processed: results.length,
          errors: errors.length,
          errorDetails: errors,
          message: `تم توزيع ${results.length} حصة قسراً في وضع الطوارئ`,
          details: results,
        };
      }),

    /**
     * إعادة القيود الطبيعية (إنهاء حالة الطوارئ)
     */
    restoreNormalLimits: protectedProcedure
      .mutation(async () => {
        const db = await import("./db").then(m => m.getDb());
        if (!db) throw new Error("DB not available");
        const { sql: sqlFn } = await import("drizzle-orm");
        // إعادة السقف الفردي إلى القيمة الطبيعية (4)
        await db.execute(
          sqlFn`UPDATE teachers SET individual_cap = 4 WHERE is_active = 1`
        );
        await restoreNormalLimits();
        return {
          success: true,
          message: "تم إعادة القيود الطبيعية - السقف الفردي: 4 حصص",
        };
      }),
  }),

  // =================== COMPENSATION TRACKING (تتبع التعويض) ===================
  compensation: router({
    // جلب سجلات التعويض المعلقة لتاريخ معين
    getPending: publicProcedure
      .input(z.object({ date: z.string() }))
      .query(async ({ input }) => {
        return getPendingCompensations(input.date);
      }),

    // إنشاء سجل تعويض للمعلم العائد
    create: protectedProcedure
      .input(z.object({
        teacherId: z.number(),
        absenceRecordId: z.number(),
        compensationDate: z.string(),
        period: z.number().min(1).max(8),
      }))
      .mutation(async ({ input }) => {
        await createCompensationRecord(
          input.teacherId,
          input.absenceRecordId,
          input.compensationDate,
          input.period
        );
        return { success: true };
      }),

    // تحديث حالة التعويض إلى مكتمل
    complete: protectedProcedure
      .input(z.object({
        compensationId: z.number(),
        substituteTeacherId: z.number(),
      }))
      .mutation(async ({ input }) => {
        await completeCompensation(input.compensationId, input.substituteTeacherId);
        return { success: true };
      }),
  }),
});
export type AppRouter = typeof appRouter;
