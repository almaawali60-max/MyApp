import { describe, it, expect, vi, beforeEach } from "vitest";

// =================== اختبارات منطق الاستثناءات الجزئية ===================

// محاكاة منطق isPartiallyExempt من routers.ts
function isPartiallyExempt(
  teacherId: number,
  day: string,
  period: number,
  partialExemptionMap: Map<number, { exemptDays: string[]; exemptPeriods: number[] }>
): boolean {
  const pe = partialExemptionMap.get(teacherId);
  if (!pe) return false;
  if (!pe.exemptDays.includes(day)) return false;
  // إذا كانت exemptPeriods فارغة → مستثنى من كل الحصص في هذا اليوم
  if (pe.exemptPeriods.length === 0) return true;
  // وإلا → مستثنى فقط من الحصص المحددة
  return pe.exemptPeriods.includes(period);
}

// محاكاة summarizePartialExemption من Teachers.tsx
const DAY_LABELS: Record<string, string> = {
  Sunday: "الأحد",
  Monday: "الاثنين",
  Tuesday: "الثلاثاء",
  Wednesday: "الأربعاء",
  Thursday: "الخميس",
};

function summarizePartialExemption(exemptDays: string[], exemptPeriods: number[]): string {
  if (exemptDays.length === 0) return "";
  const allDays = exemptDays.length === 5;
  const daysLabel = allDays
    ? "يومياً"
    : exemptDays.map((d) => DAY_LABELS[d] || d).join("، ");
  if (exemptPeriods.length === 0) {
    return `مستثنى ${daysLabel}`;
  }
  const periodsLabel = exemptPeriods.map((p) => `ح${p}`).join("، ");
  return `مستثنى ${periodsLabel} ${daysLabel}`;
}

describe("isPartiallyExempt", () => {
  const map = new Map<number, { exemptDays: string[]; exemptPeriods: number[] }>();

  beforeEach(() => {
    map.clear();
  });

  it("يُعيد false إذا لم يكن للمعلم استثناء جزئي", () => {
    expect(isPartiallyExempt(1, "Thursday", 5, map)).toBe(false);
  });

  it("يُعيد false إذا كان اليوم غير مستثنى", () => {
    map.set(1, { exemptDays: ["Thursday"], exemptPeriods: [] });
    expect(isPartiallyExempt(1, "Sunday", 5, map)).toBe(false);
  });

  it("يُعيد true إذا كان اليوم مستثنى وexemptPeriods فارغة (كل الحصص)", () => {
    map.set(1, { exemptDays: ["Thursday"], exemptPeriods: [] });
    expect(isPartiallyExempt(1, "Thursday", 1, map)).toBe(true);
    expect(isPartiallyExempt(1, "Thursday", 8, map)).toBe(true);
  });

  it("يُعيد true فقط للحصص المحددة", () => {
    map.set(2, { exemptDays: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"], exemptPeriods: [8] });
    expect(isPartiallyExempt(2, "Sunday", 8, map)).toBe(true);
    expect(isPartiallyExempt(2, "Sunday", 7, map)).toBe(false);
    expect(isPartiallyExempt(2, "Thursday", 8, map)).toBe(true);
  });

  it("يُعيد true للحصتين 7 و8 يومياً", () => {
    map.set(3, { exemptDays: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"], exemptPeriods: [7, 8] });
    expect(isPartiallyExempt(3, "Monday", 7, map)).toBe(true);
    expect(isPartiallyExempt(3, "Monday", 8, map)).toBe(true);
    expect(isPartiallyExempt(3, "Monday", 6, map)).toBe(false);
  });

  it("يُعيد true فقط ليومي الأحد والاثنين (أحمد عبدالمجيد)", () => {
    map.set(4, { exemptDays: ["Sunday", "Monday"], exemptPeriods: [] });
    expect(isPartiallyExempt(4, "Sunday", 3, map)).toBe(true);
    expect(isPartiallyExempt(4, "Monday", 5, map)).toBe(true);
    expect(isPartiallyExempt(4, "Tuesday", 3, map)).toBe(false);
    expect(isPartiallyExempt(4, "Thursday", 1, map)).toBe(false);
  });

  it("يُعيد true ليومي الأربعاء والخميس (محمد المعشري)", () => {
    map.set(5, { exemptDays: ["Wednesday", "Thursday"], exemptPeriods: [] });
    expect(isPartiallyExempt(5, "Wednesday", 4, map)).toBe(true);
    expect(isPartiallyExempt(5, "Thursday", 2, map)).toBe(true);
    expect(isPartiallyExempt(5, "Sunday", 1, map)).toBe(false);
  });
});

describe("summarizePartialExemption", () => {
  it("يُعيد نصاً فارغاً إذا لم تكن هناك أيام", () => {
    expect(summarizePartialExemption([], [])).toBe("");
  });

  it("يُلخص استثناء يوم الخميس بشكل صحيح", () => {
    expect(summarizePartialExemption(["Thursday"], [])).toBe("مستثنى الخميس");
  });

  it("يُلخص استثناء يومي الأربعاء والخميس", () => {
    expect(summarizePartialExemption(["Wednesday", "Thursday"], [])).toBe("مستثنى الأربعاء، الخميس");
  });

  it("يُلخص استثناء الحصة 8 يومياً", () => {
    const allDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"];
    expect(summarizePartialExemption(allDays, [8])).toBe("مستثنى ح8 يومياً");
  });

  it("يُلخص استثناء الحصتين 7 و8 يومياً", () => {
    const allDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"];
    expect(summarizePartialExemption(allDays, [7, 8])).toBe("مستثنى ح7، ح8 يومياً");
  });

  it("يُلخص استثناء يومي الأحد والاثنين", () => {
    expect(summarizePartialExemption(["Sunday", "Monday"], [])).toBe("مستثنى الأحد، الاثنين");
  });
});

describe("تحليل JSON للاستثناءات الجزئية", () => {
  it("يُحلل exemptDays بشكل صحيح", () => {
    const raw = '["Thursday"]';
    const parsed = JSON.parse(raw);
    expect(parsed).toEqual(["Thursday"]);
  });

  it("يُحلل exemptPeriods بشكل صحيح", () => {
    const raw = '[7,8]';
    const parsed = JSON.parse(raw);
    expect(parsed).toEqual([7, 8]);
  });

  it("يُحلل exemptPeriods الفارغة بشكل صحيح", () => {
    const raw = '[]';
    const parsed = JSON.parse(raw);
    expect(parsed).toEqual([]);
  });

  it("يتعامل مع null بشكل آمن", () => {
    const raw = null;
    const parsed = JSON.parse(raw || '[]');
    expect(parsed).toEqual([]);
  });
});
