import { describe, it, expect } from "vitest";
import { timingSafeEqual } from "crypto";

// دالة مقارنة آمنة مطابقة لما في routers.ts
function checkPassword(input: string, stored: string): boolean {
  const a = Buffer.from(input);
  const b = Buffer.from(stored);
  return a.length === b.length && timingSafeEqual(a, b);
}

describe("Admin Password Validation", () => {
  const ADMIN_PW = process.env.ADMIN_PASSWORD ?? "Secure@kh1401#";

  it("should accept the correct password Secure@kh1401#", () => {
    const valid = checkPassword("Secure@kh1401#", ADMIN_PW);
    expect(valid).toBe(true);
  });

  it("should reject wrong passwords", () => {
    expect(checkPassword("wrongpassword", ADMIN_PW)).toBe(false);
    expect(checkPassword("@Kh1401#Secure!", ADMIN_PW)).toBe(false);
    expect(checkPassword("secure@kh1401#", ADMIN_PW)).toBe(false);
    expect(checkPassword("Secure@kh1401", ADMIN_PW)).toBe(false);
    expect(checkPassword("", ADMIN_PW)).toBe(false);
  });
});
