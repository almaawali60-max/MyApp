/**
 * اختبارات نظام الجداول المزدوج والتخصصات الديناميكية
 * المتطلبات المختبرة:
 * 1. تحديث النصاب تلقائياً عند إضافة/حذف حصة
 * 2. بناء خريطة التخصصات من قاعدة البيانات
 * 3. fallback للثوابت الصلبة عند غياب البيانات الديناميكية
 */
import { describe, it, expect } from "vitest";

// =================== اختبارات بناء خريطة التخصصات ===================
describe("buildSpecialtyGroupsFromDB - logic", () => {
  function buildGroupsFromDomains(domains: Array<{
    domainKey: string;
    specialties: string;
    isCore: boolean;
  }>) {
    const groups: Record<string, string> = {};
    const coreGroups = new Set<string>();
    for (const domain of domains) {
      let specialties: string[] = [];
      try { specialties = JSON.parse(domain.specialties); } catch { specialties = []; }
      for (const sp of specialties) {
        groups[sp] = domain.domainKey;
      }
      if (domain.isCore) coreGroups.add(domain.domainKey);
    }
    return { groups, coreGroups };
  }

  it("يبني خريطة صحيحة من بيانات المجالات", () => {
    const domains = [
      { domainKey: "علوم", specialties: '["فيزياء","كيمياء","أحياء"]', isCore: true },
      { domainKey: "مهارات_فردية", specialties: '["رياضة مدرسية","فنون تشكيلية"]', isCore: false },
    ];
    const { groups, coreGroups } = buildGroupsFromDomains(domains);
    expect(groups["فيزياء"]).toBe("علوم");
    expect(groups["كيمياء"]).toBe("علوم");
    expect(groups["أحياء"]).toBe("علوم");
    expect(groups["رياضة مدرسية"]).toBe("مهارات_فردية");
    expect(groups["فنون تشكيلية"]).toBe("مهارات_فردية");
  });

  it("يصنّف المجالات الأساسية بشكل صحيح", () => {
    const domains = [
      { domainKey: "علوم", specialties: '["فيزياء"]', isCore: true },
      { domainKey: "مهارات_فردية", specialties: '["رياضة"]', isCore: false },
    ];
    const { coreGroups } = buildGroupsFromDomains(domains);
    expect(coreGroups.has("علوم")).toBe(true);
    expect(coreGroups.has("مهارات_فردية")).toBe(false);
  });

  it("يتعامل مع JSON غير صالح بشكل آمن", () => {
    const domains = [
      { domainKey: "علوم", specialties: 'INVALID_JSON', isCore: true },
    ];
    const { groups } = buildGroupsFromDomains(domains);
    expect(Object.keys(groups).length).toBe(0);
  });

  it("يُعيد خريطة فارغة عند عدم وجود مجالات", () => {
    const { groups, coreGroups } = buildGroupsFromDomains([]);
    expect(Object.keys(groups).length).toBe(0);
    expect(coreGroups.size).toBe(0);
  });
});

// =================== اختبارات resolveSpecialtyGroup ===================
describe("resolveSpecialtyGroup - dynamic vs static fallback", () => {
  const STATIC_GROUPS: Record<string, string> = {
    'علوم': 'علوم', 'فيزياء': 'علوم', 'كيمياء': 'علوم',
    'رياضيات': 'رياضيات', 'لغة عربية': 'عربية',
  };

  function resolveSpecialtyGroup(
    subjectName: string,
    dynamicGroups: Record<string, string>
  ): string | null {
    if (!subjectName) return null;
    const normalized = subjectName.trim();
    if (Object.keys(dynamicGroups).length > 0) {
      if (dynamicGroups[normalized]) return dynamicGroups[normalized];
      for (const [key, group] of Object.entries(dynamicGroups)) {
        if (normalized.includes(key) || key.includes(normalized)) return group;
      }
    }
    if (STATIC_GROUPS[normalized]) return STATIC_GROUPS[normalized];
    return null;
  }

  it("يستخدم البيانات الديناميكية عند توفرها", () => {
    const dynamic = { "فيزياء متقدمة": "علوم_متقدمة" };
    expect(resolveSpecialtyGroup("فيزياء متقدمة", dynamic)).toBe("علوم_متقدمة");
  });

  it("يرجع للثوابت الصلبة عند غياب البيانات الديناميكية", () => {
    expect(resolveSpecialtyGroup("فيزياء", {})).toBe("علوم");
    expect(resolveSpecialtyGroup("رياضيات", {})).toBe("رياضيات");
  });

  it("يدعم البحث الجزئي في البيانات الديناميكية", () => {
    const dynamic = { "علوم": "علوم_عامة" };
    expect(resolveSpecialtyGroup("علوم تطبيقية", dynamic)).toBe("علوم_عامة");
  });

  it("يُعيد null للمواد غير المصنّفة", () => {
    expect(resolveSpecialtyGroup("مادة غير معروفة", {})).toBeNull();
  });

  it("يُعيد null للسلسلة الفارغة", () => {
    expect(resolveSpecialtyGroup("", {})).toBeNull();
  });
});

// =================== اختبارات تحديث النصاب ===================
describe("weeklyLoad auto-update logic", () => {
  it("يحسب النصاب بشكل صحيح بعد إضافة حصص", () => {
    // محاكاة حساب النصاب
    const scheduleEntries = [
      { teacherId: 1, dayOfWeek: "Sunday", periodNumber: 1 },
      { teacherId: 1, dayOfWeek: "Sunday", periodNumber: 2 },
      { teacherId: 1, dayOfWeek: "Monday", periodNumber: 3 },
    ];
    const weeklyLoad = scheduleEntries.filter(e => e.teacherId === 1).length;
    expect(weeklyLoad).toBe(3);
  });

  it("يحسب النصاب بشكل صحيح بعد حذف حصة", () => {
    const scheduleEntries = [
      { id: 1, teacherId: 1, dayOfWeek: "Sunday", periodNumber: 1 },
      { id: 2, teacherId: 1, dayOfWeek: "Sunday", periodNumber: 2 },
    ];
    // محاكاة حذف حصة بـ id=1
    const afterDelete = scheduleEntries.filter(e => e.id !== 1);
    const weeklyLoad = afterDelete.filter(e => e.teacherId === 1).length;
    expect(weeklyLoad).toBe(1);
  });
});

// =================== اختبارات فحص التعارض ===================
describe("conflict detection - manual assignment", () => {
  function isBusyWithBasic(
    schedule: Array<{ dayOfWeek: string; periodNumber: number }>,
    dayOfWeek: string,
    periodNumber: number
  ): boolean {
    return schedule.some(s => s.dayOfWeek === dayOfWeek && s.periodNumber === periodNumber);
  }

  it("يكشف التعارض عند وجود حصة أساسية في نفس الوقت", () => {
    const schedule = [
      { dayOfWeek: "Sunday", periodNumber: 3 },
      { dayOfWeek: "Monday", periodNumber: 5 },
    ];
    expect(isBusyWithBasic(schedule, "Sunday", 3)).toBe(true);
  });

  it("لا يكشف تعارضاً عند عدم وجود حصة أساسية", () => {
    const schedule = [
      { dayOfWeek: "Sunday", periodNumber: 3 },
    ];
    expect(isBusyWithBasic(schedule, "Monday", 3)).toBe(false);
    expect(isBusyWithBasic(schedule, "Sunday", 4)).toBe(false);
  });

  it("يكشف التعارض في الحصص 7 و8", () => {
    const schedule = [
      { dayOfWeek: "Thursday", periodNumber: 7 },
      { dayOfWeek: "Thursday", periodNumber: 8 },
    ];
    expect(isBusyWithBasic(schedule, "Thursday", 7)).toBe(true);
    expect(isBusyWithBasic(schedule, "Thursday", 8)).toBe(true);
  });

  it("لا يكشف تعارضاً في جدول فارغ", () => {
    expect(isBusyWithBasic([], "Sunday", 1)).toBe(false);
  });
});
