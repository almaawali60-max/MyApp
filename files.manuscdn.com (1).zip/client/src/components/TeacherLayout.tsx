import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { FileText, BarChart3, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useAdminAuth } from "@/contexts/AdminAuthContext";

const navItems = [
  {
    href: "/teacher/daily-report",
    label: "جدول الاحتياط اليومي",
    icon: FileText,
  },
  {
    href: "/teacher/statistics",
    label: "الإحصائيات العامة",
    icon: BarChart3,
  },
];

interface TeacherLayoutProps {
  children: ReactNode;
}

export default function TeacherLayout({ children }: TeacherLayoutProps) {
  const [location] = useLocation();
  const { logout } = useAdminAuth();

  return (
    <div className="min-h-screen flex flex-col" dir="rtl" style={{ background: "oklch(0.97 0.005 120)" }}>
      {/* Header */}
      <header
        className="sticky top-0 z-30 shadow-md"
        style={{ background: "oklch(0.18 0.07 145)" }}
      >
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex-1 text-center">
            <h1 className="text-sm font-bold" style={{ color: "oklch(0.75 0.13 75)" }}>
              مدرسة الخوير للتعليم الأساسي (5-9)
            </h1>
            <p className="text-xs" style={{ color: "oklch(0.7 0.01 120)" }}>
              نظام توزيع الاحتياط — واجهة المعلمين
            </p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={logout}
            className="text-xs gap-1 hover:bg-white/10"
            style={{ color: "oklch(0.75 0.01 120)" }}
          >
            <LogOut size={14} />
            خروج
          </Button>
        </div>
        {/* Navigation Tabs */}
        <nav className="flex border-t" style={{ borderColor: "oklch(0.28 0.06 145)" }}>
          {navItems.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href}>
                <div
                  className={cn(
                    "flex items-center gap-2 px-6 py-2.5 text-sm font-medium cursor-pointer transition-all",
                    isActive ? "border-b-2" : "opacity-70 hover:opacity-100"
                  )}
                  style={
                    isActive
                      ? { color: "oklch(0.75 0.13 75)", borderColor: "oklch(0.75 0.13 75)" }
                      : { color: "oklch(0.75 0.01 120)" }
                  }
                >
                  <Icon size={16} />
                  {item.label}
                </div>
              </Link>
            );
          })}
        </nav>
      </header>

      {/* Read-only banner */}
      <div
        className="text-center py-2 text-xs font-medium"
        style={{ background: "oklch(0.85 0.08 75)", color: "oklch(0.2 0.05 145)" }}
      >
        وضع العرض فقط — لتسجيل الغياب أو التعديل، يرجى الدخول عبر حساب الإدارة
      </div>

      {/* Content */}
      <main className="flex-1 p-4 lg:p-6">{children}</main>
    </div>
  );
}
