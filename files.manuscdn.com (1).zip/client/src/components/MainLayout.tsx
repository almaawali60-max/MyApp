import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  Users,
  CalendarX,
  FileText,
  BarChart3,
  Upload,
  Menu,
  X,
  ChevronRight,
  ChevronDown,
  GraduationCap,
  LogOut,
  Shield,
  RotateCcw,
  Layers,
  BookOpen,
  Activity,
  Building2,
  Settings,
  UserCheck,
  ClipboardList,
  Siren,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useAdminAuth } from "@/contexts/AdminAuthContext";
import { trpc } from "@/lib/trpc";

// الهيكلة الخماسية للقائمة
const navSections = [
  {
    key: "teachers",
    label: "شؤون المعلمين",
    icon: Users,
    color: "oklch(0.65 0.15 200)",
    items: [
      { href: "/teachers", label: "قائمة المعلمين", icon: Users },
      { href: "/absence", label: "تسجيل الغياب", icon: CalendarX },
      { href: "/daily-report", label: "جدول الاحتياط اليومي", icon: FileText },
      { href: "/rotation-queue", label: "قائمة الانتظار", icon: RotateCcw },
      { href: "/statistics", label: "الإحصائيات الشهرية", icon: BarChart3 },
      { href: "/subject-heads", label: "المعلمون الأوائل", icon: Shield },
    ],
  },
  {
    key: "students",
    label: "شؤون الطلاب",
    icon: BookOpen,
    color: "oklch(0.65 0.15 140)",
    items: [
      { href: "/students", label: "بيانات الطلاب", icon: UserCheck },
    ],
  },
  {
    key: "activities",
    label: "الأنشطة المدرسية",
    icon: Activity,
    color: "oklch(0.65 0.15 60)",
    items: [
      { href: "/activities", label: "سجل الأنشطة", icon: ClipboardList },
    ],
  },
  {
    key: "admin",
    label: "إدارة المدرسة",
    icon: Building2,
    color: "oklch(0.65 0.15 30)",
    items: [
      { href: "/specialization", label: "توزيع الاحتياط", icon: GraduationCap },
      { href: "/specialty-domains", label: "مجالات التخصص", icon: Layers },
      { href: "/import", label: "رفع الجداول", icon: Upload },
      { href: "/emergency", label: "لوحة الطوارئ القصوى", icon: Siren },
    ],
  },
  {
    key: "system",
    label: "إدارة نظام شامل",
    icon: Settings,
    color: "oklch(0.75 0.13 75)",
    items: [
      { href: "/", label: "لوحة التحكم", icon: LayoutDashboard },
      { href: "/school-settings", label: "بيانات المدرسة", icon: Building2 },
    ],
  },
];

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { logout } = useAdminAuth();
  const { data: schoolSettings } = trpc.schoolSettings.get.useQuery();

  // تحديد القسم النشط بناءً على الصفحة الحالية
  const activeSection = navSections.find((s) =>
    s.items.some((item) => item.href === location)
  )?.key;

  // حالة فتح/إغلاق كل قسم
  const [openSections, setOpenSections] = useState<Record<string, boolean>>(() => {
    const initial: Record<string, boolean> = {};
    navSections.forEach((s) => {
      initial[s.key] = s.items.some((item) => item.href === location) || s.key === "teachers";
    });
    return initial;
  });

  const toggleSection = (key: string) => {
    setOpenSections((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const schoolName = schoolSettings?.schoolName || "مدرسة الخوير للتعليم الأساسي (5-9)";
  const directorate = schoolSettings?.directorate || "المديرية العامة للتعليم بمسقط";
  const ministry = schoolSettings?.ministry || "وزارة التعليم";
  const country = schoolSettings?.country || "سلطنة عُمان";

  return (
    <div className="min-h-screen flex" dir="rtl">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed top-0 right-0 h-full w-72 z-50 flex flex-col transition-transform duration-300",
          "lg:relative lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "translate-x-full lg:translate-x-0"
        )}
        style={{ background: "var(--sidebar)" }}
      >
        {/* Sidebar Header */}
        <div className="flex flex-col items-center py-5 px-4 border-b border-sidebar-border">
          {schoolSettings?.logoUrl ? (
            <img
              src={schoolSettings.logoUrl}
              alt="شعار المدرسة"
              className="w-14 h-14 rounded-full object-cover mb-2 shadow-lg border-2"
              style={{ borderColor: "oklch(0.85 0.1 75)" }}
            />
          ) : (
            <div className="w-14 h-14 rounded-full flex items-center justify-center mb-2 shadow-lg border-2"
              style={{ background: "oklch(0.75 0.13 75)", borderColor: "oklch(0.85 0.1 75)" }}>
              <svg viewBox="0 0 40 40" width="32" height="32" fill="none">
                <rect x="8" y="18" width="24" height="16" rx="2" fill="oklch(0.18 0.07 145)" />
                <polygon points="4,18 20,6 36,18" fill="oklch(0.18 0.07 145)" />
                <rect x="16" y="24" width="8" height="10" rx="1" fill="oklch(0.75 0.13 75)" />
                <rect x="10" y="21" width="5" height="5" rx="0.5" fill="oklch(0.75 0.13 75)" />
                <rect x="25" y="21" width="5" height="5" rx="0.5" fill="oklch(0.75 0.13 75)" />
              </svg>
            </div>
          )}
          <div className="text-center">
            <p className="text-xs font-medium mb-0.5" style={{ color: "oklch(0.75 0.13 75)" }}>{country}</p>
            <p className="text-xs" style={{ color: "oklch(0.65 0.01 120)" }}>{ministry}</p>
          </div>
          {/* Admin Badge */}
          <div
            className="mt-2 flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium"
            style={{ background: "oklch(0.65 0.13 75)", color: "oklch(0.15 0.05 145)" }}
          >
            <Shield size={11} />
            لوحة الإدارة
          </div>
        </div>

        {/* Navigation - الهيكلة الخماسية */}
        <nav className="flex-1 overflow-y-auto py-3 px-2">
          <div className="space-y-1">
            {navSections.map((section) => {
              const SectionIcon = section.icon;
              const isOpen = openSections[section.key];
              const hasActiveItem = section.items.some((item) => item.href === location);

              return (
                <div key={section.key}>
                  {/* Section Header */}
                  <button
                    onClick={() => toggleSection(section.key)}
                    className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg transition-all duration-200"
                    style={{
                      background: hasActiveItem ? "oklch(0.22 0.07 145)" : "transparent",
                      color: hasActiveItem ? section.color : "oklch(0.75 0.01 120)",
                    }}
                  >
                    <SectionIcon size={16} className="shrink-0" style={{ color: section.color }} />
                    <span className="text-xs font-bold flex-1 text-right">{section.label}</span>
                    <ChevronDown
                      size={13}
                      className="shrink-0 transition-transform duration-200"
                      style={{ transform: isOpen ? "rotate(0deg)" : "rotate(-90deg)", color: section.color }}
                    />
                  </button>

                  {/* Section Items */}
                  {isOpen && (
                    <div className="mr-3 mt-0.5 space-y-0.5 border-r-2 pr-2"
                      style={{ borderColor: section.color + "40" }}>
                      {section.items.map((item) => {
                        const isActive = location === item.href;
                        const ItemIcon = item.icon;
                        return (
                          <Link key={item.href} href={item.href}>
                            <div
                              onClick={() => setSidebarOpen(false)}
                              className={cn(
                                "flex items-center gap-2.5 px-3 py-2 rounded-lg cursor-pointer transition-all duration-150",
                                isActive ? "shadow-sm" : "hover:opacity-80"
                              )}
                              style={
                                isActive
                                  ? { background: section.color, color: "oklch(0.12 0.03 145)" }
                                  : { color: "oklch(0.8 0.01 120)" }
                              }
                            >
                              <ItemIcon size={15} className="shrink-0" />
                              <span className="text-xs font-semibold">{item.label}</span>
                              {isActive && <ChevronRight size={12} className="mr-auto" />}
                            </div>
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </nav>

        {/* Sidebar Footer */}
        <div className="p-3 border-t border-sidebar-border space-y-2">
          <Button
            variant="ghost"
            className="w-full justify-center gap-2 text-xs font-medium hover:bg-white/10"
            style={{ color: "oklch(0.65 0.1 25)" }}
            onClick={logout}
          >
            <LogOut size={14} />
            تسجيل الخروج
          </Button>
          <p className="text-center text-xs truncate" style={{ color: "oklch(0.45 0.03 120)" }}>
            {schoolName}
          </p>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
        {/* Top Header */}
        <header className="sticky top-0 z-30 shadow-sm border-b border-border"
          style={{ background: "oklch(0.18 0.07 145)" }}>
          <div className="flex items-center justify-between px-4 py-3">
            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden text-white hover:bg-white/10"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </Button>

            {/* School Identity */}
            <div className="flex-1 text-center lg:text-right">
              <div className="hidden lg:block">
                <h1 className="text-sm font-bold leading-tight" style={{ color: "oklch(0.75 0.13 75)" }}>
                  {schoolName}
                </h1>
                <p className="text-xs" style={{ color: "oklch(0.8 0.01 120)" }}>
                  {directorate} | {ministry} | {country}
                </p>
              </div>
              <div className="lg:hidden">
                <h1 className="text-sm font-bold" style={{ color: "oklch(0.75 0.13 75)" }}>
                  توزيع احتياط المعلمين
                </h1>
              </div>
            </div>

            {/* Logout button */}
            <Button
              variant="ghost"
              size="sm"
              className="hidden lg:flex items-center gap-1.5 text-xs hover:bg-white/10"
              style={{ color: "oklch(0.7 0.01 120)" }}
              onClick={logout}
            >
              <LogOut size={14} />
              خروج
            </Button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
