import { createContext, useContext, useState, ReactNode } from "react";

export type UserMode = "portal" | "teacher" | "head_teacher" | "admin";

interface AdminAuthContextType {
  mode: UserMode;
  setMode: (mode: UserMode) => void;
  adminPassword: string;
  setAdminPassword: (pw: string) => void;
  /** للمعلم الأول: اسم المادة التي يتابعها */
  subjectFilter: string;
  setSubjectFilter: (s: string) => void;
  logout: () => void;
}

const AdminAuthContext = createContext<AdminAuthContextType | null>(null);

const SESSION_KEY = "admin_mode";
const PASSWORD_KEY = "admin_pw_session";
const SUBJECT_KEY = "head_teacher_subject";

export function AdminAuthProvider({ children }: { children: ReactNode }) {
  const [mode, setModeState] = useState<UserMode>(() => {
    const saved = sessionStorage.getItem(SESSION_KEY);
    return (saved as UserMode) || "portal";
  });
  const [adminPassword, setAdminPasswordState] = useState<string>(() => {
    return sessionStorage.getItem(PASSWORD_KEY) || "";
  });
  const [subjectFilter, setSubjectFilterState] = useState<string>(() => {
    return sessionStorage.getItem(SUBJECT_KEY) || "";
  });

  const setMode = (m: UserMode) => {
    setModeState(m);
    sessionStorage.setItem(SESSION_KEY, m);
  };

  const setAdminPassword = (pw: string) => {
    setAdminPasswordState(pw);
    sessionStorage.setItem(PASSWORD_KEY, pw);
  };

  const setSubjectFilter = (s: string) => {
    setSubjectFilterState(s);
    sessionStorage.setItem(SUBJECT_KEY, s);
  };

  const logout = () => {
    setModeState("portal");
    setAdminPasswordState("");
    setSubjectFilterState("");
    sessionStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(PASSWORD_KEY);
    sessionStorage.removeItem(SUBJECT_KEY);
  };

  return (
    <AdminAuthContext.Provider
      value={{ mode, setMode, adminPassword, setAdminPassword, subjectFilter, setSubjectFilter, logout }}
    >
      {children}
    </AdminAuthContext.Provider>
  );
}

export function useAdminAuth() {
  const ctx = useContext(AdminAuthContext);
  if (!ctx) throw new Error("useAdminAuth must be used within AdminAuthProvider");
  return ctx;
}
