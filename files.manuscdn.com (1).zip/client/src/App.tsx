import { useEffect } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import TeachersPage from "./pages/Teachers";
import AbsencePage from "./pages/Absence";
import DailyReportPage from "./pages/DailyReport";
import StatisticsPage from "./pages/Statistics";
import ImportPage from "./pages/Import";
import SpecializationPage from "./pages/Specialization";
import RotationQueuePage from "./pages/RotationQueue";
import TeacherScheduleEditorPage from "./pages/TeacherScheduleEditor";
import SpecialtyDomainsPage from "./pages/SpecialtyDomains";
import SchoolSettingsPage from "./pages/SchoolSettings";
import SubjectHeadsPage from "./pages/SubjectHeads";
import EmergencyPanelPage from "./pages/EmergencyPanel";
import MainLayout from "./components/MainLayout";
import TeacherLayout from "./components/TeacherLayout";
import Portal from "./pages/Portal";
import TeacherDailyReportPage from "./pages/TeacherDailyReport";
import TeacherStatisticsPage from "./pages/TeacherStatistics";
import HeadTeacherPage from "./pages/HeadTeacher";
import { AdminAuthProvider, useAdminAuth } from "./contexts/AdminAuthContext";

function TeacherRedirect() {
  const [, setLocation] = useLocation();
  useEffect(() => {
    setLocation("/teacher/daily-report");
  }, [setLocation]);
  return null;
}

function Router() {
  const { mode } = useAdminAuth();

  // بوابة الدخول
  if (mode === "portal") {
    return <Portal />;
  }

  // واجهة المعلم الأول
  if (mode === "head_teacher") {
    return <HeadTeacherPage />;
  }

  // واجهة المعلمين (قراءة فقط)
  if (mode === "teacher") {
    return (
      <TeacherLayout>
        <Switch>
          <Route path="/" component={TeacherRedirect} />
          <Route path="/teacher/daily-report" component={TeacherDailyReportPage} />
          <Route path="/teacher/statistics" component={TeacherStatisticsPage} />
          <Route component={TeacherDailyReportPage} />
        </Switch>
      </TeacherLayout>
    );
  }

  // واجهة الإدارة (صلاحيات كاملة)
  return (
    <MainLayout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/teachers" component={TeachersPage} />
        <Route path="/absence" component={AbsencePage} />
        <Route path="/daily-report" component={DailyReportPage} />
        <Route path="/statistics" component={StatisticsPage} />
        <Route path="/import" component={ImportPage} />
        <Route path="/specialization" component={SpecializationPage} />
        <Route path="/rotation-queue" component={RotationQueuePage} />
        <Route path="/teacher-schedule/:id" component={TeacherScheduleEditorPage} />
        <Route path="/specialty-domains" component={SpecialtyDomainsPage} />
        <Route path="/school-settings" component={SchoolSettingsPage} />
        <Route path="/subject-heads" component={SubjectHeadsPage} />
        <Route path="/emergency" component={EmergencyPanelPage} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </MainLayout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster position="top-center" richColors />
          <AdminAuthProvider>
            <Router />
          </AdminAuthProvider>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
