import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { FileText, Printer, UserX, ChevronDown, ChevronUp, GraduationCap, Pencil, Check } from "lucide-react";
import { toast } from "sonner";

const monthNames = [
  "يناير","فبراير","مارس","أبريل","مايو","يونيو",
  "يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"
];

export default function DailyReportPage() {
  const today = new Date().toISOString().split("T")[0];
  const [selectedDate, setSelectedDate] = useState(today);
  const [expandedAbsence, setExpandedAbsence] = useState<number | null>(null);
  const [editDialog, setEditDialog] = useState<{
    open: boolean;
    assignmentId: number;
    periodNumber: number;
    subjectName: string;
    currentTeacherName: string;
  } | null>(null);
  const [teacherSearch, setTeacherSearch] = useState("");
  const [selectedNewTeacherId, setSelectedNewTeacherId] = useState<number | null>(null);

  const utils = trpc.useUtils();
  const { data: report, isLoading } = trpc.stats.dailyReport.useQuery({ date: selectedDate });
  const { data: allTeachers } = trpc.teachers.list.useQuery();

  const [conflictError, setConflictError] = useState<string | null>(null);
  const [pendingOverride, setPendingOverride] = useState<{ assignmentId: number; newSubstituteTeacherId: number; forceOverride?: boolean } | null>(null);
  const updateSubstitute = trpc.stats.updateSubstituteTeacher.useMutation({
    onSuccess: () => {
      utils.stats.dailyReport.invalidate();
      setEditDialog(null);
      setSelectedNewTeacherId(null);
      setTeacherSearch("");
      setConflictError(null);
      setPendingOverride(null);
      toast.success("تم التعديل بنجاح", { description: "تم تغيير المعلم البديل" });
    },
    onError: (err) => {
      const msg = err.message || "تعذّر تعديل المعلم البديل";
      // إذا كان الخطأ بسبب تعارض جدول، نعرض خيار التجاوز
      if (msg.includes("جدوله يُظهر حصة أساسية") || msg.includes("مستثنى من الاحتياط")) {
        setConflictError(msg);
        if (editDialog && selectedNewTeacherId) {
          setPendingOverride({ assignmentId: editDialog.assignmentId, newSubstituteTeacherId: selectedNewTeacherId });
        }
      } else {
        toast.error("خطأ", { description: msg });
      }
    },
  });

  const dateObj = new Date(selectedDate);
  const dayOfWeek = ["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"][dateObj.getDay()];
  const formattedDate = `يوم ${dayOfWeek} ${dateObj.getDate()} ${monthNames[dateObj.getMonth()]} ${dateObj.getFullYear()}م`;

  // بناء جدول موحد لجميع الغائبين للطباعة
  const allAssignments = (report || []).flatMap((item: any) => {
    let partialPeriods: number[] = [];
    try { partialPeriods = item.absence?.partialPeriods ? JSON.parse(item.absence.partialPeriods) : []; } catch {}
    const isPartial = partialPeriods.length > 0;
    return (item.assignments || []).map((a: any) => ({
      ...a,
      absentTeacherName: item.absentTeacher?.name || "—",
      absenceReason: item.absence?.reason || "",
      isPartial,
      partialPeriods,
    }));
  }).sort((a: any, b: any) => a.periodNumber - b.periodNumber);

  const totalAssignments = (report || []).reduce(
    (sum: number, item: any) => sum + (item.assignments?.length || 0), 0
  );

  const handlePrint = () => window.print();

  // ===== تحميل PDF من server-side مع معالجة النصوص العربية =====
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const handleDownloadPdf = async () => {
    if (!report || report.length === 0) return;
    setIsGeneratingPdf(true);
    try {
      const payload = {
        schoolName: "مدرسة الخوير للتعليم الأساسي (5-9)",
        dayOfWeek,
        date: formattedDate,
        totalAssignments,
        absentCount: (report || []).length,
        assignments: allAssignments.map((a: any) => ({
          periodNumber: a.periodNumber,
          className: a.className,
          substituteTeacherName: a.substituteTeacher?.name || a.substituteTeacherName || "",
          isSpecialtyMatch: a.isSpecialtyMatch,
          absentTeacherName: a.absentTeacherName,
          constraintBreakLevel: a.constraintBreakLevel || 0,
          constraintBreakReason: a.constraintBreakReason || "",
          isPartial: a.isPartial,
          partialPeriods: a.partialPeriods || [],
        })),
      };
      const res = await fetch('/api/generate-pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'فشل توليد PDF');
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = `توزيع-الاحتياط-${selectedDate}.pdf`;
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
      URL.revokeObjectURL(url);
      toast.success('تم تحميل PDF بنجاح');
    } catch (err: any) {
      toast.error('خطأ في توليد PDF', { description: err.message });
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // فلتر أسماء الفصول: إزالة كلمة "أساسي" لتوفير المساحة في الطباعة
  const filterClassName = (name: string | null | undefined): string => {
    if (!name) return "—";
    let result = name;
    // إزالة كلمة أساسي
    result = result
      .replace(/\s*\/\s*أساسي\s*/g, " / ")
      .replace(/أساسي\s*\/\s*/g, "")
      .replace(/\bأساسي\b/g, "");
    // معالجة نمط بوساح (حاسوب مقلوب): "بوساح 2 الخامس" → "الخامس"
    if (/بوساح|حاسوب/i.test(result)) {
      const gradeMatch = result.match(/(الخامس|السادس|السابع|الثامن|التاسع|الرابع|الثالث|الثاني|الأول)(?:\s*\/\s*(\d+))?/i);
      if (gradeMatch) {
        result = gradeMatch[1] + (gradeMatch[2] ? ` / ${gradeMatch[2]}` : "");
      }
    }
    return result.replace(/\s{2,}/g, " ").trim() || "—";
  };

  const filteredTeachers = (allTeachers || []).filter((t: any) =>
    t.name.includes(teacherSearch) || teacherSearch === ""
  );

  return (
    <div className="space-y-5" dir="rtl">
      {/* Header - مخفي عند الطباعة */}
      <div className="flex items-center justify-between no-print">
        <div>
          <h2 className="text-xl font-bold" style={{ color: "oklch(0.25 0.06 145)" }}>
            جدول الاحتياط اليومي
          </h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            عرض وطباعة توزيع الاحتياط لأي يوم
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={handleDownloadPdf}
            className="gap-2 text-sm no-print"
            style={{ background: "oklch(0.28 0.14 260)", color: "white" }}
            disabled={!report || report.length === 0 || isGeneratingPdf}
          >
            <FileText size={15} />
            {isGeneratingPdf ? "جاري توليد PDF..." : "تحميل PDF"}
          </Button>
          <Button
            onClick={handlePrint}
            className="gap-2 text-sm no-print"
            style={{ background: "oklch(0.32 0.11 145)", color: "white" }}
            disabled={!report || report.length === 0}
          >
            <Printer size={15} />
            طباعة جدول اليوم
          </Button>
        </div>
      </div>

      {/* Date picker - مخفي عند الطباعة */}
      <div className="no-print">
        <Input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          className="max-w-xs text-sm"
        />
      </div>

      {/* ===== منطقة الطباعة الرسمية ===== */}
      <div id="print-area">

        {/* رأس الطباعة الرسمي */}
        <div className="print-header-official hidden-screen">
          <div className="print-header-top">
            <div className="print-header-right">
              <p className="print-ministry">سلطنة عُمان - وزارة التعليم</p>
              <p className="print-directorate">المديرية العامة للتعليم بمسقط</p>
              <h1 className="print-school">مدرسة الخوير للتعليم الأساسي (5-9)</h1>
            </div>
            <div className="print-header-center">
              <div className="print-logo-circle">
                <span className="print-logo-text">م</span>
              </div>
            </div>
            <div className="print-header-left">
              <p className="print-doc-title">جدول توزيع الاحتياط اليومي</p>
              <p className="print-doc-date">يوم: <strong>{dayOfWeek}</strong></p>
              <p className="print-doc-date">التاريخ: <strong>{formattedDate}</strong></p>
              <p className="print-doc-total">إجمالي الحصص: <strong>{totalAssignments}</strong></p>
            </div>
          </div>
          <div className="print-header-divider"></div>
        </div>

        {/* الرأس المرئي على الشاشة */}
        <div className="rounded-2xl overflow-hidden shadow-md mb-5 no-print"
          style={{ background: "linear-gradient(135deg, oklch(0.18 0.07 145) 0%, oklch(0.28 0.09 145) 100%)" }}>
          <div className="px-6 py-6 text-center">
            <p className="text-xs font-semibold mb-1" style={{ color: "oklch(0.75 0.13 75)" }}>
              سلطنة عُمان - وزارة التعليم
            </p>
            <p className="text-xs mb-2" style={{ color: "oklch(0.8 0.01 120)" }}>
              المديرية العامة للتعليم بمسقط
            </p>
            <h1 className="text-lg font-bold mb-1" style={{ color: "oklch(0.95 0.01 120)" }}>
              مدرسة الخوير للتعليم الأساسي (5-9)
            </h1>
            <h2 className="text-base font-semibold" style={{ color: "oklch(0.75 0.13 75)" }}>
              جدول توزيع احتياط المعلمين
            </h2>
            <div className="mt-3 flex items-center justify-center gap-6 text-sm"
              style={{ color: "oklch(0.85 0.01 120)" }}>
              <span>يوم: <strong style={{ color: "oklch(0.75 0.13 75)" }}>{dayOfWeek}</strong></span>
              <span>التاريخ: <strong style={{ color: "oklch(0.75 0.13 75)" }}>{formattedDate}</strong></span>
            </div>
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-3 no-print">
            {[...Array(2)].map((_, i) => (
              <div key={i} className="h-32 rounded-xl animate-pulse bg-muted" />
            ))}
          </div>
        ) : !report || report.length === 0 ? (
          <Card className="border-0 shadow-sm no-print">
            <CardContent className="py-12 text-center">
              <FileText size={40} className="mx-auto mb-3 text-muted-foreground" />
              <p className="text-muted-foreground">لا يوجد غياب مسجل لهذا اليوم</p>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* ===== جدول الطباعة الموحد (يظهر فقط عند الطباعة) ===== */}
            <div className="print-unified-table hidden-screen">
              <table className="print-table">
                <thead>
                  <tr>
                    <th className="print-th print-th-center" style={{ width: "4%" }}>#</th>
                    <th className="print-th print-th-center" style={{ width: "8%" }}>حصة الاحتياط</th>
                    <th className="print-th print-th-center" style={{ width: "10%" }}>الفصل</th>
                    <th className="print-th" style={{ width: "28%" }}>معلم الاحتياط</th>
                    <th className="print-th print-th-center" style={{ width: "10%" }}>التخصص</th>
                    <th className="print-th" style={{ width: "20%" }}>المعلم الغائب</th>
                    <th className="print-th print-th-center" style={{ width: "20%" }}>الملاحظة</th>
                  </tr>
                </thead>
                <tbody>
                  {allAssignments.map((a: any, idx: number) => {
                    const isBreak = (a.constraintBreakLevel || 0) > 0;
                    const rowStyle = isBreak
                      ? { background: a.constraintBreakLevel >= 4 ? "#ffcccc" : "#fff3cd" }
                      : {};
                    // بناء ملاحظة الغياب الجزئي
                    const partialNote = a.isPartial
                      ? `غائب جزئي (${(a.partialPeriods as number[]).sort((x:number,y:number)=>x-y).map((p:number)=>`ح${p}`).join("،")})`
                      : "";
                    const note = [partialNote, a.constraintBreakReason || ""].filter(Boolean).join(" | ");
                    return (
                      <tr key={idx} className={idx % 2 === 0 ? "print-row-even" : "print-row-odd"} style={rowStyle}>
                        <td className="print-td print-td-center">{idx + 1}</td>
                        <td className="print-td print-td-center">
                          <span className="print-period-badge">{a.periodNumber}</span>
                        </td>
                        <td className="print-td print-td-center">{filterClassName(a.className)}</td>
                        <td className="print-td print-td-green">{a.substituteTeacher?.name || `معلم #${a.substituteTeacherId}`}</td>
                        <td className="print-td print-td-center">
                          {a.isSpecialtyMatch ? "✓ تخصص" : "—"}
                        </td>
                        <td className="print-td">{a.absentTeacherName}</td>
                        <td className="print-td print-td-center" style={isBreak || a.isPartial ? { color: "#6a0dad", fontWeight: 600, fontSize: "0.7rem" } : {}}>
                          {note || "—"}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr>
                    <td colSpan={7} className="print-tfoot">
                      إجمالي الحصص الموزعة: <strong>{totalAssignments} حصة</strong>
                      {" | "}
                      عدد المعلمين الغائبين: <strong>{report.length} معلم</strong>
                    </td>
                  </tr>
                </tfoot>
              </table>

              {/* خانة الاعتماد */}
              <div className="print-approval-section">
                <div className="print-approval-box">
                  <p className="print-approval-title">اعتماد مدير المدرسة</p>
                  <div className="print-approval-space"></div>
                  <p className="print-approval-label">التوقيع: ________________</p>
                  <p className="print-approval-label">التاريخ: ________________</p>
                </div>
                <div className="print-approval-box">
                  <p className="print-approval-title">اعتماد الوكيل الأكاديمي</p>
                  <div className="print-approval-space"></div>
                  <p className="print-approval-label">التوقيع: ________________</p>
                  <p className="print-approval-label">التاريخ: ________________</p>
                </div>
                <div className="print-approval-box">
                  <p className="print-approval-title">ملاحظات</p>
                  <div className="print-approval-space"></div>
                  <div className="print-approval-lines">
                    <div className="print-line"></div>
                    <div className="print-line"></div>
                    <div className="print-line"></div>
                  </div>
                </div>
              </div>
            </div>

            {/* ===== عرض الشاشة (البطاقات) ===== */}
            <div className="space-y-4 no-print">
              {report.map((item: any, idx: number) => (
                <Card key={idx} className="border shadow-sm overflow-hidden">
                  <CardHeader
                    className="pb-0 cursor-pointer"
                    onClick={() => setExpandedAbsence(expandedAbsence === idx ? null : idx)}
                  >
                    <div className="flex items-center justify-between py-1">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold"
                          style={{ background: "oklch(0.55 0.2 25)" }}>
                          <UserX size={18} />
                        </div>
                        <div>
                          <p className="font-bold text-base text-foreground flex items-center gap-2 flex-wrap">
                            المعلم الغائب: {item.absentTeacher?.name || "—"}
                            {(() => {
                              let pp: number[] = [];
                              try { pp = item.absence?.partialPeriods ? JSON.parse(item.absence.partialPeriods) : []; } catch {}
                              return pp.length > 0 ? (
                                <span className="text-xs font-bold px-2 py-0.5 rounded-full" style={{ background: "oklch(0.88 0.08 280)", color: "oklch(0.35 0.15 280)" }}>
                                  غائب جزئي: {pp.sort((a:number,b:number)=>a-b).map((p:number) => `ح${p}`).join("،")}
                                </span>
                              ) : null;
                            })()}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {item.assignments?.length || 0} حصة تم توزيعها
                            {item.absence?.reason && ` • ${item.absence.reason}`}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge style={{ background: "oklch(0.32 0.11 145)", color: "white" }}>
                          {item.assignments?.length || 0} حصة
                        </Badge>
                        {expandedAbsence === idx ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                      </div>
                    </div>
                  </CardHeader>
                  {(expandedAbsence === idx || true) && (
                    <CardContent className="pt-3">
                      {item.assignments && item.assignments.length > 0 ? (
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr style={{ background: "oklch(0.94 0.02 145)" }}>
                                <th className="px-4 py-2 text-right font-semibold text-xs rounded-r-lg"
                                  style={{ color: "oklch(0.25 0.06 145)" }}>رقم الحصة</th>
                                <th className="px-4 py-2 text-right font-semibold text-xs"
                                  style={{ color: "oklch(0.25 0.06 145)" }}>الصف والشعبة</th>
                                <th className="px-4 py-2 text-right font-semibold text-xs"
                                  style={{ color: "oklch(0.25 0.06 145)" }}>المعلم البديل</th>
                                <th className="px-4 py-2 text-center font-semibold text-xs"
                                  style={{ color: "oklch(0.25 0.06 145)" }}>التخصص</th>
                                <th className="px-4 py-2 text-center font-semibold text-xs"
                                  style={{ color: "oklch(0.25 0.06 145)" }}>ملاحظة</th>
                                <th className="px-4 py-2 text-center font-semibold text-xs rounded-l-lg"
                                  style={{ color: "oklch(0.25 0.06 145)" }}>تعديل</th>
                              </tr>
                            </thead>
                            <tbody>
                              {item.assignments
                                .sort((a: any, b: any) => a.periodNumber - b.periodNumber)
                                .map((assignment: any, aIdx: number) => {
                                  const isBreak = (assignment.constraintBreakLevel || 0) > 0;
                                  const breakBg = isBreak
                                    ? (assignment.constraintBreakLevel >= 4 ? "#fff0f0" : "#fffbea")
                                    : (aIdx % 2 === 0 ? "oklch(0.99 0.005 120)" : "white");
                                  return (
                                  <tr key={aIdx} style={{ background: breakBg }}>
                                    <td className="px-4 py-2.5 text-center">
                                      <span className="inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold text-white"
                                        style={{ background: isBreak ? (assignment.constraintBreakLevel >= 4 ? "#e74c3c" : "#f39c12") : "oklch(0.32 0.11 145)" }}>
                                        {assignment.periodNumber}
                                      </span>
                                    </td>
                                    <td className="px-4 py-2.5 text-sm font-semibold">{filterClassName(assignment.className)}</td>
                                    <td className="px-4 py-2.5">
                                      <span className="font-semibold text-sm"
                                        style={{ color: isBreak ? (assignment.constraintBreakLevel >= 4 ? "#c0392b" : "#d68910") : "oklch(0.32 0.11 145)" }}>
                                        {assignment.substituteTeacher?.name || `معلم #${assignment.substituteTeacherId}`}
                                      </span>
                                    </td>
                                    <td className="px-4 py-2.5 text-center">
                                      {assignment.isSpecialtyMatch ? (
                                        <span
                                          title="توزيع حسب التخصص"
                                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold"
                                          style={{ background: "oklch(0.92 0.12 250)", color: "oklch(0.28 0.15 250)" }}
                                        >
                                          <GraduationCap size={12} />
                                          تخصص
                                        </span>
                                      ) : (
                                        <span className="text-muted-foreground text-xs">—</span>
                                      )}
                                    </td>
                                    <td className="px-4 py-2.5 text-center">
                                      {isBreak ? (
                                        <span
                                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold"
                                          style={{
                                            background: assignment.constraintBreakLevel >= 4 ? "#fde8e8" : "#fef9e7",
                                            color: assignment.constraintBreakLevel >= 4 ? "#c0392b" : "#d68910",
                                            border: `1px solid ${assignment.constraintBreakLevel >= 4 ? "#e74c3c" : "#f39c12"}`
                                          }}
                                          title={assignment.constraintBreakReason || ""}
                                        >
                                          ⚠️ {assignment.constraintBreakReason || "كسر قيد"}
                                        </span>
                                      ) : (
                                        <span className="text-muted-foreground text-xs">—</span>
                                      )}
                                    </td>
                                    <td className="px-4 py-2.5 text-center">
                                      <Button
                                        size="sm"
                                        variant="ghost"
                                        className="h-7 w-7 p-0 hover:bg-amber-50"
                                        title="تعديل المعلم البديل"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setEditDialog({
                                            open: true,
                                            assignmentId: assignment.id,
                                            periodNumber: assignment.periodNumber,
                                            subjectName: assignment.subjectName || "",
                                            currentTeacherName: assignment.substituteTeacher?.name || "",
                                          });
                                          setTeacherSearch("");
                                          setSelectedNewTeacherId(null);
                                        }}
                                      >
                                        <Pencil size={14} className="text-amber-600" />
                                      </Button>
                                    </td>
                                  </tr>
                                  );
                                })}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground text-center py-4">
                          لا توجد حصص في جدول هذا المعلم لهذا اليوم
                        </p>
                      )}
                    </CardContent>
                  )}
                </Card>
              ))}

              {/* Summary */}
              <Card className="border-0 shadow-sm"
                style={{ background: "oklch(0.97 0.02 145)" }}>
                <CardContent className="py-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-semibold" style={{ color: "oklch(0.25 0.06 145)" }}>
                      إجمالي الحصص الموزعة:
                    </span>
                    <span className="text-xl font-bold" style={{ color: "oklch(0.32 0.11 145)" }}>
                      {totalAssignments} حصة
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>

      {/* Edit Substitute Dialog */}
      <Dialog open={!!editDialog?.open} onOpenChange={(open) => !open && setEditDialog(null)}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-right">تعديل المعلم البديل</DialogTitle>
          </DialogHeader>
          {editDialog && (
            <div className="space-y-4">
              <div className="rounded-lg p-3 text-sm space-y-1"
                style={{ background: "oklch(0.96 0.02 145)" }}>
                <p><span className="text-muted-foreground">الحصة:</span> <strong>{editDialog.periodNumber}</strong></p>
                <p><span className="text-muted-foreground">المادة:</span> <strong>{editDialog.subjectName || "—"}</strong></p>
                <p><span className="text-muted-foreground">البديل الحالي:</span> <strong style={{ color: "oklch(0.32 0.11 145)" }}>{editDialog.currentTeacherName}</strong></p>
              </div>
              <div>
                <p className="text-sm font-medium mb-2">اختر المعلم البديل الجديد:</p>
                <Command className="border rounded-lg">
                  <CommandInput
                    placeholder="ابحث باسم المعلم..."
                    value={teacherSearch}
                    onValueChange={setTeacherSearch}
                  />
                  <CommandList className="max-h-52">
                    <CommandEmpty>لا يوجد معلم بهذا الاسم</CommandEmpty>
                    <CommandGroup>
                      {filteredTeachers.map((t: any) => (
                        <CommandItem
                          key={t.id}
                          value={t.name}
                          onSelect={() => setSelectedNewTeacherId(t.id)}
                          className="cursor-pointer"
                        >
                          <div className="flex items-center justify-between w-full">
                            <span className="text-sm">{t.name}</span>
                            {selectedNewTeacherId === t.id && (
                              <Check size={14} className="text-green-600" />
                            )}
                          </div>
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </div>
              {selectedNewTeacherId && (
                <div className="rounded-lg p-2 text-sm text-center"
                  style={{ background: "oklch(0.93 0.08 145)", color: "oklch(0.25 0.06 145)" }}>
                  البديل الجديد: <strong>
                    {allTeachers?.find((t: any) => t.id === selectedNewTeacherId)?.name}
                  </strong>
                </div>
              )}
            </div>
          )}
          {conflictError && (
            <div className="mx-4 mb-2 p-3 rounded-lg bg-red-50 border border-red-200 text-red-800 text-sm">
              <div className="font-bold mb-1">⚠️ تعارض في الجدول</div>
              <div className="mb-2">{conflictError}</div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => {
                    if (pendingOverride) {
                      updateSubstitute.mutate({ ...pendingOverride, forceOverride: true } as any);
                    }
                  }}
                >
                  تجاوز التعارض وحفظ
                </Button>
                <Button size="sm" variant="outline" onClick={() => { setConflictError(null); setPendingOverride(null); }}>
                  إلغاء
                </Button>
              </div>
            </div>
          )}
          <DialogFooter className="gap-2 flex-row-reverse">
            <Button
              disabled={!selectedNewTeacherId || updateSubstitute.isPending}
              onClick={() => {
                if (editDialog && selectedNewTeacherId) {
                  setConflictError(null);
                  setPendingOverride(null);
                  updateSubstitute.mutate({
                    assignmentId: editDialog.assignmentId,
                    newSubstituteTeacherId: selectedNewTeacherId,
                  });
                }
              }}
              style={{ background: "oklch(0.32 0.11 145)", color: "white" }}
            >
              {updateSubstitute.isPending ? "جاري الحفظ..." : "حفظ التعديل"}
            </Button>
            <Button variant="outline" onClick={() => { setEditDialog(null); setConflictError(null); setPendingOverride(null); }}>
              إلغاء
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== أنماط الطباعة ===== */}
      <style>{`
        /* ============================================================
           إعدادات الطباعة - تحسينات احترافية شاملة
           ============================================================ */
        @media print {
          /* A4 أفقي مع هوامش متوازنة */
          @page {
            size: A4 landscape;
            margin: 8mm 10mm;
          }

          /* إخفاء كل شيء عدا منطقة الطباعة */
          body > *:not(#root) { display: none !important; }
          body * { visibility: hidden !important; }
          #print-area, #print-area * { visibility: visible !important; }

          /* إصلاح رئيسي: إزالة position:fixed الذي يقطع البيانات عند تجاوز صفحة واحدة */
          #print-area {
            position: absolute !important;
            top: 0 !important;
            left: 0 !important;
            right: 0 !important;
            width: 100% !important;
            background: white !important;
          }

          .hidden-screen {
            display: block !important;
            visibility: visible !important;
          }

          .no-print {
            display: none !important;
            visibility: hidden !important;
          }

          /* خط Cairo العربي مع دعم RTL كامل */
          html, body {
            background: white !important;
            font-family: 'Cairo', 'Arial', 'Segoe UI', sans-serif !important;
            font-size: 11px !important;
            direction: rtl !important;
            unicode-bidi: bidi-override;
            width: 100% !important;
            height: auto !important;
            overflow: visible !important;
            margin: 0 !important;
            padding: 0 !important;
          }

          /* تكرار رؤوس الجدول في كل صفحة */
          .print-table thead {
            display: table-header-group !important;
          }
          .print-table tfoot {
            display: table-footer-group !important;
          }
          .print-table tbody tr {
            page-break-inside: avoid;
          }

          /* منع قطع خانة الاعتماد بين صفحتين */
          .print-approval-section {
            page-break-inside: avoid;
          }
        }

        /* إخفاء عناصر الطباعة على الشاشة */
        @media screen {
          .hidden-screen { display: none !important; }
        }

        /* ============================================================
           تنسيقات الطباعة - خط Cairo ودعم RTL كامل
           ============================================================ */

        /* كل عنصر في منطقة الطباعة يرث الخط والاتجاه */
        #print-area * {
          font-family: 'Cairo', 'Arial', 'Segoe UI', sans-serif !important;
          direction: rtl;
          unicode-bidi: embed;
        }

        .print-header-official {
          margin-bottom: 6mm;
          border-bottom: 2px solid #1a5c2a;
          padding-bottom: 4mm;
        }

        .print-header-top {
          display: flex !important;
          justify-content: space-between;
          align-items: center;
          direction: rtl;
          unicode-bidi: bidi-override;
        }

        .print-header-right {
          text-align: right;
          flex: 1;
          direction: rtl;
        }

        .print-ministry {
          font-size: 10px;
          color: #555;
          margin: 0 0 1mm 0;
          direction: rtl;
          unicode-bidi: embed;
        }

        .print-directorate {
          font-size: 10px;
          color: #555;
          margin: 0 0 2mm 0;
          direction: rtl;
          unicode-bidi: embed;
        }

        .print-school {
          font-size: 14px;
          font-weight: 800;
          color: #1a5c2a;
          margin: 0;
          direction: rtl;
          unicode-bidi: embed;
        }

        .print-header-center {
          flex: 0 0 auto;
          text-align: center;
          padding: 0 8mm;
        }

        .print-logo-circle {
          width: 18mm;
          height: 18mm;
          border-radius: 50%;
          background: #1a5c2a;
          display: flex !important;
          align-items: center;
          justify-content: center;
          margin: 0 auto;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }

        .print-logo-text {
          color: white;
          font-size: 20px;
          font-weight: 800;
        }

        .print-header-left {
          text-align: center;
          flex: 1;
          direction: rtl;
        }

        .print-doc-title {
          font-size: 13px;
          font-weight: 800;
          color: #1a5c2a;
          margin: 0 0 2mm 0;
          text-align: center;
          direction: rtl;
          unicode-bidi: embed;
        }

        .print-doc-date {
          font-size: 10px;
          color: #333;
          margin: 0 0 1mm 0;
          text-align: center;
          direction: rtl;
          unicode-bidi: embed;
        }

        .print-doc-total {
          font-size: 10px;
          color: #1a5c2a;
          font-weight: 700;
          text-align: center;
          margin-top: 2mm;
          direction: rtl;
          unicode-bidi: embed;
        }

        .print-header-divider {
          height: 1px;
          background: #1a5c2a;
          margin-top: 3mm;
        }

        /* ===== جدول الطباعة - ضبط الأبعاد للتناسب مع A4 أفقي ===== */
        .print-unified-table {
          width: 100%;
          overflow: hidden;
        }

        .print-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 10px;
          direction: rtl;
          unicode-bidi: bidi-override;
          /* ضمان عدم خروج الجدول عن حدود الصفحة */
          table-layout: fixed;
        }

        /* عروض الأعمدة المحسوبة لصفحة A4 أفقي (277mm عرض قابل للطباعة) */
        .print-table th:nth-child(1) { width: 6%; }   /* # */
        .print-table th:nth-child(2) { width: 9%; }   /* حصة الاحتياط */
        .print-table th:nth-child(3) { width: 13%; }  /* الفصل (بدون أساسي) */
        .print-table th:nth-child(4) { width: 34%; }  /* معلم الاحتياط */
        .print-table th:nth-child(5) { width: 11%; }  /* التخصص */
        .print-table th:nth-child(6) { width: 27%; }  /* الملاحظة */

        .print-th {
          background: #1a5c2a !important;
          color: white !important;
          padding: 3mm 3mm;
          text-align: right;
          font-weight: 700;
          font-size: 10px;
          border: 1px solid #0d3d1a;
          direction: rtl;
          unicode-bidi: embed;
          overflow: hidden;
          white-space: nowrap;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }

        .print-th-center {
          text-align: center !important;
        }

        .print-td {
          padding: 2mm 3mm;
          border: 1px solid #ccc;
          font-size: 10px;
          vertical-align: middle;
          direction: rtl;
          unicode-bidi: embed;
          overflow: hidden;
          word-wrap: break-word;
          word-break: break-word;
        }

        .print-td-center {
          text-align: center;
        }

        .print-td-bold {
          font-weight: 700;
          color: #333;
        }

        .print-td-green {
          font-weight: 700;
          color: #1a5c2a;
        }

        .print-row-even {
          background: #f5faf5 !important;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }

        .print-row-odd {
          background: white !important;
        }

        /* شارة رقم الحصة */
        .print-period-badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 6mm;
          height: 6mm;
          border-radius: 50%;
          background: #1a5c2a !important;
          color: white !important;
          font-weight: 700;
          font-size: 10px;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }

        .print-tfoot {
          padding: 2mm 3mm;
          text-align: center;
          background: #e8f5e9 !important;
          font-size: 10px;
          border: 1px solid #ccc;
          direction: rtl;
          unicode-bidi: embed;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }

        /* خانة الاعتماد */
        .print-approval-section {
          display: flex !important;
          justify-content: space-between;
          margin-top: 6mm;
          gap: 5mm;
          direction: rtl;
          unicode-bidi: bidi-override;
        }

        .print-approval-box {
          flex: 1;
          border: 1px solid #1a5c2a;
          border-radius: 2mm;
          padding: 3mm;
          min-height: 22mm;
        }

        .print-approval-title {
          font-size: 10px;
          font-weight: 700;
          color: #1a5c2a;
          text-align: center;
          margin: 0 0 2mm 0;
          border-bottom: 1px solid #1a5c2a;
          padding-bottom: 1mm;
          direction: rtl;
          unicode-bidi: embed;
        }

        .print-approval-space {
          height: 8mm;
        }

        .print-approval-label {
          font-size: 9px;
          color: #555;
          margin: 1mm 0;
          direction: rtl;
          unicode-bidi: embed;
        }

        .print-approval-lines {
          margin-top: 2mm;
        }

        .print-line {
          border-bottom: 1px solid #ccc;
          margin: 3mm 0;
        }
      `}</style>
    </div>
  );
}
