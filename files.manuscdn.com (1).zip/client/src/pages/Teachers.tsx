import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import {
  Users, Plus, Trash2, ShieldOff, Shield, Search, BookOpen,
  Pencil, CalendarDays, ShieldAlert, ShieldCheck, Clock, SquarePen
} from "lucide-react";

const today = new Date().toISOString().split("T")[0];

const DAY_LABELS: Record<string, string> = {
  Sunday: "الأحد",
  Monday: "الاثنين",
  Tuesday: "الثلاثاء",
  Wednesday: "الأربعاء",
  Thursday: "الخميس",
};

const DAY_ORDER = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"];
const ALL_DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"] as const;
type DayOfWeek = typeof ALL_DAYS[number];

// تلخيص الاستثناء الجزئي لعرضه في البطاقة
function summarizePartialExemption(exemptDays: string[], exemptPeriods: number[]): string {
  if (exemptDays.length === 0) return "";
  const allDays = exemptDays.length === 5;
  const daysLabel = allDays
    ? "يومياً"
    : exemptDays.map((d) => DAY_LABELS[d] || d).join("، ");
  if (exemptPeriods.length === 0) {
    return `مستثنى ${daysLabel}`;
  }
  const periodsLabel = exemptPeriods.map((p) => `ح${p}`).join("، ");
  return `مستثنى ${periodsLabel} ${daysLabel}`;
}

export default function TeachersPage() {
  const utils = trpc.useUtils();
  const [, navigate] = useLocation();
  const { data: teachers, isLoading } = trpc.teachers.list.useQuery();
  const { data: exemptions } = trpc.exemptions.getByDate.useQuery({ date: today });
  const { data: partialExemptions } = trpc.teachers.getPartialExemptions.useQuery();

  const [search, setSearch] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [newTeacher, setNewTeacher] = useState({ name: "", shortName: "", weeklyLoad: "" });

  // حالة تعديل النصاب
  const [editLoadTeacher, setEditLoadTeacher] = useState<{ id: number; name: string; weeklyLoad: number; monthlyCapacity: number; individualCap: number } | null>(null);
  const [editLoadValue, setEditLoadValue] = useState("");
  const [editCapacityValue, setEditCapacityValue] = useState("");
  const [editIndividualCapValue, setEditIndividualCapValue] = useState("");

  // حالة عرض الجدول
  const [scheduleTeacherId, setScheduleTeacherId] = useState<number | null>(null);
  const [scheduleTeacherName, setScheduleTeacherName] = useState("");

  // حالة إدارة الاستثناء الجزئي
  const [partialExemptTeacher, setPartialExemptTeacher] = useState<{ id: number; name: string } | null>(null);
  const [partialDays, setPartialDays] = useState<DayOfWeek[]>([]);
  const [partialPeriods, setPartialPeriods] = useState<number[]>([]);
  const [partialReason, setPartialReason] = useState("");

  const exemptedIds = new Set(exemptions?.map((e: any) => e.teacherId) || []);

  // خريطة الاستثناءات الجزئية
  const partialExemptMap = new Map<number, { exemptDays: string[]; exemptPeriods: number[] }>();
  if (partialExemptions) {
    for (const pe of partialExemptions) {
      try {
        partialExemptMap.set(pe.teacherId, {
          exemptDays: JSON.parse(pe.exemptDays || "[]"),
          exemptPeriods: JSON.parse(pe.exemptPeriods || "[]"),
        });
      } catch {}
    }
  }

  // mutation لتغيير الاستثناء الدائم
  const togglePermanentExemptMutation = trpc.teachers.update.useMutation({
    onSuccess: () => {
      utils.teachers.list.invalidate();
      toast.success("تم تحديث حالة الاستثناء الدائم");
    },
    onError: () => toast.error("حدث خطأ أثناء التحديث"),
  });

  const handleTogglePermanentExemption = (teacher: any) => {
    togglePermanentExemptMutation.mutate({
      id: teacher.id,
      isExemptFromSubstitute: !teacher.isExemptFromSubstitute,
    });
  };

  // جلب جدول المعلم المحدد
  const { data: teacherSchedule, isLoading: scheduleLoading } = trpc.teachers.getSchedule.useQuery(
    { teacherId: scheduleTeacherId! },
    { enabled: scheduleTeacherId !== null }
  );

  const addMutation = trpc.teachers.add.useMutation({
    onSuccess: () => {
      utils.teachers.list.invalidate();
      toast.success("تم إضافة المعلم بنجاح");
      setShowAddDialog(false);
      setNewTeacher({ name: "", shortName: "", weeklyLoad: "" });
    },
    onError: () => toast.error("حدث خطأ أثناء الإضافة"),
  });

  const updateMutation = trpc.teachers.update.useMutation({
    onSuccess: () => {
      utils.teachers.list.invalidate();
      toast.success("تم تحديث النصاب بنجاح");
      setEditLoadTeacher(null);
    },
    onError: () => toast.error("حدث خطأ أثناء التحديث"),
  });

  const deleteMutation = trpc.teachers.delete.useMutation({
    onSuccess: () => {
      utils.teachers.list.invalidate();
      toast.success("تم حذف المعلم بنجاح");
      setDeleteId(null);
    },
    onError: () => toast.error("حدث خطأ أثناء الحذف"),
  });

  const addExemptionMutation = trpc.exemptions.add.useMutation({
    onSuccess: () => {
      utils.exemptions.getByDate.invalidate();
      toast.success("تم استثناء المعلم من الاحتياط اليوم");
    },
    onError: () => toast.error("حدث خطأ"),
  });

  const removeExemptionMutation = trpc.exemptions.removeByTeacherAndDate.useMutation({
    onSuccess: () => {
      utils.exemptions.getByDate.invalidate();
      toast.success("تم إلغاء الاستثناء");
    },
    onError: () => toast.error("حدث خطأ"),
  });

  // mutations الاستثناء الجزئي
  const setPartialExemptionMutation = trpc.teachers.setPartialExemption.useMutation({
    onSuccess: () => {
      utils.teachers.getPartialExemptions.invalidate();
      toast.success("تم حفظ الاستثناء الجزئي بنجاح");
      setPartialExemptTeacher(null);
    },
    onError: () => toast.error("حدث خطأ أثناء حفظ الاستثناء الجزئي"),
  });

  const removePartialExemptionMutation = trpc.teachers.removePartialExemption.useMutation({
    onSuccess: () => {
      utils.teachers.getPartialExemptions.invalidate();
      toast.success("تم إزالة الاستثناء الجزئي");
    },
    onError: () => toast.error("حدث خطأ"),
  });

  const filtered = teachers?.filter((t: any) =>
    t.name.includes(search) || (t.shortName && t.shortName.includes(search))
  ) || [];

  const handleToggleExemption = (teacherId: number) => {
    if (exemptedIds.has(teacherId)) {
      removeExemptionMutation.mutate({ teacherId, date: today });
    } else {
      addExemptionMutation.mutate({ teacherId, date: today, reason: "مكلف بمهام أخرى" });
    }
  };

  const openEditLoad = (teacher: any) => {
    setEditLoadTeacher({ id: teacher.id, name: teacher.name, weeklyLoad: teacher.weeklyLoad || 0, monthlyCapacity: teacher.monthlyCapacity || 0, individualCap: teacher.individualCap ?? 4 });
    setEditLoadValue(String(teacher.weeklyLoad || 0));
    setEditCapacityValue(String(teacher.monthlyCapacity || 0));
    setEditIndividualCapValue(String(teacher.individualCap ?? 4));
  };

  const openSchedule = (teacher: any) => {
    setScheduleTeacherId(teacher.id);
    setScheduleTeacherName(teacher.name);
  };

  const openPartialExemption = (teacher: any) => {
    const existing = partialExemptMap.get(teacher.id);
    setPartialExemptTeacher({ id: teacher.id, name: teacher.name });
    setPartialDays((existing?.exemptDays || []) as DayOfWeek[]);
    setPartialPeriods(existing?.exemptPeriods || []);
    setPartialReason("");
  };

  const toggleDay = (day: DayOfWeek) => {
    setPartialDays((prev) =>
      prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]
    );
  };

  const togglePeriod = (p: number) => {
    setPartialPeriods((prev) =>
      prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p].sort((a, b) => a - b)
    );
  };

  const handleSavePartialExemption = () => {
    if (!partialExemptTeacher) return;
    if (partialDays.length === 0) {
      toast.error("يرجى اختيار يوم واحد على الأقل");
      return;
    }
    setPartialExemptionMutation.mutate({
      teacherId: partialExemptTeacher.id,
      exemptDays: partialDays,
      exemptPeriods: partialPeriods,
      reason: partialReason || undefined,
    });
  };

  // تجميع الجدول حسب الأيام
  const scheduleByDay = DAY_ORDER.reduce((acc, day) => {
    acc[day] = (teacherSchedule || []).filter((s: any) => s.dayOfWeek === day)
      .sort((a: any, b: any) => a.periodNumber - b.periodNumber);
    return acc;
  }, {} as Record<string, any[]>);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold" style={{ color: "oklch(0.25 0.06 145)" }}>
            إدارة المعلمين
          </h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            إجمالي المعلمين: <strong>{teachers?.length || 0}</strong> معلم
          </p>
        </div>
        <Button
          onClick={() => setShowAddDialog(true)}
          className="gap-2 text-sm"
          style={{ background: "oklch(0.32 0.11 145)", color: "white" }}
        >
          <Plus size={16} />
          إضافة معلم
        </Button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="البحث عن معلم..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pr-9"
        />
      </div>

      {/* Exemption notice */}
      {exemptedIds.size > 0 && (
        <div className="flex items-center gap-2 p-3 rounded-lg text-sm"
          style={{ background: "oklch(0.97 0.04 75)", color: "oklch(0.45 0.1 75)" }}>
          <ShieldOff size={14} />
          <span>{exemptedIds.size} معلم مستثنى من الاحتياط اليوم</span>
        </div>
      )}

      {/* Legend */}
      <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
        <div className="flex items-center gap-1">
          <ShieldOff size={12} className="text-amber-500" />
          <span>استثناء يومي مؤقت</span>
        </div>
        <div className="flex items-center gap-1">
          <ShieldCheck size={12} className="text-red-500" />
          <span>استثناء دائم كلي</span>
        </div>
        <div className="flex items-center gap-1">
          <Clock size={12} className="text-blue-500" />
          <span>استثناء جزئي (أيام/حصص)</span>
        </div>
      </div>

      {/* Teachers Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-24 rounded-xl animate-pulse bg-muted" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((teacher: any) => {
            const isExempted = exemptedIds.has(teacher.id);
            const isPermanentlyExempt = teacher.isExemptFromSubstitute;
            const partialEx = partialExemptMap.get(teacher.id);
            const hasPartialExemption = partialEx && partialEx.exemptDays.length > 0;
            const partialSummary = hasPartialExemption
              ? summarizePartialExemption(partialEx!.exemptDays, partialEx!.exemptPeriods)
              : "";

            return (
              <Card
                key={teacher.id}
                className={`border transition-all duration-200 ${isExempted ? "opacity-60" : ""} ${isPermanentlyExempt ? "border-dashed" : ""}`}
                style={
                  isPermanentlyExempt
                    ? { borderColor: "oklch(0.6 0.18 25)", background: "oklch(0.99 0.01 25)" }
                    : isExempted
                    ? { borderColor: "oklch(0.75 0.13 75)", background: "oklch(0.98 0.02 75)" }
                    : hasPartialExemption
                    ? { borderColor: "oklch(0.65 0.15 250)", background: "oklch(0.98 0.02 250)" }
                    : {}
                }
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      {/* Color dot */}
                      <div
                        className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 text-white font-bold text-sm"
                        style={{ background: teacher.color || "oklch(0.32 0.11 145)" }}
                      >
                        {teacher.name.charAt(0)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-sm text-foreground truncate">
                          {teacher.name}
                        </p>
                        <div className="flex items-center gap-1.5 mt-1">
                          <BookOpen size={11} className="text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">
                            النصاب: {teacher.weeklyLoad || 0} ح/أسبوع
                          </span>
                          {(teacher.weeklyLoad === 0 || !teacher.weeklyLoad) && (
                            <Badge className="text-xs h-4 px-1"
                              style={{ background: "oklch(0.75 0.15 25)", color: "white", fontSize: "9px" }}>
                              لا يوجد جدول
                            </Badge>
                          )}
                          {/* عرض السقف الفردي */}
                          {(teacher as any).individualCap !== undefined && (teacher as any).individualCap !== 4 && (
                            <Badge className="text-xs h-4 px-1"
                              style={{ background: "oklch(0.75 0.15 200)", color: "white", fontSize: "9px" }}
                              title="السقف الفردي الأسبوعي للاحتياط">
                              ★ سقف: {(teacher as any).individualCap}
                            </Badge>
                          )}
                        </div>
                        {/* شارة المعلم الأول + الرصيد التراكمي */}
                        {(teacher as any).teacherRole === 'subject_head' && (
                          <Badge className="text-xs h-5 px-1.5 mt-1"
                            style={{ background: "oklch(0.45 0.12 200)", color: "white" }}>
                            معلم أول
                          </Badge>
                        )}
                        <span className="text-xs text-muted-foreground mt-1">
                          الرصيد التراكمي: {(teacher as any).totalAssignmentsCumulative || 0}
                        </span>
                        {/* شارات الاستثناء */}
                        <div className="flex flex-wrap gap-1 mt-1">
                          {isExempted && (
                            <Badge className="text-xs h-5 px-1.5"
                              style={{ background: "oklch(0.75 0.13 75)", color: "oklch(0.15 0.02 240)" }}>
                              مستثنى اليوم
                            </Badge>
                          )}
                          {isPermanentlyExempt && (
                            <Badge className="text-xs h-5 px-1.5"
                              style={{ background: "oklch(0.6 0.18 25)", color: "white" }}>
                              مستثنى دائماً
                            </Badge>
                          )}
                          {hasPartialExemption && !isPermanentlyExempt && (
                            <Badge className="text-xs h-5 px-1.5"
                              style={{ background: "oklch(0.55 0.15 250)", color: "white" }}
                              title={partialSummary}>
                              {partialSummary.length > 20 ? partialSummary.slice(0, 20) + "…" : partialSummary}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col gap-1 shrink-0">
                      {/* استثناء يومي */}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        title={isExempted ? "إلغاء الاستثناء اليومي" : "استثناء من الاحتياط اليوم فقط"}
                        onClick={() => handleToggleExemption(teacher.id)}
                        style={isExempted ? { color: "oklch(0.65 0.13 75)" } : { color: "oklch(0.5 0.03 240)" }}
                      >
                        {isExempted ? <Shield size={14} /> : <ShieldOff size={14} />}
                      </Button>
                      {/* استثناء دائم */}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        title={isPermanentlyExempt ? "إلغاء الاستثناء الدائم" : "استثناء دائم من الاحتياط"}
                        onClick={() => handleTogglePermanentExemption(teacher)}
                        disabled={togglePermanentExemptMutation.isPending}
                        style={isPermanentlyExempt ? { color: "oklch(0.5 0.18 25)" } : { color: "oklch(0.65 0.05 240)" }}
                      >
                        {isPermanentlyExempt ? <ShieldCheck size={14} /> : <ShieldAlert size={14} />}
                      </Button>
                      {/* استثناء جزئي */}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        title="إدارة الاستثناء الجزئي (أيام/حصص محددة)"
                        onClick={() => openPartialExemption(teacher)}
                        style={hasPartialExemption ? { color: "oklch(0.45 0.15 250)" } : { color: "oklch(0.65 0.05 240)" }}
                      >
                        <Clock size={14} />
                      </Button>
                      {/* تعديل النصاب */}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        title="تعديل النصاب الأسبوعي"
                        onClick={() => openEditLoad(teacher)}
                        style={{ color: "oklch(0.45 0.15 250)" }}
                      >
                        <Pencil size={14} />
                      </Button>
                      {/* عرض الجدول */}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        title="عرض الجدول الأسبوعي"
                        onClick={() => openSchedule(teacher)}
                        style={{ color: "oklch(0.45 0.15 145)" }}
                      >
                        <CalendarDays size={14} />
                      </Button>
                      {/* تعديل الجدول يدوياً */}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        title="تعديل الجدول يدوياً"
                        onClick={() => navigate(`/teacher-schedule/${teacher.id}`)}
                        style={{ color: "oklch(0.45 0.15 60)" }}
                      >
                        <SquarePen size={14} />
                      </Button>
                      {/* حذف */}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-destructive hover:text-destructive"
                        title="حذف المعلم"
                        onClick={() => setDeleteId(teacher.id)}
                      >
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {filtered.length === 0 && !isLoading && (
        <div className="text-center py-12">
          <Users size={40} className="mx-auto text-muted-foreground mb-3" />
          <p className="text-muted-foreground text-sm">
            {search ? "لا توجد نتائج للبحث" : "لا يوجد معلمون. قم برفع جدول XML أو إضافة معلم يدوياً."}
          </p>
        </div>
      )}

      {/* ===== Add Teacher Dialog ===== */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="sm:max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-right">إضافة معلم جديد</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label htmlFor="name">اسم المعلم *</Label>
              <Input
                id="name"
                placeholder="الاسم الكامل"
                value={newTeacher.name}
                onChange={(e) => setNewTeacher({ ...newTeacher, name: e.target.value })}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="shortName">الاسم المختصر</Label>
              <Input
                id="shortName"
                placeholder="اختياري"
                value={newTeacher.shortName}
                onChange={(e) => setNewTeacher({ ...newTeacher, shortName: e.target.value })}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="weeklyLoad">النصاب الأسبوعي (عدد الحصص)</Label>
              <Input
                id="weeklyLoad"
                type="number"
                min="0"
                max="40"
                placeholder="0"
                value={newTeacher.weeklyLoad}
                onChange={(e) => setNewTeacher({ ...newTeacher, weeklyLoad: e.target.value })}
                className="mt-1"
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>إلغاء</Button>
            <Button
              onClick={() => {
                if (!newTeacher.name.trim()) {
                  toast.error("يرجى إدخال اسم المعلم");
                  return;
                }
                addMutation.mutate({
                  name: newTeacher.name.trim(),
                  shortName: newTeacher.shortName.trim() || undefined,
                  weeklyLoad: newTeacher.weeklyLoad ? parseFloat(newTeacher.weeklyLoad) : 0,
                });
              }}
              disabled={addMutation.isPending}
              style={{ background: "oklch(0.32 0.11 145)", color: "white" }}
            >
              {addMutation.isPending ? "جاري الإضافة..." : "إضافة"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== Edit Weekly Load Dialog ===== */}
      <Dialog open={editLoadTeacher !== null} onOpenChange={() => setEditLoadTeacher(null)}>
        <DialogContent className="sm:max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-right">تعديل النصاب والسقف</DialogTitle>
          </DialogHeader>
          <div className="py-3 space-y-4">
            <p className="text-sm text-muted-foreground text-right">
              المعلم: <strong className="text-foreground">{editLoadTeacher?.name}</strong>
            </p>
            {/* النصاب الأسبوعي */}
            <div>
              <Label htmlFor="editLoad">النصاب الأسبوعي (عدد الحصص)</Label>
              <Input
                id="editLoad"
                type="number"
                min="0"
                max="40"
                value={editLoadValue}
                onChange={(e) => setEditLoadValue(e.target.value)}
                className="mt-1 text-center text-lg font-bold"
                autoFocus
              />
              <p className="text-xs text-muted-foreground mt-1 text-right">
                النصاب الحالي: {editLoadTeacher?.weeklyLoad} حصة/أسبوع
              </p>
            </div>
            {/* السقف الفردي الأسبوعي (individual_cap) */}
            <div className="p-3 rounded-lg border-2" style={{ borderColor: "oklch(0.75 0.15 200)", background: "oklch(0.97 0.02 200)" }}>
              <Label htmlFor="editIndividualCap" className="font-semibold" style={{ color: "oklch(0.35 0.12 200)" }}>
                ⭐ السقف الفردي الأسبوعي للاحتياط
              </Label>
              <Input
                id="editIndividualCap"
                type="number"
                min="1"
                max="20"
                value={editIndividualCapValue}
                onChange={(e) => setEditIndividualCapValue(e.target.value)}
                className="mt-1 text-center text-lg font-bold"
              />
              <p className="text-xs mt-1 text-right" style={{ color: "oklch(0.45 0.1 200)" }}>
                الحد الأقصى لحصص الاحتياط في الأسبوع — الحالي: {editLoadTeacher?.individualCap ?? 4} حصص | الافتراضي: 4
              </p>
            </div>
            {/* السقف الشهري */}
            <div>
              <Label htmlFor="editCapacity">السقف الشهري (صفر = غير محدود)</Label>
              <Input
                id="editCapacity"
                type="number"
                min="0"
                max="100"
                value={editCapacityValue}
                onChange={(e) => setEditCapacityValue(e.target.value)}
                className="mt-1 text-center"
              />
              <p className="text-xs text-muted-foreground mt-1 text-right">
                السقف الحالي: {editLoadTeacher?.monthlyCapacity === 0 ? "غير محدود" : `${editLoadTeacher?.monthlyCapacity} حصة/شهر`}
              </p>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEditLoadTeacher(null)}>إلغاء</Button>
            <Button
              onClick={() => {
                if (!editLoadTeacher) return;
                const val = parseInt(editLoadValue);
                const cap = parseInt(editCapacityValue);
                const indCap = parseInt(editIndividualCapValue);
                if (isNaN(val) || val < 0) {
                  toast.error("يرجى إدخال رقم صحيح للنصاب");
                  return;
                }
                if (isNaN(cap) || cap < 0) {
                  toast.error("يرجى إدخال رقم صحيح للسقف الشهري");
                  return;
                }
                if (isNaN(indCap) || indCap < 1 || indCap > 20) {
                  toast.error("السقف الفردي يجب أن يكون بين 1 و 20");
                  return;
                }
                updateMutation.mutate({ id: editLoadTeacher.id, weeklyLoad: val, monthlyCapacity: cap, individualCap: indCap });
              }}
              disabled={updateMutation.isPending}
              style={{ background: "oklch(0.32 0.11 145)", color: "white" }}
            >
              {updateMutation.isPending ? "جاري الحفظ..." : "حفظ"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== Partial Exemption Dialog ===== */}
      <Dialog open={partialExemptTeacher !== null} onOpenChange={() => setPartialExemptTeacher(null)}>
        <DialogContent className="sm:max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-right flex items-center gap-2">
              <Clock size={18} style={{ color: "oklch(0.45 0.15 250)" }} />
              الاستثناء الجزئي - {partialExemptTeacher?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="py-3 space-y-5">
            {/* شرح */}
            <div className="p-3 rounded-lg text-sm"
              style={{ background: "oklch(0.97 0.02 250)", color: "oklch(0.35 0.08 250)" }}>
              <p className="font-medium mb-1">كيفية الاستخدام:</p>
              <ul className="text-xs space-y-1 list-disc list-inside">
                <li>اختر الأيام التي يُستثنى فيها المعلم من الاحتياط</li>
                <li>إذا أردت استثناءه من حصص معينة فقط، اختر تلك الحصص</li>
                <li>إذا تركت الحصص فارغة، سيُستثنى من جميع حصص تلك الأيام</li>
              </ul>
            </div>

            {/* الأيام */}
            <div>
              <Label className="text-sm font-semibold mb-2 block">أيام الاستثناء</Label>
              <div className="flex flex-wrap gap-2">
                {ALL_DAYS.map((day) => (
                  <label key={day} className="flex items-center gap-1.5 cursor-pointer select-none">
                    <Checkbox
                      checked={partialDays.includes(day)}
                      onCheckedChange={() => toggleDay(day)}
                    />
                    <span className="text-sm">{DAY_LABELS[day]}</span>
                  </label>
                ))}
              </div>
              <Button
                variant="outline"
                size="sm"
                className="mt-2 text-xs h-7"
                onClick={() => setPartialDays(partialDays.length === 5 ? [] : [...ALL_DAYS])}
              >
                {partialDays.length === 5 ? "إلغاء تحديد الكل" : "تحديد كل الأيام"}
              </Button>
            </div>

            {/* الحصص */}
            <div>
              <Label className="text-sm font-semibold mb-2 block">
                الحصص المستثناة
                <span className="font-normal text-muted-foreground mr-1">(اتركها فارغة لاستثناء كل الحصص)</span>
              </Label>
              <div className="flex flex-wrap gap-2">
                {[1,2,3,4,5,6,7,8].map((p) => (
                  <label key={p} className="flex items-center gap-1.5 cursor-pointer select-none">
                    <Checkbox
                      checked={partialPeriods.includes(p)}
                      onCheckedChange={() => togglePeriod(p)}
                    />
                    <span className="text-sm">ح{p}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* سبب الاستثناء */}
            <div>
              <Label htmlFor="partialReason" className="text-sm font-semibold mb-2 block">سبب الاستثناء (اختياري)</Label>
              <Input
                id="partialReason"
                placeholder="مثال: مشرف طابور، مسؤول نشاط..."
                value={partialReason}
                onChange={(e) => setPartialReason(e.target.value)}
              />
            </div>

            {/* ملخص */}
            {partialDays.length > 0 && (
              <div className="p-2 rounded-lg text-sm font-medium"
                style={{ background: "oklch(0.95 0.04 145)", color: "oklch(0.3 0.08 145)" }}>
                الملخص: {summarizePartialExemption(partialDays, partialPeriods)}
              </div>
            )}
          </div>
          <DialogFooter className="gap-2 flex-wrap">
            {/* زر إزالة الاستثناء الجزئي */}
            {partialExemptTeacher && partialExemptMap.has(partialExemptTeacher.id) && (
              <Button
                variant="outline"
                className="text-destructive border-destructive hover:bg-destructive/10 ml-auto"
                onClick={() => {
                  if (!partialExemptTeacher) return;
                  removePartialExemptionMutation.mutate({ teacherId: partialExemptTeacher.id });
                  setPartialExemptTeacher(null);
                }}
                disabled={removePartialExemptionMutation.isPending}
              >
                إزالة الاستثناء الجزئي
              </Button>
            )}
            <Button variant="outline" onClick={() => setPartialExemptTeacher(null)}>إلغاء</Button>
            <Button
              onClick={handleSavePartialExemption}
              disabled={setPartialExemptionMutation.isPending || partialDays.length === 0}
              style={{ background: "oklch(0.32 0.11 145)", color: "white" }}
            >
              {setPartialExemptionMutation.isPending ? "جاري الحفظ..." : "حفظ الاستثناء"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== View Schedule Dialog ===== */}
      <Dialog open={scheduleTeacherId !== null} onOpenChange={() => setScheduleTeacherId(null)}>
        <DialogContent className="max-w-2xl" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-right flex items-center gap-2">
              <CalendarDays size={18} style={{ color: "oklch(0.32 0.11 145)" }} />
              الجدول الأسبوعي - {scheduleTeacherName}
            </DialogTitle>
          </DialogHeader>
          <div className="py-2">
            {scheduleLoading ? (
              <div className="text-center py-8 text-muted-foreground text-sm">جاري التحميل...</div>
            ) : !teacherSchedule || teacherSchedule.length === 0 ? (
              <div className="text-center py-8">
                <CalendarDays size={32} className="mx-auto mb-2 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">لا يوجد جدول مسجل لهذا المعلم</p>
                <p className="text-xs text-muted-foreground mt-1">
                  يمكنك تعديل النصاب الأسبوعي يدوياً بالضغط على أيقونة القلم
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {/* إجمالي */}
                <div className="flex items-center gap-2 p-2 rounded-lg text-sm"
                  style={{ background: "oklch(0.96 0.03 145)", color: "oklch(0.3 0.08 145)" }}>
                  <BookOpen size={14} />
                  <span>إجمالي الحصص الأسبوعية: <strong>{teacherSchedule.length}</strong> حصة</span>
                </div>

                {/* الجدول حسب الأيام */}
                <div className="overflow-x-auto">
                  <table className="w-full text-sm border-collapse">
                    <thead>
                      <tr style={{ background: "oklch(0.32 0.11 145)", color: "white" }}>
                        <th className="p-2 text-right font-semibold text-xs">اليوم</th>
                        {[1,2,3,4,5,6,7,8].map(p => (
                          <th key={p} className="p-2 text-center font-semibold text-xs w-16">ح{p}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {DAY_ORDER.map((day, idx) => {
                        const dayEntries = scheduleByDay[day] || [];
                        const periodMap = Object.fromEntries(dayEntries.map((e: any) => [e.periodNumber, e]));
                        return (
                          <tr key={day} style={{ background: idx % 2 === 0 ? "oklch(0.99 0.01 145)" : "white" }}>
                            <td className="p-2 font-medium text-xs text-right border-l"
                              style={{ color: "oklch(0.3 0.08 145)", minWidth: "60px" }}>
                              {DAY_LABELS[day]}
                            </td>
                            {[1,2,3,4,5,6,7,8].map(p => {
                              const entry = periodMap[p];
                              return (
                                <td key={p} className="p-1 text-center border-l">
                                  {entry ? (
                                    <div className="rounded text-xs p-1"
                                      style={{ background: "oklch(0.92 0.08 145)", color: "oklch(0.2 0.08 145)" }}>
                                      <div className="font-medium leading-tight" style={{ fontSize: "9px" }}>
                                        {entry.subjectName?.replace('التربية الإسلامية', 'إسلامية')
                                          .replace('اللغة العربية', 'عربية')
                                          .replace('اللغة الإنجليزية', 'إنجليزية')
                                          .replace('الرياضيات', 'رياضيات')
                                          .replace('الدراسات الاجتماعية', 'اجتماعيات') || '—'}
                                      </div>
                                    </div>
                                  ) : (
                                    <span className="text-muted-foreground" style={{ fontSize: "10px" }}>—</span>
                                  )}
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setScheduleTeacherId(null)}>إغلاق</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-right">تأكيد الحذف</AlertDialogTitle>
            <AlertDialogDescription className="text-right">
              هل أنت متأكد من حذف هذا المعلم؟ لن يتم حذف سجلات الغياب والاحتياط المرتبطة به.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row-reverse gap-2">
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteId && deleteMutation.mutate({ id: deleteId })}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
