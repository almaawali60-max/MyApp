import { trpc } from "@/lib/trpc";
import { Users, CheckCircle2, Clock, RefreshCw, RotateCcw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const SPECIALTY_LABELS: Record<string, string> = {
  علوم: "علوم",
  رياضيات: "رياضيات",
  عربي: "لغة عربية",
  انجليزي: "لغة إنجليزية",
  اجتماعيات: "اجتماعيات",
  تربية_اسلامية: "تربية إسلامية",
  تقنية: "تقنية المعلومات",
  مهارات_فردية: "مهارات فردية",
  تربية_بدنية: "تربية بدنية",
  فنون: "تربية فنية",
  موسيقى: "موسيقى",
  مسرح: "مسرح",
};

function specialtyLabel(s?: string | null) {
  if (!s) return "—";
  return SPECIALTY_LABELS[s] || s;
}

function specialtyColor(s?: string | null) {
  const map: Record<string, string> = {
    علوم: "oklch(0.55 0.18 155)",
    رياضيات: "oklch(0.5 0.2 260)",
    عربي: "oklch(0.5 0.2 30)",
    انجليزي: "oklch(0.5 0.18 200)",
    اجتماعيات: "oklch(0.5 0.18 60)",
    تربية_اسلامية: "oklch(0.45 0.18 140)",
    تقنية: "oklch(0.5 0.2 280)",
    مهارات_فردية: "oklch(0.5 0.2 310)",
    تربية_بدنية: "oklch(0.5 0.2 20)",
    فنون: "oklch(0.5 0.2 330)",
    موسيقى: "oklch(0.5 0.2 240)",
    مسرح: "oklch(0.5 0.2 180)",
  };
  return map[s || ""] || "oklch(0.5 0.05 0)";
}

export default function RotationQueue() {
  const { data, isLoading, isError, error, refetch } = trpc.rotationQueue.useQuery(undefined, {
    refetchInterval: 30_000, // تحديث كل 30 ثانية
    retry: 2,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <span className="text-sm text-muted-foreground">جاري التحميل...</span>
        </div>
      </div>
    );
  }

  if (isError || !data) {
    return (
      <div className="flex items-center justify-center h-64" dir="rtl">
        <div className="flex flex-col items-center gap-3 text-center">
          <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: "oklch(0.95 0.05 25)" }}>
            <span className="text-2xl">⚠️</span>
          </div>
          <p className="text-sm font-semibold" style={{ color: "oklch(0.4 0.15 25)" }}>
            تعذّر تحميل قائمة الانتظار
          </p>
          {error && (
            <p className="text-xs text-muted-foreground max-w-xs">
              {String((error as any)?.message || "حدث خطأ غير متوقع")}
            </p>
          )}
          <Button variant="outline" size="sm" onClick={() => refetch()} className="gap-1.5 mt-1">
            <RefreshCw size={14} />
            إعادة المحاولة
          </Button>
        </div>
      </div>
    );
  }

  const progressPct = data.totalEligible > 0
    ? Math.round((data.doneCount / data.totalEligible) * 100)
    : 0;

  return (
    <div className="p-4 max-w-4xl mx-auto space-y-5" dir="rtl">
      {/* رأس الصفحة */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <RotateCcw size={20} style={{ color: "oklch(0.5 0.2 280)" }} />
          <h1 className="text-xl font-bold">قائمة الانتظار — الدورة {data.currentRoundNumber}</h1>
        </div>
        <Button variant="outline" size="sm" onClick={() => refetch()} className="gap-1.5">
          <RefreshCw size={14} />
          تحديث
        </Button>
      </div>

      {/* بطاقات الإحصاء */}
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-xl p-4 text-center" style={{ background: "oklch(0.97 0.02 280)", border: "1px solid oklch(0.88 0.06 280)" }}>
          <div className="text-3xl font-bold" style={{ color: "oklch(0.45 0.2 280)" }}>{data.totalEligible}</div>
          <div className="text-xs text-muted-foreground mt-1">إجمالي المؤهلين</div>
        </div>
        <div className="rounded-xl p-4 text-center" style={{ background: "oklch(0.97 0.04 145)", border: "1px solid oklch(0.88 0.06 145)" }}>
          <div className="text-3xl font-bold" style={{ color: "oklch(0.4 0.18 145)" }}>{data.doneCount}</div>
          <div className="text-xs text-muted-foreground mt-1">أخذوا حصة</div>
        </div>
        <div className="rounded-xl p-4 text-center" style={{ background: "oklch(0.97 0.04 60)", border: "1px solid oklch(0.88 0.06 60)" }}>
          <div className="text-3xl font-bold" style={{ color: "oklch(0.45 0.18 60)" }}>{data.waitingCount}</div>
          <div className="text-xs text-muted-foreground mt-1">في الانتظار</div>
        </div>
      </div>

      {/* شريط التقدم */}
      <div className="space-y-1.5">
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>تقدم الدورة {data.currentRoundNumber}</span>
          <span>{progressPct}%</span>
        </div>
        <div className="h-3 rounded-full overflow-hidden" style={{ background: "oklch(0.93 0.02 0)" }}>
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{
              width: `${progressPct}%`,
              background: progressPct === 100
                ? "oklch(0.55 0.18 145)"
                : "oklch(0.55 0.2 280)",
            }}
          />
        </div>
        {progressPct === 100 && (
          <p className="text-xs text-center font-semibold" style={{ color: "oklch(0.4 0.18 145)" }}>
            ✓ اكتملت الدورة — ستبدأ الدورة {data.currentRoundNumber + 1} تلقائياً عند التوزيع القادم
          </p>
        )}
      </div>

      {/* قسمان: في الانتظار / أخذوا حصة */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* في الانتظار */}
        <div className="rounded-xl overflow-hidden border" style={{ borderColor: "oklch(0.88 0.06 60)" }}>
          <div className="px-4 py-3 flex items-center gap-2" style={{ background: "oklch(0.96 0.04 60)" }}>
            <Clock size={15} style={{ color: "oklch(0.45 0.18 60)" }} />
            <span className="font-semibold text-sm" style={{ color: "oklch(0.35 0.15 60)" }}>
              في الانتظار ({data.waitingCount})
            </span>
            <span className="text-xs text-muted-foreground mr-auto">لم يأخذوا حصة في الدورة الحالية</span>
          </div>
          <div className="divide-y max-h-96 overflow-y-auto">
            {data.waiting.length === 0 ? (
              <div className="p-6 text-center text-sm text-muted-foreground">
                جميع المعلمين أخذوا حصة في هذه الدورة
              </div>
            ) : (
              data.waiting.map((t, idx) => (
                <div key={t.id} className="px-4 py-2.5 flex items-center gap-3 hover:bg-muted/30 transition-colors">
                  <span className="text-xs font-bold w-5 text-center text-muted-foreground">{idx + 1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{t.name}</div>
                    <div className="text-xs text-muted-foreground">{t.weeklyLoad || 0} ح/أسبوع</div>
                  </div>
                  <Badge
                    className="text-xs shrink-0"
                    style={{
                      background: specialtyColor(t.specialty),
                      color: "white",
                      fontSize: "10px",
                    }}
                  >
                    {specialtyLabel(t.specialty)}
                  </Badge>
                </div>
              ))
            )}
          </div>
        </div>

        {/* أخذوا حصة */}
        <div className="rounded-xl overflow-hidden border" style={{ borderColor: "oklch(0.88 0.06 145)" }}>
          <div className="px-4 py-3 flex items-center gap-2" style={{ background: "oklch(0.96 0.04 145)" }}>
            <CheckCircle2 size={15} style={{ color: "oklch(0.45 0.18 145)" }} />
            <span className="font-semibold text-sm" style={{ color: "oklch(0.35 0.15 145)" }}>
              أخذوا حصة ({data.doneCount})
            </span>
            <span className="text-xs text-muted-foreground mr-auto">في الدورة الحالية</span>
          </div>
          <div className="divide-y max-h-96 overflow-y-auto">
            {data.done.length === 0 ? (
              <div className="p-6 text-center text-sm text-muted-foreground">
                لم يأخذ أي معلم حصة بعد في هذه الدورة
              </div>
            ) : (
              data.done.map((t, idx) => (
                <div key={t.id} className="px-4 py-2.5 flex items-center gap-3 hover:bg-muted/30 transition-colors">
                  <CheckCircle2 size={14} style={{ color: "oklch(0.55 0.18 145)" }} className="shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{t.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {(t as any).realLoad ?? t.weeklyLoad ?? 0} ح/أسبوع
                      {(t as any).realLoad !== undefined && (t as any).realLoad !== t.weeklyLoad && (
                        <span className="mr-1 text-amber-600" title="النصاب الحقيقي من الجدول">(جدول)</span>
                      )}
                    </div>
                  </div>
                  <Badge
                    className="text-xs shrink-0"
                    style={{
                      background: specialtyColor(t.specialty),
                      color: "white",
                      fontSize: "10px",
                    }}
                  >
                    {specialtyLabel(t.specialty)}
                  </Badge>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* ملاحظة توضيحية */}
      <div className="rounded-lg p-3 text-xs" style={{ background: "oklch(0.97 0.02 280)", color: "oklch(0.4 0.1 280)" }}>
        <strong>كيف يعمل نظام الدورة:</strong> يضمن النظام أن كل معلم مؤهل يأخذ حصة احتياط واحدة قبل أن يأخذ أي معلم حصته الثانية.
        عند اكتمال الدورة، تبدأ دورة جديدة تلقائياً مع عشوائية ذكية لكسر النمطية.
      </div>
    </div>
  );
}
