import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Shield, Plus, Trash2, Key, Users, Award, AlertTriangle, RefreshCcw } from "lucide-react";

export default function SubjectHeadsPage() {
  const { data: teachers, isLoading: loadingTeachers } = trpc.teachers.list.useQuery();
  const { data: subjectHeads, isLoading: loadingHeads, refetch: refetchHeads } = trpc.subjectHead.list.useQuery();
  const utils = trpc.useUtils();

  const assignMutation = trpc.subjectHead.assign.useMutation({
    onSuccess: () => {
      toast.success("تم تعيين المعلم الأول بنجاح");
      refetchHeads();
      utils.teachers.list.invalidate();
      setAssignDialogOpen(false);
      setSelectedTeacherId("");
      setPassword("");
      setConfirmPassword("");
    },
    onError: (err) => toast.error(err.message),
  });

  const removeMutation = trpc.subjectHead.remove.useMutation({
    onSuccess: () => {
      toast.success("تم إزالة صلاحية المعلم الأول");
      refetchHeads();
      utils.teachers.list.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const resetCumulativeMutation = trpc.cumulative.resetAll.useMutation({
    onSuccess: () => {
      toast.success("تم إعادة تعيين الرصيد التراكمي لجميع المعلمين");
      utils.teachers.list.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [selectedTeacherId, setSelectedTeacherId] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [removeDialogOpen, setRemoveDialogOpen] = useState(false);
  const [removeTarget, setRemoveTarget] = useState<{ id: number; name: string } | null>(null);
  const [resetDialogOpen, setResetDialogOpen] = useState(false);

  // فلترة المعلمين الذين ليسوا معلمين أوائل بالفعل
  const availableTeachers = (teachers || []).filter(
    (t: any) => t.teacherRole !== "subject_head" && t.isActive
  );

  const handleAssign = () => {
    if (!selectedTeacherId) {
      toast.error("الرجاء اختيار معلم");
      return;
    }
    if (password.length < 4) {
      toast.error("الرقم السري يجب أن يكون 4 أحرف على الأقل");
      return;
    }
    if (password !== confirmPassword) {
      toast.error("الرقم السري وتأكيده غير متطابقين");
      return;
    }
    assignMutation.mutate({
      teacherId: Number(selectedTeacherId),
      password,
    });
  };

  const handleRemove = () => {
    if (!removeTarget) return;
    removeMutation.mutate({ teacherId: removeTarget.id });
    setRemoveDialogOpen(false);
    setRemoveTarget(null);
  };

  if (loadingTeachers || loadingHeads) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="container max-w-4xl py-6 space-y-6" dir="rtl">
      {/* العنوان */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl" style={{ background: "oklch(0.35 0.08 200)" }}>
            <Shield className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">المعلمون الأوائل</h1>
            <p className="text-sm text-muted-foreground">إدارة صلاحيات المعلم الأول (Subject Head)</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setResetDialogOpen(true)}
            className="gap-1.5"
          >
            <RefreshCcw size={14} />
            تصفير الرصيد التراكمي
          </Button>
          <Button
            onClick={() => setAssignDialogOpen(true)}
            className="gap-1.5"
            style={{ background: "oklch(0.45 0.12 200)" }}
          >
            <Plus size={16} />
            تعيين معلم أول
          </Button>
        </div>
      </div>

      {/* شرح النظام */}
      <Card className="border-blue-200 bg-blue-50/50 dark:bg-blue-950/20 dark:border-blue-800">
        <CardContent className="p-4">
          <div className="flex gap-3">
            <Award className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="space-y-1 text-sm">
              <p className="font-semibold text-blue-900 dark:text-blue-200">نظام المعلم الأول (Subject Head)</p>
              <ul className="text-blue-800 dark:text-blue-300 space-y-0.5 list-disc list-inside">
                <li>المعلم الأول يمتلك صلاحية متابعة فريقه التخصصي وتكليفهم بالاحتياط</li>
                <li>سقف خاص: <strong>حصتين احتياط أسبوعياً فقط</strong> للمعلم الأول</li>
                <li>يتم تسجيل الدخول عبر رقم سري خاص يُحدد من هذه الصفحة</li>
                <li>العدالة التراكمية: الرصيد لا يُصفّر أسبوعياً بل يتراكم لضمان العدالة الطويلة</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* قائمة المعلمين الأوائل */}
      {(!subjectHeads || subjectHeads.length === 0) ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Users className="h-12 w-12 mx-auto text-muted-foreground/40 mb-3" />
            <p className="text-muted-foreground">لم يتم تعيين أي معلم أول بعد</p>
            <p className="text-sm text-muted-foreground/70 mt-1">
              اضغط "تعيين معلم أول" لإضافة أول معلم
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3">
          {subjectHeads.map((head: any) => (
            <Card key={head.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm"
                      style={{ background: "oklch(0.45 0.12 200)" }}
                    >
                      {head.name?.charAt(0) || "؟"}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">{head.name}</span>
                        <Badge
                          className="text-xs"
                          style={{ background: "oklch(0.45 0.12 200)", color: "white" }}
                        >
                          معلم أول
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                        {head.specialty && (
                          <span>التخصص: {head.specialty}</span>
                        )}
                        <span>النصاب: {head.weeklyLoad || 0} ح/أسبوع</span>
                        <span>الرصيد التراكمي: {head.totalAssignmentsCumulative || 0}</span>
                        <span className="flex items-center gap-1">
                          <Key size={10} />
                          رقم سري مُعيَّن
                        </span>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    onClick={() => {
                      setRemoveTarget({ id: head.id, name: head.name });
                      setRemoveDialogOpen(true);
                    }}
                  >
                    <Trash2 size={14} className="ml-1" />
                    إزالة
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* نافذة تعيين معلم أول */}
      <Dialog open={assignDialogOpen} onOpenChange={setAssignDialogOpen}>
        <DialogContent dir="rtl" className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield size={20} />
              تعيين معلم أول جديد
            </DialogTitle>
            <DialogDescription>
              اختر المعلم وحدد رقماً سرياً لتسجيل دخوله
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>المعلم</Label>
              <Select value={selectedTeacherId} onValueChange={setSelectedTeacherId}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر معلماً..." />
                </SelectTrigger>
                <SelectContent>
                  {availableTeachers.map((t: any) => (
                    <SelectItem key={t.id} value={String(t.id)}>
                      {t.name} {t.specialty ? `(${t.specialty})` : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>الرقم السري</Label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="أدخل الرقم السري (4 أحرف على الأقل)"
                dir="ltr"
              />
            </div>
            <div className="space-y-2">
              <Label>تأكيد الرقم السري</Label>
              <Input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="أعد إدخال الرقم السري"
                dir="ltr"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignDialogOpen(false)}>
              إلغاء
            </Button>
            <Button
              onClick={handleAssign}
              disabled={assignMutation.isPending}
              style={{ background: "oklch(0.45 0.12 200)" }}
            >
              {assignMutation.isPending ? "جارٍ التعيين..." : "تعيين"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* نافذة تأكيد الإزالة */}
      <Dialog open={removeDialogOpen} onOpenChange={setRemoveDialogOpen}>
        <DialogContent dir="rtl" className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle size={20} />
              تأكيد الإزالة
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من إزالة صلاحية المعلم الأول من <strong>{removeTarget?.name}</strong>؟
              سيتم حذف الرقم السري وإعادته لمعلم عادي.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRemoveDialogOpen(false)}>
              إلغاء
            </Button>
            <Button variant="destructive" onClick={handleRemove}>
              إزالة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* نافذة تأكيد تصفير الرصيد التراكمي */}
      <Dialog open={resetDialogOpen} onOpenChange={setResetDialogOpen}>
        <DialogContent dir="rtl" className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-amber-600">
              <RefreshCcw size={20} />
              تصفير الرصيد التراكمي
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من إعادة تعيين الرصيد التراكمي لجميع المعلمين إلى صفر؟
              هذا الإجراء لا يمكن التراجع عنه.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setResetDialogOpen(false)}>
              إلغاء
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                resetCumulativeMutation.mutate();
                setResetDialogOpen(false);
              }}
            >
              تصفير
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
