import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { GraduationCap, Search, CheckCircle2, AlertCircle, Users } from "lucide-react";
import { toast } from "sonner";

// قائمة التخصصات الرسمية
const SPECIALTIES = [
  { value: "علوم", label: "العلوم (كيمياء / فيزياء / أحياء)", color: "oklch(0.55 0.18 160)" },
  { value: "رياضيات", label: "الرياضيات", color: "oklch(0.50 0.18 250)" },
  { value: "عربية", label: "اللغة العربية", color: "oklch(0.50 0.18 30)" },
  { value: "إنجليزية", label: "اللغة الإنجليزية", color: "oklch(0.45 0.18 280)" },
  { value: "تقنية", label: "تقنية المعلومات", color: "oklch(0.45 0.18 220)" },
  { value: "إسلامية", label: "التربية الإسلامية", color: "oklch(0.50 0.18 75)" },
  { value: "دراسات", label: "الدراسات الاجتماعية", color: "oklch(0.50 0.18 45)" },
  { value: "رياضة", label: "الرياضة المدرسية", color: "oklch(0.50 0.18 140)" },
  { value: "فنون", label: "الفنون التشكيلية", color: "oklch(0.50 0.18 320)" },
  { value: "موسيقى", label: "المهارات الموسيقية", color: "oklch(0.50 0.18 350)" },
  { value: "حياتية", label: "المهارات الحياتية", color: "oklch(0.45 0.18 190)" },
];

const specialtyMap = Object.fromEntries(SPECIALTIES.map((s) => [s.value, s]));

export default function SpecializationPage() {
  const [search, setSearch] = useState("");
  const [filterSpecialty, setFilterSpecialty] = useState<string>("all");
  const [savingId, setSavingId] = useState<number | null>(null);
  const [localSpecialties, setLocalSpecialties] = useState<Record<number, string>>({});

  const { data: teachers, isLoading, refetch } = trpc.teachers.list.useQuery();

  const updateMutation = trpc.teachers.update.useMutation({
    onSuccess: () => {
      refetch();
    },
    onError: () => {
      toast.error("فشل حفظ التخصص");
    },
  });

  const handleSave = async (teacherId: number) => {
    const specialty = localSpecialties[teacherId];
    if (specialty === undefined) return;
    setSavingId(teacherId);
    try {
      await updateMutation.mutateAsync({ id: teacherId, specialty: specialty || null });
      toast.success("تم حفظ التخصص بنجاح");
      setLocalSpecialties((prev) => {
        const next = { ...prev };
        delete next[teacherId];
        return next;
      });
    } finally {
      setSavingId(null);
    }
  };

  const handleSpecialtyChange = (teacherId: number, value: string) => {
    setLocalSpecialties((prev) => ({ ...prev, [teacherId]: value === "none" ? "" : value }));
  };

  const activeTeachers = (teachers || []).filter((t: any) => t.isActive);

  const filtered = activeTeachers.filter((t: any) => {
    const matchSearch =
      !search ||
      t.name?.includes(search) ||
      t.shortName?.includes(search);
    const currentSpecialty = localSpecialties[t.id] !== undefined ? localSpecialties[t.id] : (t.specialty || "");
    const matchFilter =
      filterSpecialty === "all" ||
      (filterSpecialty === "unset" && !currentSpecialty) ||
      currentSpecialty === filterSpecialty;
    return matchSearch && matchFilter;
  });

  const assignedCount = activeTeachers.filter((t: any) =>
    localSpecialties[t.id] !== undefined
      ? !!localSpecialties[t.id]
      : !!t.specialty
  ).length;
  const unassignedCount = activeTeachers.length - assignedCount;

  // تجميع المعلمين حسب التخصص
  const bySpecialty: Record<string, any[]> = {};
  for (const t of filtered) {
    const sp = localSpecialties[t.id] !== undefined ? localSpecialties[t.id] : (t.specialty || "");
    const key = sp || "unset";
    if (!bySpecialty[key]) bySpecialty[key] = [];
    bySpecialty[key].push(t);
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold" style={{ color: "oklch(0.25 0.06 145)" }}>
          التخصيص
        </h2>
        <p className="text-sm text-muted-foreground mt-0.5">
          حدّد التخصص الرسمي لكل معلم لتفعيل التوزيع الذكي حسب التخصص
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="py-4 text-center">
            <p className="text-2xl font-bold" style={{ color: "oklch(0.32 0.11 145)" }}>
              {activeTeachers.length}
            </p>
            <p className="text-xs text-muted-foreground mt-1">إجمالي المعلمين</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="py-4 text-center">
            <p className="text-2xl font-bold" style={{ color: "oklch(0.45 0.18 250)" }}>
              {assignedCount}
            </p>
            <p className="text-xs text-muted-foreground mt-1">تم تحديد تخصصهم</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="py-4 text-center">
            <p className="text-2xl font-bold" style={{ color: "oklch(0.55 0.18 30)" }}>
              {unassignedCount}
            </p>
            <p className="text-xs text-muted-foreground mt-1">لم يُحدَّد تخصصهم</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="ابحث باسم المعلم..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-9 text-sm"
          />
        </div>
        <Select value={filterSpecialty} onValueChange={setFilterSpecialty}>
          <SelectTrigger className="w-52 text-sm">
            <SelectValue placeholder="تصفية حسب التخصص" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع التخصصات</SelectItem>
            <SelectItem value="unset">غير محدد التخصص</SelectItem>
            {SPECIALTIES.map((s) => (
              <SelectItem key={s.value} value={s.value}>
                {s.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Teachers List */}
      {isLoading ? (
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-16 rounded-xl animate-pulse bg-muted" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="py-12 text-center">
            <Users size={40} className="mx-auto mb-3 text-muted-foreground" />
            <p className="text-muted-foreground">لا يوجد معلمون مطابقون للبحث</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {filtered.map((teacher: any) => {
            const currentSpecialty =
              localSpecialties[teacher.id] !== undefined
                ? localSpecialties[teacher.id]
                : teacher.specialty || "";
            const isDirty = localSpecialties[teacher.id] !== undefined;
            const specialtyInfo = specialtyMap[currentSpecialty];

            return (
              <Card
                key={teacher.id}
                className="border shadow-sm"
                style={isDirty ? { borderColor: "oklch(0.75 0.13 75)" } : {}}
              >
                <CardContent className="py-3 px-4">
                  <div className="flex items-center gap-3">
                    {/* Avatar */}
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0"
                      style={{
                        background: specialtyInfo
                          ? specialtyInfo.color
                          : "oklch(0.65 0.05 145)",
                      }}
                    >
                      {teacher.name?.charAt(0) || "م"}
                    </div>

                    {/* Name */}
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm text-foreground truncate">
                        {teacher.name}
                      </p>
                      {currentSpecialty ? (
                        <span
                          className="inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full mt-0.5"
                          style={{
                            background: specialtyInfo
                              ? specialtyInfo.color + "22"
                              : "oklch(0.94 0.02 145)",
                            color: specialtyInfo ? specialtyInfo.color : "oklch(0.45 0.06 145)",
                          }}
                        >
                          <GraduationCap size={11} />
                          {specialtyInfo?.label || currentSpecialty}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                          <AlertCircle size={11} />
                          لم يُحدَّد التخصص
                        </span>
                      )}
                    </div>

                    {/* Specialty Selector */}
                    <div className="flex items-center gap-2 shrink-0">
                      <Select
                        value={currentSpecialty || "none"}
                        onValueChange={(v) => handleSpecialtyChange(teacher.id, v)}
                      >
                        <SelectTrigger className="w-48 text-xs h-8">
                          <SelectValue placeholder="اختر التخصص..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">— بدون تخصص —</SelectItem>
                          {SPECIALTIES.map((s) => (
                            <SelectItem key={s.value} value={s.value}>
                              {s.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      {isDirty && (
                        <Button
                          size="sm"
                          className="h-8 px-3 text-xs gap-1"
                          style={{ background: "oklch(0.32 0.11 145)", color: "white" }}
                          onClick={() => handleSave(teacher.id)}
                          disabled={savingId === teacher.id}
                        >
                          {savingId === teacher.id ? (
                            <span className="animate-spin">⏳</span>
                          ) : (
                            <CheckCircle2 size={13} />
                          )}
                          حفظ
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Legend */}
      <Card className="border-0 shadow-sm" style={{ background: "oklch(0.97 0.02 145)" }}>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold" style={{ color: "oklch(0.25 0.06 145)" }}>
            التخصصات المتاحة
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex flex-wrap gap-2">
            {SPECIALTIES.map((s) => (
              <span
                key={s.value}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium"
                style={{ background: s.color + "22", color: s.color }}
              >
                <GraduationCap size={11} />
                {s.label}
              </span>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
