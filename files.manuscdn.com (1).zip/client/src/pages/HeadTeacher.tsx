import { useAdminAuth } from "@/contexts/AdminAuthContext";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { GraduationCap, LogOut, Users, BookOpen, Calendar, TrendingUp } from "lucide-react";
import { useMemo } from "react";

export default function HeadTeacherPage() {
  const { subjectFilter, logout } = useAdminAuth();

  // جلب جميع المعلمين
  const { data: teachers, isLoading: loadingTeachers } = trpc.teachers.list.useQuery();

  // جلب إحصائيات الاحتياط للشهر الحالي
  const now = useMemo(() => new Date(), []);
  const { data: monthStats } = trpc.stats.monthly.useQuery({
    year: now.getFullYear(),
    month: now.getMonth() + 1,
  });

  // تصفية المعلمين حسب المادة
  const filteredTeachers = useMemo(() => {
    if (!teachers) return [];
    return teachers.filter((t) => {
      const spec = (t.specialty || "").toLowerCase();
      const filter = subjectFilter.toLowerCase();
      return spec.includes(filter) || filter.includes(spec);
    });
  }, [teachers, subjectFilter]);

  // إحصائيات الفريق
  const teamStats = useMemo(() => {
    if (!filteredTeachers.length) return { total: 0, totalLoad: 0, avgLoad: 0, maxLoad: 0 };
    const total = filteredTeachers.length;
    const totalLoad = filteredTeachers.reduce((s, t) => s + (t.weeklyLoad || 0), 0);
    const avgLoad = total > 0 ? Math.round(totalLoad / total) : 0;
    const maxLoad = Math.max(...filteredTeachers.map((t) => t.weeklyLoad || 0));
    return { total, totalLoad, avgLoad, maxLoad };
  }, [filteredTeachers]);

  const getSubstituteCount = (teacherId: number): number => {
    if (!monthStats) return 0;
    const found = monthStats.find((s: { teacher: { id: number }; substituteCount: number }) => s.teacher.id === teacherId);
    return found?.substituteCount || 0;
  };

  return (
    <div className="min-h-screen" dir="rtl" style={{ background: "oklch(0.13 0.05 145)" }}>
      {/* Header */}
      <div className="border-b px-6 py-4 flex items-center justify-between" style={{ background: "oklch(0.18 0.07 145)", borderColor: "oklch(0.28 0.08 145)" }}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "oklch(0.3 0.1 200)" }}>
            <GraduationCap size={22} style={{ color: "oklch(0.75 0.12 200)" }} />
          </div>
          <div>
            <h1 className="text-base font-bold" style={{ color: "oklch(0.95 0.01 120)" }}>لوحة المعلم الأول</h1>
            <p className="text-xs" style={{ color: "oklch(0.65 0.03 120)" }}>
              مادة: <span className="font-semibold" style={{ color: "oklch(0.75 0.12 200)" }}>{subjectFilter}</span>
            </p>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={logout} className="gap-2 text-xs border" style={{ borderColor: "oklch(0.35 0.08 145)", color: "oklch(0.75 0.03 120)" }}>
          <LogOut size={14} />خروج
        </Button>
      </div>

      <div className="p-6 space-y-6">
        {/* بطاقات الإحصائيات */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card style={{ background: "oklch(0.2 0.06 145)", borderColor: "oklch(0.3 0.08 145)" }}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: "oklch(0.3 0.1 200)" }}>
                  <Users size={18} style={{ color: "oklch(0.75 0.12 200)" }} />
                </div>
                <div>
                  <p className="text-2xl font-bold" style={{ color: "oklch(0.95 0.01 120)" }}>{teamStats.total}</p>
                  <p className="text-xs" style={{ color: "oklch(0.6 0.03 120)" }}>أعضاء الفريق</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card style={{ background: "oklch(0.2 0.06 145)", borderColor: "oklch(0.3 0.08 145)" }}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: "oklch(0.32 0.1 145)" }}>
                  <BookOpen size={18} style={{ color: "oklch(0.75 0.13 75)" }} />
                </div>
                <div>
                  <p className="text-2xl font-bold" style={{ color: "oklch(0.95 0.01 120)" }}>{teamStats.avgLoad}</p>
                  <p className="text-xs" style={{ color: "oklch(0.6 0.03 120)" }}>متوسط النصاب</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card style={{ background: "oklch(0.2 0.06 145)", borderColor: "oklch(0.3 0.08 145)" }}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: "oklch(0.28 0.1 50)" }}>
                  <TrendingUp size={18} style={{ color: "oklch(0.75 0.13 50)" }} />
                </div>
                <div>
                  <p className="text-2xl font-bold" style={{ color: "oklch(0.95 0.01 120)" }}>{teamStats.maxLoad}</p>
                  <p className="text-xs" style={{ color: "oklch(0.6 0.03 120)" }}>أعلى نصاب</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card style={{ background: "oklch(0.2 0.06 145)", borderColor: "oklch(0.3 0.08 145)" }}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: "oklch(0.28 0.1 25)" }}>
                  <Calendar size={18} style={{ color: "oklch(0.75 0.13 25)" }} />
                </div>
                <div>
                  <p className="text-2xl font-bold" style={{ color: "oklch(0.95 0.01 120)" }}>
                    {filteredTeachers.reduce((s: number, t) => s + getSubstituteCount(t.id), 0)}
                  </p>
                  <p className="text-xs" style={{ color: "oklch(0.6 0.03 120)" }}>احتياط هذا الشهر</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* جدول أعضاء الفريق */}
        <Card style={{ background: "oklch(0.18 0.07 145)", borderColor: "oklch(0.28 0.08 145)" }}>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2" style={{ color: "oklch(0.95 0.01 120)" }}>
              <GraduationCap size={18} style={{ color: "oklch(0.75 0.12 200)" }} />
              فريق مادة {subjectFilter}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loadingTeachers ? (
              <div className="text-center py-8" style={{ color: "oklch(0.6 0.03 120)" }}>جاري التحميل...</div>
            ) : filteredTeachers.length === 0 ? (
              <div className="text-center py-8" style={{ color: "oklch(0.6 0.03 120)" }}>
                لا يوجد معلمون بمادة "{subjectFilter}" في النظام
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ borderBottom: "1px solid oklch(0.28 0.08 145)" }}>
                      <th className="text-right py-2 px-3 font-medium" style={{ color: "oklch(0.65 0.03 120)" }}>الاسم</th>
                      <th className="text-center py-2 px-3 font-medium" style={{ color: "oklch(0.65 0.03 120)" }}>النصاب</th>
                      <th className="text-center py-2 px-3 font-medium" style={{ color: "oklch(0.65 0.03 120)" }}>احتياط الشهر</th>
                      <th className="text-center py-2 px-3 font-medium" style={{ color: "oklch(0.65 0.03 120)" }}>الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredTeachers.map((teacher) => {
                      const subCount = getSubstituteCount(teacher.id);
                      const cap = teacher.monthlyCapacity || 8;
                      const overCap = subCount >= cap;
                      return (
                        <tr key={teacher.id} style={{ borderBottom: "1px solid oklch(0.22 0.06 145)" }}>
                          <td className="py-3 px-3" style={{ color: "oklch(0.9 0.01 120)" }}>
                            <div className="font-medium">{teacher.name}</div>
                            <div className="text-xs" style={{ color: "oklch(0.6 0.03 120)" }}>{teacher.specialty}</div>
                          </td>
                          <td className="py-3 px-3 text-center">
                            <span className="font-bold" style={{ color: "oklch(0.75 0.13 75)" }}>{teacher.weeklyLoad || 0}</span>
                            <span className="text-xs" style={{ color: "oklch(0.6 0.03 120)" }}> ح/أ</span>
                          </td>
                          <td className="py-3 px-3 text-center">
                            <span className={`font-bold ${overCap ? "text-red-400" : ""}`} style={overCap ? {} : { color: "oklch(0.75 0.12 200)" }}>
                              {subCount}
                            </span>
                            <span className="text-xs" style={{ color: "oklch(0.6 0.03 120)" }}>/{cap}</span>
                          </td>
                          <td className="py-3 px-3 text-center">
                            {!teacher.isActive ? (
                              <Badge variant="outline" className="text-xs border-red-500 text-red-400">غير نشط</Badge>
                            ) : teacher.isExemptFromSubstitute ? (
                              <Badge variant="outline" className="text-xs border-yellow-500 text-yellow-400">معفى</Badge>
                            ) : overCap ? (
                              <Badge variant="outline" className="text-xs border-red-500 text-red-400">تجاوز السقف</Badge>
                            ) : (
                              <Badge variant="outline" className="text-xs border-green-500 text-green-400">متاح</Badge>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
