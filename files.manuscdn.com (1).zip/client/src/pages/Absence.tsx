import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { CalendarX, Trash2, CheckCircle2, Search, UserX, AlertTriangle, BookOpen, Clock, UserPlus, PenLine, X } from "lucide-react";

const DAYS = [
  { value: "Sunday", label: "الأحد" },
  { value: "Monday", label: "الاثنين" },
  { value: "Tuesday", label: "الثلاثاء" },
  { value: "Wednesday", label: "الأربعاء" },
  { value: "Thursday", label: "الخميس" },
];

/** تحويل سلسلة YYYY-MM-DD إلى اسم اليوم بالإنجليزية بدون تأثير UTC */
const getDayOfWeek = (dateStr: string): string => {
  const [year, month, day] = dateStr.split("-").map(Number);
  const d = new Date(year, month - 1, day); // local date, لا تحويل UTC
  const dayMap: Record<number, string> = {
    0: "Sunday", 1: "Monday", 2: "Tuesday", 3: "Wednesday", 4: "Thursday",
    5: "Friday", 6: "Saturday",
  };
  return dayMap[d.getDay()] || "Sunday";
};

/** الحصول على تاريخ اليوم بالتوقيت المحلي (لا UTC) بصيغة YYYY-MM-DD */
const getLocalToday = (): string => {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
};

// مكوّن لوحة التوزيع اليدوي الإلزامي مع فلترة المعلمين المتاحين
function ManualAssignPanel({
  absence,
  selectedDate,
  selectedDay,
  onClose,
  onConfirm,
  isPending,
}: {
  absence: any;
  selectedDate: string;
  selectedDay: string;
  onClose: () => void;
  onConfirm: (periodNumber: number, substituteTeacherId: number) => void;
  isPending: boolean;
}) {
  const [periodNumber, setPeriodNumber] = useState<number>(0);
  const [substituteTeacherId, setSubstituteTeacherId] = useState<number>(0);

  // جلب المعلمين الفارغين في الحصة المختارة فقط (مع تمييز نفس التخصص)
  const { data: availableTeachers, isLoading: loadingTeachers } = trpc.teachers.getAvailableForPeriod.useQuery(
    {
      dayOfWeek: selectedDay as any,
      periodNumber,
      date: selectedDate,
      excludeTeacherIds: [absence.teacherId],
      absentTeacherId: absence.teacherId,
    },
    { enabled: periodNumber > 0 }
  );
  const sameSubjectTeachers = (availableTeachers || []).filter((t: any) => t.sameSubject);
  const otherTeachers = (availableTeachers || []).filter((t: any) => !t.sameSubject);

  const handlePeriodChange = (val: string) => {
    setPeriodNumber(Number(val));
    setSubstituteTeacherId(0); // إعادة تعيين المعلم عند تغيير الحصة
  };

  const dayLabel = selectedDay === 'Sunday' ? 'الأحد' : selectedDay === 'Monday' ? 'الاثنين' : selectedDay === 'Tuesday' ? 'الثلاثاء' : selectedDay === 'Wednesday' ? 'الأربعاء' : 'الخميس';

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold" style={{ color: "oklch(0.45 0.2 270)" }}>
          <PenLine size={11} className="inline ml-1" />
          توزيع يدوي إلزامي
        </span>
        <button className="text-xs text-muted-foreground hover:text-foreground" onClick={onClose}>
          <X size={12} />
        </button>
      </div>
      <div className="flex items-center gap-2 flex-wrap">
        {/* اختيار رقم الحصة */}
        <Select value={String(periodNumber || "")} onValueChange={handlePeriodChange}>
          <SelectTrigger className="h-7 text-xs w-24">
            <SelectValue placeholder="الحصة" />
          </SelectTrigger>
          <SelectContent>
            {[1,2,3,4,5,6,7,8].map(p => (
              <SelectItem key={p} value={String(p)}>الحصة {p}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {/* اختيار المعلم البديل - مفلتر حسب الحصة */}
        <Select
          value={String(substituteTeacherId || "")}
          onValueChange={(val) => setSubstituteTeacherId(Number(val))}
          disabled={!periodNumber}
        >
          <SelectTrigger className="h-7 text-xs flex-1 min-w-[180px]">
            <SelectValue placeholder={
              !periodNumber
                ? "اختر الحصة أولاً..."
                : loadingTeachers
                ? "جاري التحميل..."
                : availableTeachers?.length === 0
                ? "لا يوجد معلمون متاحون"
                : `${availableTeachers?.length || 0} معلم متاح`
            } />
          </SelectTrigger>
          <SelectContent className="max-h-60">
            {periodNumber > 0 && !loadingTeachers && (availableTeachers || []).length === 0 && (
              <div className="px-3 py-2 text-xs text-muted-foreground text-center">
                لا يوجد معلمون فارغون في الحصة {periodNumber}
              </div>
            )}
            {/* المعلمون بنفس التخصص أولاً - بخلفية خضراء */}
            {sameSubjectTeachers.length > 0 && (
              <>
                <div className="px-3 py-1 text-[10px] font-bold" style={{ color: "oklch(0.35 0.15 145)", background: "oklch(0.95 0.05 145)" }}>
                  ★ نفس التخصص ({sameSubjectTeachers.length})
                </div>
                {sameSubjectTeachers.map((t: any) => (
                  <SelectItem key={t.id} value={String(t.id)}>
                    <span className="flex items-center gap-1 w-full">
                      <span className="inline-block w-2 h-2 rounded-full flex-shrink-0" style={{ background: "oklch(0.55 0.18 145)" }} />
                      <span>{t.name}</span>
                      {t.specialty && <span className="text-[9px] font-bold mr-auto" style={{ color: "oklch(0.45 0.15 145)" }}>({t.specialty})</span>}
                    </span>
                  </SelectItem>
                ))}
                {otherTeachers.length > 0 && (
                  <div className="px-3 py-1 text-[10px] text-muted-foreground border-t" style={{ background: "oklch(0.98 0.01 0)" }}>
                    — معلمون آخرون ({otherTeachers.length})
                  </div>
                )}
              </>
            )}
            {/* باقي المعلمين */}
            {otherTeachers.map((t: any) => (
              <SelectItem key={t.id} value={String(t.id)}>
                {t.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {/* زر التأكيد */}
        <Button
          size="sm"
          className="h-7 text-xs px-3"
          style={{ background: "oklch(0.45 0.2 270)", color: "white" }}
          disabled={!periodNumber || !substituteTeacherId || isPending}
          onClick={() => onConfirm(periodNumber, substituteTeacherId)}
        >
          {isPending ? "جاري..." : "تأكيد"}
        </Button>
      </div>
      {periodNumber > 0 && !loadingTeachers && (
        <p className="text-[10px]" style={{ color: "oklch(0.45 0.15 145)" }}>
          ✓ المعلمون المعروضون فارغون في الحصة {periodNumber} يوم {dayLabel}
          {sameSubjectTeachers.length > 0 && <span className="font-bold"> · {sameSubjectTeachers.length} بنفس التخصص مميزون باللون الأخضر</span>}
        </p>
      )}
      <p className="text-[10px] text-muted-foreground">
        ⚠️ هذا التوزيع إلزامي ويتجاوز جميع القيود التلقائية
      </p>
    </div>
  );
}

// مكوّن صغير يعرض حصص معلم في يوم معين
function TeacherDaySchedule({ teacherId, dayOfWeek }: { teacherId: number; dayOfWeek: string }) {
  const { data: periods, isLoading } = trpc.teachers.getScheduleByDay.useQuery(
    { teacherId, dayOfWeek },
    { enabled: !!teacherId && !!dayOfWeek }
  );

  if (isLoading) return <span className="text-xs text-muted-foreground">...</span>;
  if (!periods || periods.length === 0) {
    return (
      <span className="inline-flex items-center gap-1 text-xs" style={{ color: "oklch(0.55 0.2 25)" }}>
        <AlertTriangle size={11} />
        لا توجد حصص هذا اليوم
      </span>
    );
  }
  return (
    <span className="text-xs" style={{ color: "oklch(0.35 0.1 145)" }}>
      {periods.length} حصة: {periods.map((p: any) => `ح${p.periodNumber}`).join("، ")}
    </span>
  );
}

export default function AbsencePage() {
  const utils = trpc.useUtils();
  const today = getLocalToday(); // توقيت محلي لا UTC
  const [selectedDate, setSelectedDate] = useState(today);
  const [selectedDay, setSelectedDay] = useState(getDayOfWeek(today));
  const [selectedTeachers, setSelectedTeachers] = useState<number[]>([]);
  const [reason, setReason] = useState("");
  const [search, setSearch] = useState("");
  const [deleteAbsenceId, setDeleteAbsenceId] = useState<number | null>(null);
  const [skipExpiredPeriods, setSkipExpiredPeriods] = useState(false);
  // غياب جزئي: Map<teacherId, Set<periodNumber>>
  const [partialPeriodsMap, setPartialPeriodsMap] = useState<Map<number, Set<number>>>(new Map());
  const [distributionMode, setDistributionMode] = useState<"general" | "specialty">("general");
  // إدخال يدوي للحصص: Map<teacherId, Set<periodNumber>>
  const [manualPeriodsMap, setManualPeriodsMap] = useState<Map<number, Set<number>>>(new Map());
  const [showManualInput, setShowManualInput] = useState<Set<number>>(new Set());
  // التوزيع اليدوي الإلزامي: Map<absenceRecordId, { periodNumber, substituteTeacherId }>
  const [manualAssignState, setManualAssignState] = useState<Map<number, { periodNumber: number; substituteTeacherId: number | null }>>(new Map());
  const [showManualAssign, setShowManualAssign] = useState<Set<number>>(new Set()); // Set<absenceRecordId>
  const toggleManualPeriod = (teacherId: number, period: number) => {
    setManualPeriodsMap(prev => {
      const nm = new Map(prev);
      const existing = nm.get(teacherId) ? new Set(nm.get(teacherId)) : new Set<number>();
      if (existing.has(period)) { existing.delete(period); } else { existing.add(period); }
      nm.set(teacherId, existing);
      return nm;
    });
  };
  const toggleShowManualInput = (teacherId: number) => {
    setShowManualInput(prev => {
      const ns = new Set(prev);
      if (ns.has(teacherId)) { ns.delete(teacherId); } else { ns.add(teacherId); }
      return ns;
    });
  };

  const { data: teachers } = trpc.teachers.list.useQuery();
  const { data: weeklyStats } = trpc.stats.weeklyStats.useQuery();
  const weeklyCountMap = new Map(
    (weeklyStats || []).map((w: any) => [w.teacherId, { count: w.weeklyCount, max: w.maxAllowed }])
  );
  const { data: absences } = trpc.absences.getByDate.useQuery({ date: selectedDate });

  const alreadyAbsentIds = new Set(absences?.map((a: any) => a.teacherId) || []);

  const filteredTeachers = useMemo(() =>
    teachers?.filter((t: any) =>
      !alreadyAbsentIds.has(t.id) &&
      (t.name.includes(search) || (t.shortName && t.shortName.includes(search)))
    ) || [],
    [teachers, alreadyAbsentIds, search]
  );

  const registerMutation = trpc.absences.register.useMutation({
    onSuccess: (data) => {
      utils.absences.getByDate.invalidate();
      utils.stats.monthly.invalidate();
      const total = data.results.reduce((sum: number, r: any) => sum + r.assignmentsCount, 0);
      if (total === 0) {
        toast.warning("تم تسجيل الغياب، لكن لا توجد حصص لتوزيعها في هذا اليوم");
      } else {
        toast.success(`تم تسجيل الغياب وتوزيع ${total} حصة احتياط بنجاح`);
      }
      setSelectedTeachers([]);
      setReason("");
    },
    onError: () => toast.error("حدث خطأ أثناء تسجيل الغياب"),
  });

  const deleteMutation = trpc.absences.delete.useMutation({
    onSuccess: () => {
      utils.absences.getByDate.invalidate();
      toast.success("تم حذف سجل الغياب والتوزيع");
      setDeleteAbsenceId(null);
    },
    onError: () => toast.error("حدث خطأ"),
  });
  const manualAssignMutation = trpc.absences.manualAssign.useMutation({
    onSuccess: (data, variables) => {
      utils.absences.getByDate.invalidate();
      utils.stats.weeklyStats.invalidate();
      if (data.hasConflict) {
        toast.warning("تم التوزيع اليدوي — تحذير: المعلم البديل مشغول بحصة أخرى في نفس الوقت");
      } else {
        toast.success("تم التوزيع اليدوي الإلزامي بنجاح");
      }
      // إخفاء لوحة التوزيع اليدوي لهذا الغياب
      setShowManualAssign(prev => { const ns = new Set(prev); ns.delete(variables.absenceRecordId); return ns; });
      setManualAssignState(prev => { const nm = new Map(prev); nm.delete(variables.absenceRecordId); return nm; });
    },
    onError: (err) => toast.error("خطأ في التوزيع اليدوي: " + err.message),
  });
  const deleteAssignmentMutation = trpc.absences.deleteAssignment.useMutation({
    onSuccess: () => {
      utils.absences.getByDate.invalidate();
      utils.stats.weeklyStats.invalidate();
      toast.success("تم حذف التوزيع");
    },
    onError: () => toast.error("حدث خطأ في حذف التوزيع"),
  });

  const toggleTeacher = (id: number) => {
    setSelectedTeachers((prev) => {
      if (prev.includes(id)) {
        // عند إلغاء التحديد نحذف الغياب الجزئي أيضاً
        setPartialPeriodsMap(m => { const nm = new Map(m); nm.delete(id); return nm; });
        return prev.filter((x) => x !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  const togglePartialPeriod = (teacherId: number, period: number) => {
    setPartialPeriodsMap(prev => {
      const nm = new Map(prev);
      const existing = nm.get(teacherId) ? new Set(nm.get(teacherId)) : new Set<number>();
      if (existing.has(period)) {
        existing.delete(period);
      } else {
        existing.add(period);
      }
      nm.set(teacherId, existing);
      return nm;
    });
  };

  const handleDateChange = (date: string) => {
    setSelectedDate(date);
    setSelectedDay(getDayOfWeek(date));
    setSelectedTeachers([]);
  };

  const handleSubmit = () => {
    if (selectedTeachers.length === 0) {
      toast.error("يرجى اختيار معلم واحد على الأقل");
      return;
    }
    // بناء قائمة الغياب الجزئي (partialAbsences)
    // تدمج الحصص المحددة يدوياً مع الحصص الجزئية المختارة من الجدول
    const partialAbsences: Array<{ teacherId: number; periods: number[] }> = [];
    for (const tid of selectedTeachers) {
      const partialPeriods = partialPeriodsMap.get(tid) || new Set<number>();
      const manualPeriods = manualPeriodsMap.get(tid) || new Set<number>();
      // دمج الحصتين: الجزئية + اليدوية
      const combined = new Set([...Array.from(partialPeriods), ...Array.from(manualPeriods)]);
      if (combined.size > 0) {
        partialAbsences.push({ teacherId: tid, periods: Array.from(combined).sort((a,b)=>a-b) });
      }
    }
    console.log("[DEBUG Absence] Submitting:", {
      teacherIds: selectedTeachers,
      date: selectedDate,
      dayOfWeek: selectedDay,
      partialAbsences,
    });
    registerMutation.mutate({
      teacherIds: selectedTeachers,
      date: selectedDate,
      dayOfWeek: selectedDay as any,
      reason: reason || undefined,
      skipExpiredPeriods,
      nowUtcMs: skipExpiredPeriods ? Date.now() : undefined,
      partialAbsences: partialAbsences.length > 0 ? partialAbsences : undefined,
      distributionMode,
    });
  };

  const dayLabel = DAYS.find((d) => d.value === selectedDay)?.label || "";

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold" style={{ color: "oklch(0.25 0.06 145)" }}>
          تسجيل الغياب اليومي
        </h2>
        <p className="text-sm text-muted-foreground mt-0.5">
          اختر المعلمين الغائبين لتوزيع حصصهم تلقائياً على المعلمين الحاضرين
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Left: Registration Form */}
        <div className="space-y-4">
          {/* Date & Day Selection */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold">تحديد اليوم</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">التاريخ</Label>
                <Input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => handleDateChange(e.target.value)}
                  className="text-sm"
                />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">اليوم</Label>
                <Select value={selectedDay} onValueChange={(v) => { setSelectedDay(v); setSelectedTeachers([]); }}>
                  <SelectTrigger className="text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {DAYS.map((d) => (
                      <SelectItem key={d.value} value={d.value}>{d.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">سبب الغياب (اختياري)</Label>
                <Input
                  placeholder="مثال: إجازة مرضية"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="text-sm"
                />
              </div>
            </CardContent>
          </Card>

          {/* Teacher Selection */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold flex items-center justify-between">
                <span>اختيار المعلمين الغائبين</span>
                {selectedTeachers.length > 0 && (
                  <Badge style={{ background: "oklch(0.55 0.2 25)", color: "white" }}>
                    {selectedTeachers.length} محدد
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="relative">
                <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="بحث..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pr-8 text-sm h-8"
                />
              </div>

              <div className="max-h-96 overflow-y-auto space-y-1 pr-1">
                {filteredTeachers.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-4">
                    {teachers?.length === 0 ? "لا يوجد معلمون مسجلون" : "جميع المعلمين مسجلون كغائبين"}
                  </p>
                ) : (
                  filteredTeachers.map((teacher: any) => {
                    const isSelected = selectedTeachers.includes(teacher.id);
                    const selectedPeriods = partialPeriodsMap.get(teacher.id) || new Set<number>();
                    return (
                      <div key={teacher.id} className="rounded-lg overflow-hidden border border-transparent">
                        {/* صف المعلم */}
                        <div
                          className={`flex items-center gap-3 p-2.5 cursor-pointer transition-colors ${
                            isSelected
                              ? "bg-primary/10 border-b border-primary/20"
                              : "hover:bg-muted rounded-lg"
                          }`}
                          onClick={() => toggleTeacher(teacher.id)}
                        >
                          <Checkbox
                            checked={isSelected}
                            onCheckedChange={() => toggleTeacher(teacher.id)}
                            className="shrink-0"
                          />
                          <div
                            className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0"
                            style={{ background: teacher.color || "oklch(0.32 0.11 145)" }}
                          >
                            {teacher.name.charAt(0)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="text-sm font-medium truncate">{teacher.name}</p>
                              {isSelected && selectedPeriods.size > 0 && (
                                <Badge className="text-xs shrink-0" style={{ background: "oklch(0.55 0.18 280)", color: "white" }}>
                                  جزئي: {Array.from(selectedPeriods).sort((a,b)=>a-b).map(p => `ح${p}`).join("،")}
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <BookOpen size={10} />
                                {teacher.weeklyLoad || 0} ح/أسبوع
                              </span>
                              {(() => {
                                const wk = weeklyCountMap.get(teacher.id);
                                const cnt = wk?.count || 0;
                                const max = wk?.max || 4;
                                const isAtLimit = cnt >= max;
                                const isNearLimit = cnt >= max - 1 && cnt < max;
                                return (
                                  <span
                                    className="text-xs font-bold px-1.5 py-0.5 rounded-full"
                                    style={{
                                      background: isAtLimit ? 'oklch(0.92 0.15 25)' : isNearLimit ? 'oklch(0.95 0.1 75)' : 'oklch(0.93 0.05 145)',
                                      color: isAtLimit ? 'oklch(0.45 0.2 25)' : isNearLimit ? 'oklch(0.45 0.12 75)' : 'oklch(0.3 0.1 145)',
                                    }}
                                    title={isAtLimit ? 'وصل للحد الأقصى هذا الأسبوع' : isNearLimit ? 'قريب من الحد الأقصى' : 'الاحتياط هذا الأسبوع'}
                                  >
                                    {cnt}/{max}
                                  </span>
                                );
                              })()}
                              <span className="text-muted-foreground">·</span>
                              <TeacherDaySchedule teacherId={teacher.id} dayOfWeek={selectedDay} />
                            </div>
                          </div>
                        </div>
                        {/* لوحة الغياب الجزئي - تظهر فقط عند تحديد المعلم */}
                        {isSelected && (
                          <div className="px-3 py-2" style={{ background: "oklch(0.97 0.02 280)", borderTop: "1px dashed oklch(0.85 0.06 280)" }}>
                            <div className="flex items-center justify-between gap-2 mb-1.5">
                              <div className="flex items-center gap-2">
                                <Clock size={11} style={{ color: "oklch(0.45 0.15 280)" }} />
                                <span className="text-xs font-semibold" style={{ color: "oklch(0.35 0.12 280)" }}>
                                  غياب جزئي — حدد الحصص المغيبة فقط (اتركه فارغاً للغياب الكامل)
                                </span>
                              </div>
                              {/* زر الإدخال اليدوي */}
                              <button
                                type="button"
                                onClick={(e) => { e.stopPropagation(); toggleShowManualInput(teacher.id); }}
                                className="text-xs px-2 py-0.5 rounded-full border font-semibold transition-all"
                                style={showManualInput.has(teacher.id) ? {
                                  background: "oklch(0.45 0.18 25)", color: "white", borderColor: "oklch(0.45 0.18 25)"
                                } : {
                                  background: "oklch(0.96 0.05 25)", color: "oklch(0.45 0.18 25)", borderColor: "oklch(0.75 0.1 25)"
                                }}
                                title="إضافة حصص غياب يدوياً (للتغلب على مشكلة جلب الجدول)"
                              >
                                {showManualInput.has(teacher.id) ? "✕ إخفاء اليدوي" : "⊕ إضافة يدوي"}
                              </button>
                            </div>
                            <div className="flex flex-wrap gap-1.5">
                              {[1,2,3,4,5,6,7,8].map(p => (
                                <button
                                  key={p}
                                  type="button"
                                  onClick={(e) => { e.stopPropagation(); togglePartialPeriod(teacher.id, p); }}
                                  className="w-8 h-8 rounded-full text-xs font-bold transition-all border"
                                  style={selectedPeriods.has(p) ? {
                                    background: "oklch(0.45 0.18 280)",
                                    color: "white",
                                    borderColor: "oklch(0.45 0.18 280)",
                                  } : {
                                    background: "white",
                                    color: "oklch(0.45 0.15 280)",
                                    borderColor: "oklch(0.75 0.08 280)",
                                  }}
                                >
                                  {p}
                                </button>
                              ))}
                            </div>
                            {/* لوحة الإدخال اليدوي - تظهر عند الضغط على ⊕ إضافة يدوي */}
                            {showManualInput.has(teacher.id) && (
                              <div className="mt-2 pt-2" style={{ borderTop: "1px dashed oklch(0.8 0.08 25)" }}>
                                <div className="flex items-center gap-1.5 mb-1.5">
                                  <span className="text-xs font-bold" style={{ color: "oklch(0.4 0.18 25)" }}>
                                    ⚠️ تحديد حصص الغياب يدوياً
                                  </span>
                                  <span className="text-xs text-muted-foreground">
                                    (للتغلب على مشكلة جلب الجدول آلياً)
                                  </span>
                                </div>
                                <div className="flex flex-wrap gap-1.5">
                                  {[1,2,3,4,5,6,7,8].map(mp => {
                                    const isManualSelected = (manualPeriodsMap.get(teacher.id) || new Set()).has(mp);
                                    return (
                                      <button
                                        key={mp}
                                        type="button"
                                        onClick={(e) => { e.stopPropagation(); toggleManualPeriod(teacher.id, mp); }}
                                        className="w-8 h-8 rounded-full text-xs font-bold transition-all border"
                                        style={isManualSelected ? {
                                          background: "oklch(0.45 0.18 25)",
                                          color: "white",
                                          borderColor: "oklch(0.45 0.18 25)",
                                        } : {
                                          background: "white",
                                          color: "oklch(0.45 0.18 25)",
                                          borderColor: "oklch(0.75 0.1 25)",
                                        }}
                                      >
                                        {mp}
                                      </button>
                                    );
                                  })}
                                </div>
                                {(manualPeriodsMap.get(teacher.id)?.size ?? 0) > 0 && (
                                  <div className="mt-1.5 text-xs font-semibold" style={{ color: "oklch(0.4 0.18 25)" }}>
                                    ✔ سيتم توزيع الحصص: {Array.from(manualPeriodsMap.get(teacher.id) || new Set<number>()).sort((a,b)=>(a as number)-(b as number)).map(p => `ح${p}`).join("، ")}
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
              {/* تحذير إذا كان المعلم المختار ليس لديه حصص */}
              {selectedTeachers.length > 0 && (
                <div className="rounded-lg p-2.5 text-xs flex items-start gap-2"
                  style={{ background: "oklch(0.97 0.03 75)", color: "oklch(0.4 0.1 75)" }}>
                  <AlertTriangle size={13} className="shrink-0 mt-0.5" />
                  <span>
                    تأكد من أن المعلمين المختارين لديهم حصص في يوم <strong>{dayLabel}</strong>. 
                    إذا لم تكن لديهم حصص، لن يتم توزيع أي احتياط.
                  </span>
                </div>
              )}

              {/* خيار تجاوز الحصص المنتهية */}
              <div
                className="flex items-start gap-2.5 rounded-lg p-3 cursor-pointer"
                style={{ background: skipExpiredPeriods ? "oklch(0.93 0.06 240)" : "oklch(0.97 0.02 240)", border: "1px solid oklch(0.85 0.06 240)" }}
                onClick={() => setSkipExpiredPeriods(v => !v)}
              >
                <Checkbox
                  id="skipExpired"
                  checked={skipExpiredPeriods}
                  onCheckedChange={(v) => setSkipExpiredPeriods(!!v)}
                  className="mt-0.5"
                />
                <div>
                  <Label htmlFor="skipExpired" className="text-xs font-semibold cursor-pointer" style={{ color: "oklch(0.3 0.1 240)" }}>
                    غياب في منتصف اليوم — تجاوز الحصص المنتهية
                  </Label>
              <div className="flex items-center gap-2 p-3 rounded-lg border" style={{ background: "oklch(0.96 0.01 145)", borderColor: "oklch(0.85 0.05 145)" }}>
                <Label className="text-xs font-medium">وضع التوزيع:</Label>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant={distributionMode === "general" ? "default" : "outline"}
                    onClick={() => setDistributionMode("general")}
                    className="text-xs h-7"
                  >
                    عام
                  </Button>
                  <Button
                    size="sm"
                    variant={distributionMode === "specialty" ? "default" : "outline"}
                    onClick={() => setDistributionMode("specialty")}
                    className="text-xs h-7"
                  >
                    تخصصي
                  </Button>
                </div>
              </div>
                  <p className="text-xs mt-0.5" style={{ color: "oklch(0.5 0.08 240)" }}>
                    سيبدأ التوزيع تلقائياً من الحصة التالية للوقت الحالي (عمان UTC+4)
                  </p>
                </div>
              </div>

              <Button
                className="w-full gap-2 text-sm"
                onClick={handleSubmit}
                disabled={selectedTeachers.length === 0 || registerMutation.isPending}
                style={{ background: "oklch(0.32 0.11 145)", color: "white" }}
              >
                <CalendarX size={15} />
                {registerMutation.isPending
                  ? "جاري التوزيع..."
                  : `تسجيل غياب ${selectedTeachers.length > 0 ? selectedTeachers.length + " معلم" : ""} وتوزيع الاحتياط`}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Right: Today's Absences */}
        <div>
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <UserX size={15} style={{ color: "oklch(0.55 0.2 25)" }} />
                <span>غيابات {dayLabel} - {selectedDate}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!absences || absences.length === 0 ? (
                <div className="text-center py-8">
                  <CheckCircle2 size={32} className="mx-auto mb-2" style={{ color: "oklch(0.32 0.11 145)" }} />
                  <p className="text-sm text-muted-foreground">لا يوجد غياب مسجل لهذا اليوم</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {absences.map((absence: any) => (
                    <div
                      key={absence.id}
                      className="rounded-xl border overflow-hidden"
                    >
                      {/* Absent teacher header */}
                      <div className="flex items-center justify-between px-4 py-3"
                        style={{ background: "oklch(0.97 0.02 25)" }}>
                        <div className="flex items-center gap-2">
                          <UserX size={14} style={{ color: "oklch(0.55 0.2 25)" }} />
                          <span className="font-semibold text-sm text-foreground">
                            {absence.teacher?.name || "—"}
                          </span>
                          {absence.reason && (
                            <span className="text-xs text-muted-foreground">({absence.reason})</span>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          {absence.assignments && absence.assignments.length > 0 ? (
                            <Badge className="text-xs"
                              style={{ background: "oklch(0.55 0.2 25)", color: "white" }}>
                              {absence.assignments.length} حصة موزّعة
                            </Badge>
                          ) : (
                            <Badge className="text-xs"
                              style={{ background: "oklch(0.75 0.1 75)", color: "white" }}>
                              لا توجد حصص
                            </Badge>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-destructive"
                            onClick={() => setDeleteAbsenceId(absence.id)}
                          >
                            <Trash2 size={12} />
                          </Button>
                        </div>
                      </div>

                      {/* Assignments */}
                      {absence.assignments && absence.assignments.length > 0 ? (
                        <div className="divide-y divide-border">
                          {absence.assignments.map((a: any) => (
                            <div key={a.id} className="flex items-center justify-between px-4 py-2 text-xs group">
                              <div className="flex items-center gap-1">
                                <span className="font-medium text-muted-foreground">
                                  الحصة {a.periodNumber}
                                  {a.subjectName && ` - ${a.subjectName}`}
                                  {a.className && ` (${a.className})`}
                                </span>
                                {a.constraintBreakLevel === 99 && (
                                  <Badge className="text-[10px] px-1 py-0 h-4" style={{ background: "oklch(0.45 0.2 270)", color: "white" }}>يدوي</Badge>
                                )}
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-sm text-foreground">
                                  {teachers?.find((t: any) => t.id === a.substituteTeacherId)?.name || `معلم #${a.substituteTeacherId}`}
                                </span>
                                <button
                                  className="opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-red-700"
                                  title="حذف هذا التوزيع"
                                  onClick={() => deleteAssignmentMutation.mutate({ assignmentId: a.id })}
                                >
                                  <X size={12} />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="px-4 py-3 text-xs text-muted-foreground flex items-center gap-2"
                          style={{ background: "oklch(0.98 0.01 75)" }}>
                          <AlertTriangle size={12} style={{ color: "oklch(0.65 0.15 75)" }} />
                          لا توجد حصص لهذا المعلم في هذا اليوم — لم يتم توزيع أي احتياط
                        </div>
                      )}
                      {/* زر التوزيع اليدوي الإلزامي */}
                      <div className="px-4 py-2 border-t" style={{ background: "oklch(0.97 0.01 270 / 0.4)" }}>
                        {!showManualAssign.has(absence.id) ? (
                          <button
                            className="flex items-center gap-1 text-xs font-medium hover:underline"
                            style={{ color: "oklch(0.45 0.2 270)" }}
                            onClick={() => setShowManualAssign(prev => { const ns = new Set(prev); ns.add(absence.id); return ns; })}
                          >
                            <UserPlus size={12} />
                            إضافة توزيع يدوي إلزامي
                          </button>
                        ) : (
                          <ManualAssignPanel
                            absence={absence}
                            selectedDate={selectedDate}
                            selectedDay={selectedDay}
                            isPending={manualAssignMutation.isPending}
                            onClose={() => {
                              setShowManualAssign(prev => { const ns = new Set(prev); ns.delete(absence.id); return ns; });
                            }}
                            onConfirm={(periodNumber, substituteTeacherId) => {
                              manualAssignMutation.mutate({
                                absenceRecordId: absence.id,
                                absentTeacherId: absence.teacherId,
                                substituteTeacherId,
                                periodNumber,
                                date: selectedDate,
                                dayOfWeek: selectedDay as any,
                              });
                            }}
                          />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteAbsenceId !== null} onOpenChange={() => setDeleteAbsenceId(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-right">حذف سجل الغياب</AlertDialogTitle>
            <AlertDialogDescription className="text-right">
              سيتم حذف سجل الغياب وجميع توزيعات الاحتياط المرتبطة به. هل تريد المتابعة؟
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row-reverse gap-2">
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteAbsenceId && deleteMutation.mutate({ id: deleteAbsenceId })}
              className="bg-destructive text-white"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
