import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { BarChart3, TrendingUp, Award, Users } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

const monthNames = [
  "يناير","فبراير","مارس","أبريل","مايو","يونيو",
  "يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"
];

export default function TeacherStatisticsPage() {
  const today = new Date();
  const [selectedYear, setSelectedYear] = useState(today.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(today.getMonth() + 1);

  const { data: stats, isLoading } = trpc.stats.monthly.useQuery({
    year: selectedYear,
    month: selectedMonth,
  });
  const { data: weeklyStats } = trpc.stats.weeklyStats.useQuery();

  const weeklyMap = new Map<number, number>();
  if (weeklyStats) {
    for (const w of weeklyStats) {
      weeklyMap.set(w.teacherId, w.weeklyCount);
    }
  }

  const chartData = stats
    ? stats
        .filter((s) => s.substituteCount > 0)
        .sort((a, b) => b.substituteCount - a.substituteCount)
        .slice(0, 15)
        .map((s) => ({
          name: s.teacher.name.split(" ").slice(0, 2).join(" "),
          count: s.substituteCount,
          id: s.teacher.id,
        }))
    : [];

  const totalSubstitutes = stats?.reduce((sum, s) => sum + s.substituteCount, 0) || 0;
  const topTeacher = stats?.sort((a, b) => b.substituteCount - a.substituteCount)[0];

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold flex items-center gap-2" style={{ color: "oklch(0.2 0.05 145)" }}>
            <BarChart3 size={22} style={{ color: "oklch(0.45 0.12 145)" }} />
            الإحصائيات العامة
          </h1>
          <p className="text-sm mt-1" style={{ color: "oklch(0.5 0.03 120)" }}>
            {monthNames[selectedMonth - 1]} {selectedYear}
          </p>
        </div>
        <div className="flex gap-2">
          <Select value={String(selectedMonth)} onValueChange={(v) => setSelectedMonth(Number(v))}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {monthNames.map((m, i) => (
                <SelectItem key={i + 1} value={String(i + 1)}>{m}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={String(selectedYear)} onValueChange={(v) => setSelectedYear(Number(v))}>
            <SelectTrigger className="w-24">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {[2024, 2025, 2026].map((y) => (
                <SelectItem key={y} value={String(y)}>{y}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-5 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: "oklch(0.9 0.05 145)" }}>
                <TrendingUp size={20} style={{ color: "oklch(0.35 0.12 145)" }} />
              </div>
              <div>
                <p className="text-2xl font-bold" style={{ color: "oklch(0.2 0.05 145)" }}>{totalSubstitutes}</p>
                <p className="text-xs" style={{ color: "oklch(0.5 0.03 120)" }}>إجمالي حصص الاحتياط</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: "oklch(0.9 0.08 75)" }}>
                <Award size={20} style={{ color: "oklch(0.55 0.13 75)" }} />
              </div>
              <div>
                <p className="text-sm font-bold truncate max-w-[120px]" style={{ color: "oklch(0.2 0.05 145)" }}>
                  {topTeacher?.teacher.name.split(" ").slice(0, 2).join(" ") || "—"}
                </p>
                <p className="text-xs" style={{ color: "oklch(0.5 0.03 120)" }}>الأكثر احتياطاً ({topTeacher?.substituteCount || 0})</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: "oklch(0.9 0.05 240)" }}>
                <Users size={20} style={{ color: "oklch(0.45 0.12 240)" }} />
              </div>
              <div>
                <p className="text-2xl font-bold" style={{ color: "oklch(0.2 0.05 145)" }}>
                  {stats?.filter((s) => s.substituteCount > 0).length || 0}
                </p>
                <p className="text-xs" style={{ color: "oklch(0.5 0.03 120)" }}>معلم شارك في الاحتياط</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Chart */}
      {chartData.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base" style={{ color: "oklch(0.25 0.07 145)" }}>
              أعلى 15 معلماً في الاحتياط
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 60 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.9 0.005 120)" />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 10, fill: "oklch(0.4 0.03 120)" }}
                  angle={-35}
                  textAnchor="end"
                  interval={0}
                />
                <YAxis tick={{ fontSize: 11, fill: "oklch(0.4 0.03 120)" }} allowDecimals={false} />
                <Tooltip
                  formatter={(value) => [`${value} حصة`, "الاحتياط"]}
                  contentStyle={{ fontSize: 12, direction: "rtl" }}
                />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                  {chartData.map((_, index) => (
                    <Cell
                      key={index}
                      fill={index === 0 ? "oklch(0.65 0.13 75)" : "oklch(0.45 0.12 145)"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Table */}
      {isLoading ? (
        <div className="text-center py-8" style={{ color: "oklch(0.5 0.03 120)" }}>جاري التحميل...</div>
      ) : stats && stats.length > 0 ? (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base" style={{ color: "oklch(0.25 0.07 145)" }}>
              تفاصيل الاحتياط الشهري
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ background: "oklch(0.95 0.005 120)" }}>
                    <th className="text-right px-4 py-2.5 font-semibold" style={{ color: "oklch(0.3 0.05 145)" }}>#</th>
                    <th className="text-right px-4 py-2.5 font-semibold" style={{ color: "oklch(0.3 0.05 145)" }}>اسم المعلم</th>
                    <th className="text-right px-4 py-2.5 font-semibold" style={{ color: "oklch(0.3 0.05 145)" }}>التخصص</th>
                    <th className="text-center px-4 py-2.5 font-semibold" style={{ color: "oklch(0.3 0.05 145)" }}>هذا الأسبوع</th>
                    <th className="text-center px-4 py-2.5 font-semibold" style={{ color: "oklch(0.3 0.05 145)" }}>الشهر</th>
                  </tr>
                </thead>
                <tbody>
                  {stats
                    .sort((a, b) => b.substituteCount - a.substituteCount)
                    .map((s, idx) => {
                      const weeklyCount = weeklyMap.get(s.teacher.id) || 0;
                      const maxWeekly = 4;
                      const weeklyColor =
                        weeklyCount >= maxWeekly
                          ? "oklch(0.55 0.2 25)"
                          : weeklyCount >= 3
                          ? "oklch(0.6 0.15 60)"
                          : "oklch(0.45 0.12 145)";
                      return (
                        <tr
                          key={s.teacher.id}
                          style={{ background: idx % 2 === 0 ? "white" : "oklch(0.98 0.003 120)" }}
                        >
                          <td className="px-4 py-2.5 text-xs" style={{ color: "oklch(0.6 0.03 120)" }}>{idx + 1}</td>
                          <td className="px-4 py-2.5 font-medium" style={{ color: "oklch(0.25 0.07 145)" }}>
                            {s.teacher.name}
                          </td>
                          <td className="px-4 py-2.5 text-xs" style={{ color: "oklch(0.5 0.03 120)" }}>
                            {s.teacher.specialty || "—"}
                          </td>
                          <td className="px-4 py-2.5 text-center">
                            <Badge
                              className="text-xs font-bold"
                              style={{
                                background: weeklyColor + "22",
                                color: weeklyColor,
                                border: `1px solid ${weeklyColor}`,
                              }}
                            >
                              {weeklyCount}/{maxWeekly}
                            </Badge>
                          </td>
                          <td className="px-4 py-2.5 text-center">
                            <span className="font-bold" style={{ color: s.substituteCount > 0 ? "oklch(0.35 0.12 145)" : "oklch(0.7 0.01 120)" }}>
                              {s.substituteCount}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
