import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { FileText, UserX, GraduationCap } from "lucide-react";

const monthNames = [
  "يناير","فبراير","مارس","أبريل","مايو","يونيو",
  "يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"
];

const dayNames = ["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];

export default function TeacherDailyReportPage() {
  const today = new Date().toISOString().split("T")[0];
  const [selectedDate, setSelectedDate] = useState(today);

  const { data: report, isLoading } = trpc.stats.dailyReport.useQuery({ date: selectedDate });

  const dateObj = new Date(selectedDate + "T00:00:00");
  const dayName = dayNames[dateObj.getDay()];
  const formattedDate = `${dayName} ${dateObj.getDate()} ${monthNames[dateObj.getMonth()]} ${dateObj.getFullYear()}`;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold flex items-center gap-2" style={{ color: "oklch(0.2 0.05 145)" }}>
            <FileText size={22} style={{ color: "oklch(0.45 0.12 145)" }} />
            جدول الاحتياط اليومي
          </h1>
          <p className="text-sm mt-1" style={{ color: "oklch(0.5 0.03 120)" }}>{formattedDate}</p>
        </div>
        <Input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          className="w-44 text-center"
          style={{ direction: "ltr" }}
        />
      </div>

      {isLoading ? (
        <div className="text-center py-12" style={{ color: "oklch(0.5 0.03 120)" }}>
          جاري التحميل...
        </div>
      ) : !report || report.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <UserX size={48} className="mx-auto mb-4 opacity-30" />
            <p className="text-lg font-medium" style={{ color: "oklch(0.4 0.03 120)" }}>
              لا يوجد غياب مسجّل لهذا اليوم
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {report.map((item) => (
            <Card key={item.absence.id} className="overflow-hidden shadow-sm">
              <CardHeader className="py-3 px-4" style={{ background: "oklch(0.22 0.07 145)" }}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-bold text-sm" style={{ color: "oklch(0.95 0.01 120)" }}>
                      {item.absentTeacher?.name || "—"}
                    </p>
                    <p className="text-xs mt-0.5" style={{ color: "oklch(0.7 0.01 120)" }}>
                      {item.absentTeacher?.specialty || "غير محدد"} — نصاب {item.absentTeacher?.weeklyLoad || 0} حصة
                    </p>
                  </div>
                  <Badge
                    className="text-xs"
                    style={{ background: "oklch(0.55 0.15 25)", color: "white" }}
                  >
                    غائب
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {item.assignments.length === 0 ? (
                  <p className="text-center py-4 text-sm" style={{ color: "oklch(0.5 0.03 120)" }}>
                    لا يوجد توزيع احتياط لهذا المعلم
                  </p>
                ) : (
                  <table className="w-full text-sm">
                    <thead>
                      <tr style={{ background: "oklch(0.95 0.005 120)" }}>
                        <th className="text-right px-4 py-2 font-semibold" style={{ color: "oklch(0.3 0.05 145)" }}>الحصة</th>
                        <th className="text-right px-4 py-2 font-semibold" style={{ color: "oklch(0.3 0.05 145)" }}>الفصل</th>
                        <th className="text-right px-4 py-2 font-semibold" style={{ color: "oklch(0.3 0.05 145)" }}>المادة</th>
                        <th className="text-right px-4 py-2 font-semibold" style={{ color: "oklch(0.3 0.05 145)" }}>المعلم البديل</th>
                      </tr>
                    </thead>
                    <tbody>
                      {item.assignments.map((a, idx) => (
                        <tr
                          key={a.id}
                          style={{ background: idx % 2 === 0 ? "white" : "oklch(0.98 0.003 120)" }}
                        >
                          <td className="px-4 py-2.5 font-medium" style={{ color: "oklch(0.3 0.05 145)" }}>
                            {a.periodNumber}
                          </td>
                          <td className="px-4 py-2.5" style={{ color: "oklch(0.3 0.03 120)" }}>
                            {a.className || "—"}
                          </td>
                          <td className="px-4 py-2.5" style={{ color: "oklch(0.3 0.03 120)" }}>
                            {a.subjectName || "—"}
                          </td>
                          <td className="px-4 py-2.5">
                            <div className="flex items-center gap-2">
                              <span style={{ color: "oklch(0.25 0.07 145)" }} className="font-medium">
                                {a.substituteTeacher?.name || "—"}
                              </span>
                              {a.isSpecialtyMatch && (
                                <Badge
                                  className="text-xs gap-1 py-0"
                                  style={{ background: "oklch(0.45 0.12 145)", color: "white" }}
                                >
                                  <GraduationCap size={10} />
                                  تخصص
                                </Badge>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
