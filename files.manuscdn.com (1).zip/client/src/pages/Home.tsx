import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Users,
  CalendarX,
  FileText,
  BarChart3,
  Upload,
  BookOpen,
  TrendingUp,
  Award,
} from "lucide-react";
import { useState } from "react";

const today = new Date();
const todayStr = today.toISOString().split("T")[0];
const dayNames: Record<number, string> = {
  0: "الأحد",
  1: "الاثنين",
  2: "الثلاثاء",
  3: "الأربعاء",
  4: "الخميس",
  5: "الجمعة",
  6: "السبت",
};

const monthNames = [
  "يناير","فبراير","مارس","أبريل","مايو","يونيو",
  "يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"
];

export default function Home() {
  const { data: teachers } = trpc.teachers.list.useQuery();
  const { data: schoolSettings } = trpc.schoolSettings.get.useQuery();
  const { data: todayAbsences } = trpc.absences.getByDate.useQuery({ date: todayStr });
  const { data: monthStats } = trpc.stats.monthly.useQuery({
    year: today.getFullYear(),
    month: today.getMonth() + 1,
  });

  const totalTeachers = teachers?.length || 0;
  const todayAbsenceCount = todayAbsences?.length || 0;
  const totalSubstitutesThisMonth = monthStats?.reduce((sum, s) => sum + s.substituteCount, 0) || 0;
  const totalAbsencesThisMonth = monthStats?.reduce((sum, s) => sum + s.absenceCount, 0) || 0;

  const quickActions = [
    {
      href: "/absence",
      label: "تسجيل غياب اليوم",
      icon: CalendarX,
      color: "oklch(0.55 0.2 25)",
      bg: "oklch(0.97 0.02 25)",
      description: "تسجيل غياب المعلمين وتوزيع الاحتياط",
    },
    {
      href: "/daily-report",
      label: "جدول الاحتياط اليومي",
      icon: FileText,
      color: "oklch(0.32 0.11 145)",
      bg: "oklch(0.97 0.02 145)",
      description: "عرض وطباعة جدول الاحتياط",
    },
    {
      href: "/teachers",
      label: "إدارة المعلمين",
      icon: Users,
      color: "oklch(0.45 0.1 240)",
      bg: "oklch(0.97 0.02 240)",
      description: "إضافة وحذف واستثناء المعلمين",
    },
    {
      href: "/statistics",
      label: "الإحصائيات الشهرية",
      icon: BarChart3,
      color: "oklch(0.55 0.12 280)",
      bg: "oklch(0.97 0.02 280)",
      description: "تقارير وإحصائيات توزيع الاحتياط",
    },
    {
      href: "/import",
      label: "رفع جدول المعلمين",
      icon: Upload,
      color: "oklch(0.5 0.12 200)",
      bg: "oklch(0.97 0.02 200)",
      description: "استيراد الجدول من ملف XML",
    },
  ];

  return (
    <div className="space-y-6">
      {/* School Identity Header */}
      <div className="rounded-2xl overflow-hidden shadow-lg"
        style={{ background: "linear-gradient(135deg, oklch(0.18 0.07 145) 0%, oklch(0.28 0.09 145) 100%)" }}>
        <div className="px-6 py-8 text-center">
          {/* Decorative line */}
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="h-px flex-1 max-w-16" style={{ background: "oklch(0.75 0.13 75)" }} />
            <div className="w-3 h-3 rounded-full" style={{ background: "oklch(0.75 0.13 75)" }} />
            <div className="h-px flex-1 max-w-16" style={{ background: "oklch(0.75 0.13 75)" }} />
          </div>

          <p className="text-sm font-semibold mb-1" style={{ color: "oklch(0.75 0.13 75)" }}>
            سلطنة عُمان
          </p>
          <p className="text-sm mb-1" style={{ color: "oklch(0.85 0.01 120)" }}>
            وزارة التعليم
          </p>
          <p className="text-sm mb-2" style={{ color: "oklch(0.8 0.01 120)" }}>
            المديرية العامة للتعليم بمسقط
          </p>

          <div className="h-px max-w-xs mx-auto my-3" style={{ background: "oklch(0.75 0.13 75 / 0.4)" }} />

          <h1 className="text-xl font-bold mb-1" style={{ color: "oklch(0.95 0.01 120)" }}>
            مدرسة الخوير للتعليم الأساسي (5-9)
          </h1>
          <h2 className="text-base font-semibold" style={{ color: "oklch(0.75 0.13 75)" }}>
            توزيع احتياط المعلمين
          </h2>

          <div className="flex items-center justify-center gap-4 mt-4">
            <div className="h-px flex-1 max-w-16" style={{ background: "oklch(0.75 0.13 75)" }} />
            <div className="w-3 h-3 rounded-full" style={{ background: "oklch(0.75 0.13 75)" }} />
            <div className="h-px flex-1 max-w-16" style={{ background: "oklch(0.75 0.13 75)" }} />
          </div>
        </div>

        {/* Date bar */}
        <div className="px-6 py-3 flex items-center justify-between"
          style={{ background: "oklch(0.12 0.05 145)" }}>
          <span className="text-sm font-medium" style={{ color: "oklch(0.75 0.13 75)" }}>
            {dayNames[today.getDay()]}
          </span>
          <span className="text-sm" style={{ color: "oklch(0.75 0.01 120)" }}>
            {today.getDate()} {monthNames[today.getMonth()]} {today.getFullYear()}م
          </span>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-0 shadow-sm overflow-hidden">
          <CardContent className="p-0">
            <div className="p-4" style={{ background: "oklch(0.97 0.02 145)" }}>
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: "oklch(0.32 0.11 145)" }}>
                  <Users size={18} className="text-white" />
                </div>
                <TrendingUp size={14} style={{ color: "oklch(0.32 0.11 145)" }} />
              </div>
              <p className="text-2xl font-bold" style={{ color: "oklch(0.32 0.11 145)" }}>
                {totalTeachers}
              </p>
              <p className="text-xs mt-1" style={{ color: "oklch(0.45 0.05 145)" }}>
                إجمالي المعلمين
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm overflow-hidden">
          <CardContent className="p-0">
            <div className="p-4" style={{ background: "oklch(0.97 0.02 25)" }}>
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: "oklch(0.55 0.2 25)" }}>
                  <CalendarX size={18} className="text-white" />
                </div>
              </div>
              <p className="text-2xl font-bold" style={{ color: "oklch(0.55 0.2 25)" }}>
                {todayAbsenceCount}
              </p>
              <p className="text-xs mt-1" style={{ color: "oklch(0.45 0.1 25)" }}>
                غياب اليوم
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm overflow-hidden">
          <CardContent className="p-0">
            <div className="p-4" style={{ background: "oklch(0.97 0.02 75)" }}>
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: "oklch(0.65 0.13 75)" }}>
                  <Award size={18} className="text-white" />
                </div>
              </div>
              <p className="text-2xl font-bold" style={{ color: "oklch(0.55 0.13 75)" }}>
                {totalSubstitutesThisMonth}
              </p>
              <p className="text-xs mt-1" style={{ color: "oklch(0.45 0.08 75)" }}>
                حصص احتياط هذا الشهر
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm overflow-hidden">
          <CardContent className="p-0">
            <div className="p-4" style={{ background: "oklch(0.97 0.02 280)" }}>
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: "oklch(0.55 0.12 280)" }}>
                  <BookOpen size={18} className="text-white" />
                </div>
              </div>
              <p className="text-2xl font-bold" style={{ color: "oklch(0.45 0.12 280)" }}>
                {totalAbsencesThisMonth}
              </p>
              <p className="text-xs mt-1" style={{ color: "oklch(0.4 0.08 280)" }}>
                حالات غياب هذا الشهر
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-base font-bold mb-3" style={{ color: "oklch(0.25 0.06 145)" }}>
          الوصول السريع
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <Link key={action.href} href={action.href}>
                <Card className="border border-border hover:shadow-md transition-all duration-200 cursor-pointer group overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div
                        className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-110"
                        style={{ background: action.bg }}
                      >
                        <Icon size={20} style={{ color: action.color }} />
                      </div>
                      <div>
                        <p className="font-semibold text-sm text-foreground">{action.label}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{action.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Today's Absences Preview */}
      {todayAbsences && todayAbsences.length > 0 && (
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-bold flex items-center gap-2"
              style={{ color: "oklch(0.55 0.2 25)" }}>
              <CalendarX size={16} />
              غيابات اليوم ({dayNames[today.getDay()]})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {todayAbsences.map((absence: any) => (
                <div key={absence.id}
                  className="flex items-center justify-between p-3 rounded-lg"
                  style={{ background: "oklch(0.97 0.02 25)" }}>
                  <span className="font-semibold text-sm text-foreground">
                    {absence.teacher?.name || "—"}
                  </span>
                  <span className="text-xs px-2 py-1 rounded-full font-medium"
                    style={{ background: "oklch(0.55 0.2 25)", color: "white" }}>
                    {absence.assignments?.length || 0} حصة موزعة
                  </span>
                </div>
              ))}
            </div>
            <Link href="/daily-report">
              <Button variant="outline" size="sm" className="mt-3 w-full text-xs">
                عرض الجدول الكامل
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
