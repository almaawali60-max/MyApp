import { useState } from "react";
import { useAdminAuth } from "@/contexts/AdminAuthContext";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Shield, Users, Lock, Eye, EyeOff, AlertCircle, KeyRound, CheckCircle2, GraduationCap } from "lucide-react";

type LoginView = "portal" | "admin" | "head_teacher";

export default function Portal() {
  const { setMode, setAdminPassword, setSubjectFilter } = useAdminAuth();
  const [view, setView] = useState<LoginView>("portal");
  const [password, setPassword] = useState("");
  const [subject, setSubject] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  // حالة نسيت كلمة المرور
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [recoveryContact, setRecoveryContact] = useState("");
  const [recoveryStep, setRecoveryStep] = useState<"input" | "sent">("input");
  const [recoveryError, setRecoveryError] = useState("");

  const loginMutation = trpc.admin.login.useMutation({
    onSuccess: () => {
      setAdminPassword(password);
      setMode("admin");
      toast.success("مرحباً بك في لوحة الإدارة");
    },
    onError: (err) => {
      setError(err.message || "كلمة المرور غير صحيحة");
      setIsLoading(false);
    },
  });

  const headTeacherLoginMutation = trpc.admin.headTeacherLogin.useMutation({
    onSuccess: (data) => {
      setSubjectFilter(data.subject);
      setMode("head_teacher");
      toast.success(`مرحباً — تتابع مادة: ${data.subject}`);
    },
    onError: (err) => {
      setError(err.message || "كلمة المرور غير صحيحة");
      setIsLoading(false);
    },
  });

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) { setError("يرجى إدخال كلمة المرور"); return; }
    setError(""); setIsLoading(true);
    loginMutation.mutate({ password });
  };

  const handleHeadTeacherLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) { setError("يرجى إدخال كلمة المرور"); return; }
    if (!subject.trim()) { setError("يرجى تحديد المادة التي تتابعها"); return; }
    setError(""); setIsLoading(true);
    headTeacherLoginMutation.mutate({ password, subject });
  };

  const handleRecoveryRequest = () => {
    const email = "almaawali60@gmail.com";
    const phone = "0096892668828";
    const phone2 = "92668828";
    const trimmed = recoveryContact.trim();
    if (!trimmed) { setRecoveryError("يرجى إدخال البريد الإلكتروني أو رقم الهاتف"); return; }
    if (trimmed !== email && trimmed !== phone && trimmed !== phone2) {
      setRecoveryError("البريد أو الرقم غير مطابق للسجل المعتمد في النظام"); return;
    }
    setRecoveryError(""); setRecoveryStep("sent");
    toast.success("تم التحقق من هويتك");
  };

  const openForgotPassword = () => { setShowForgotPassword(true); setRecoveryStep("input"); setRecoveryContact(""); setRecoveryError(""); };
  const closeForgotPassword = () => { setShowForgotPassword(false); setRecoveryStep("input"); setRecoveryContact(""); setRecoveryError(""); };
  const goBack = () => { setView("portal"); setPassword(""); setSubject(""); setError(""); setShowPassword(false); };

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center p-4"
      dir="rtl"
      style={{ background: "linear-gradient(135deg, oklch(0.15 0.07 145) 0%, oklch(0.22 0.08 145) 50%, oklch(0.18 0.05 145) 100%)" }}
    >
      {/* نافذة نسيت كلمة المرور */}
      {showForgotPassword && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50 p-4"
          style={{ background: "rgba(0,0,0,0.75)" }}
          onClick={(e) => { if (e.target === e.currentTarget) closeForgotPassword(); }}
        >
          <div className="w-full max-w-sm rounded-2xl p-8 border-2 shadow-2xl" style={{ background: "oklch(0.2 0.06 145)", borderColor: "oklch(0.55 0.15 75)" }}>
            {recoveryStep === "input" ? (
              <>
                <div className="text-center mb-6">
                  <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: "oklch(0.65 0.13 75)" }}>
                    <KeyRound size={28} style={{ color: "oklch(0.15 0.05 145)" }} />
                  </div>
                  <h3 className="text-lg font-bold mb-1" style={{ color: "oklch(0.95 0.01 120)" }}>استعادة كلمة المرور</h3>
                  <p className="text-sm" style={{ color: "oklch(0.65 0.03 120)" }}>أدخل البريد الإلكتروني أو رقم الهاتف المعتمد</p>
                </div>
                <div className="space-y-4">
                  <Input type="text" placeholder="almaawali60@gmail.com أو 0096892668828" value={recoveryContact}
                    onChange={(e) => { setRecoveryContact(e.target.value); setRecoveryError(""); }}
                    className="h-12 text-sm border-2" style={{ background: "oklch(0.15 0.05 145)", borderColor: recoveryError ? "oklch(0.6 0.2 25)" : "oklch(0.35 0.08 145)", color: "oklch(0.95 0.01 120)" }} dir="ltr" autoFocus />
                  {recoveryError && (
                    <div className="flex items-center gap-2 text-sm p-3 rounded-lg" style={{ background: "oklch(0.25 0.08 25)", color: "oklch(0.75 0.15 25)" }}>
                      <AlertCircle size={16} /><span>{recoveryError}</span>
                    </div>
                  )}
                  <Button onClick={handleRecoveryRequest} className="w-full h-12 text-base font-bold" style={{ background: "oklch(0.65 0.13 75)", color: "oklch(0.15 0.05 145)" }}>إرسال رمز التحقق</Button>
                </div>
                <button onClick={closeForgotPassword} className="w-full mt-4 text-sm py-2 rounded-lg hover:opacity-80" style={{ color: "oklch(0.65 0.03 120)" }}>← إلغاء والعودة</button>
              </>
            ) : (
              <div className="text-center">
                <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: "oklch(0.35 0.15 145)" }}>
                  <CheckCircle2 size={32} style={{ color: "oklch(0.85 0.15 145)" }} />
                </div>
                <h3 className="text-lg font-bold mb-3" style={{ color: "oklch(0.95 0.01 120)" }}>تم التحقق من هويتك</h3>
                <p className="text-sm mb-2" style={{ color: "oklch(0.75 0.03 120)" }}>يرجى التواصل مع مسؤول النظام عبر:</p>
                <p className="text-sm font-medium mb-1" style={{ color: "oklch(0.75 0.1 75)" }}>البريد: almaawali60@gmail.com</p>
                <p className="text-sm font-medium mb-6" style={{ color: "oklch(0.75 0.1 75)" }}>الهاتف: 0096892668828</p>
                <Button onClick={closeForgotPassword} className="w-full h-11" style={{ background: "oklch(0.65 0.13 75)", color: "oklch(0.15 0.05 145)" }}>العودة لصفحة الدخول</Button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Header */}
      <div className="text-center mb-8">
        <div className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-5 shadow-2xl border-4" style={{ background: "oklch(0.75 0.13 75)", borderColor: "oklch(0.85 0.1 75)" }}>
          <svg viewBox="0 0 40 40" width="48" height="48" fill="none">
            <rect x="8" y="18" width="24" height="16" rx="2" fill="oklch(0.18 0.07 145)" />
            <polygon points="4,18 20,6 36,18" fill="oklch(0.18 0.07 145)" />
            <rect x="16" y="24" width="8" height="10" rx="1" fill="oklch(0.75 0.13 75)" />
            <rect x="10" y="21" width="5" height="5" rx="0.5" fill="oklch(0.75 0.13 75)" />
            <rect x="25" y="21" width="5" height="5" rx="0.5" fill="oklch(0.75 0.13 75)" />
          </svg>
        </div>
        <p className="text-sm mb-1" style={{ color: "oklch(0.75 0.13 75)" }}>سلطنة عُمان — وزارة التعليم</p>
        <p className="text-xs mb-4" style={{ color: "oklch(0.65 0.03 120)" }}>المديرية العامة للتعليم بمسقط</p>
        <h1 className="text-2xl font-bold mb-1" style={{ color: "oklch(0.95 0.01 120)" }}>مدرسة الخوير للتعليم الأساسي (5-9)</h1>
        <p className="text-base" style={{ color: "oklch(0.75 0.13 75)" }}>نظام توزيع الاحتياط اليومي</p>
      </div>

      {/* ===== بوابة الاختيار ===== */}
      {view === "portal" && (
        <div className="w-full max-w-md space-y-4">
          {/* دخول المعلمين - بدون كلمة مرور */}
          <button onClick={() => setMode("teacher")}
            className="w-full group rounded-2xl p-6 text-right transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl border-2"
            style={{ background: "oklch(0.22 0.06 145)", borderColor: "oklch(0.35 0.08 145)" }}>
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform" style={{ background: "oklch(0.32 0.1 145)" }}>
                <Users size={28} style={{ color: "oklch(0.75 0.13 75)" }} />
              </div>
              <div className="flex-1">
                <h2 className="text-lg font-bold mb-1" style={{ color: "oklch(0.95 0.01 120)" }}>دخول المعلمين</h2>
                <p className="text-sm" style={{ color: "oklch(0.65 0.03 120)" }}>عرض جدول الاحتياط والإحصائيات — بدون كلمة مرور</p>
              </div>
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "oklch(0.32 0.1 145)" }}>
                <span style={{ color: "oklch(0.75 0.13 75)" }}>←</span>
              </div>
            </div>
          </button>

          {/* دخول المعلم الأول - كلمة مرور خاصة + تحديد المادة */}
          <button onClick={() => setView("head_teacher")}
            className="w-full group rounded-2xl p-6 text-right transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl border-2"
            style={{ background: "oklch(0.22 0.06 145)", borderColor: "oklch(0.4 0.12 200)" }}>
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform" style={{ background: "oklch(0.3 0.1 200)" }}>
                <GraduationCap size={28} style={{ color: "oklch(0.75 0.12 200)" }} />
              </div>
              <div className="flex-1">
                <h2 className="text-lg font-bold mb-1" style={{ color: "oklch(0.95 0.01 120)" }}>دخول المعلم الأول</h2>
                <p className="text-sm" style={{ color: "oklch(0.65 0.03 120)" }}>متابعة نصاب فريقك واحتياط مادتك فقط</p>
              </div>
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "oklch(0.3 0.1 200)" }}>
                <Lock size={16} style={{ color: "oklch(0.75 0.12 200)" }} />
              </div>
            </div>
          </button>

          {/* دخول الإدارة */}
          <button onClick={() => setView("admin")}
            className="w-full group rounded-2xl p-6 text-right transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl border-2"
            style={{ background: "oklch(0.22 0.06 145)", borderColor: "oklch(0.55 0.15 75)" }}>
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform" style={{ background: "oklch(0.65 0.13 75)" }}>
                <Shield size={28} style={{ color: "oklch(0.15 0.05 145)" }} />
              </div>
              <div className="flex-1">
                <h2 className="text-lg font-bold mb-1" style={{ color: "oklch(0.95 0.01 120)" }}>دخول الإدارة</h2>
                <p className="text-sm" style={{ color: "oklch(0.65 0.03 120)" }}>صلاحيات كاملة — تسجيل الغياب، التوزيع، الإعدادات</p>
              </div>
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "oklch(0.65 0.13 75)" }}>
                <Lock size={16} style={{ color: "oklch(0.15 0.05 145)" }} />
              </div>
            </div>
          </button>
        </div>
      )}

      {/* ===== نموذج دخول الإدارة ===== */}
      {view === "admin" && (
        <div className="w-full max-w-sm rounded-2xl p-8 border-2" style={{ background: "oklch(0.2 0.06 145)", borderColor: "oklch(0.55 0.15 75)" }}>
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: "oklch(0.65 0.13 75)" }}>
              <Shield size={32} style={{ color: "oklch(0.15 0.05 145)" }} />
            </div>
            <h2 className="text-xl font-bold" style={{ color: "oklch(0.95 0.01 120)" }}>دخول الإدارة</h2>
            <p className="text-sm mt-1" style={{ color: "oklch(0.65 0.03 120)" }}>أدخل كلمة المرور للمتابعة</p>
          </div>
          <form onSubmit={handleAdminLogin} className="space-y-4">
            <div className="relative">
              <Input type={showPassword ? "text" : "password"} placeholder="كلمة المرور" value={password}
                onChange={(e) => { setPassword(e.target.value); setError(""); }}
                className="text-right pr-4 pl-10 h-12 text-base border-2"
                style={{ background: "oklch(0.15 0.05 145)", borderColor: error ? "oklch(0.6 0.2 25)" : "oklch(0.35 0.08 145)", color: "oklch(0.95 0.01 120)" }}
                dir="ltr" autoFocus />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100" style={{ color: "oklch(0.75 0.01 120)" }}>
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            {error && (
              <div className="flex items-center gap-2 text-sm p-3 rounded-lg" style={{ background: "oklch(0.25 0.08 25)", color: "oklch(0.75 0.15 25)" }}>
                <AlertCircle size={16} /><span>{error}</span>
              </div>
            )}
            <Button type="submit" disabled={isLoading} className="w-full h-12 text-base font-bold" style={{ background: "oklch(0.65 0.13 75)", color: "oklch(0.15 0.05 145)" }}>
              {isLoading ? "جاري التحقق..." : "دخول"}
            </Button>
          </form>
          <div className="mt-4">
            <button type="button" onClick={openForgotPassword}
              className="w-full text-sm py-2.5 rounded-xl transition-all hover:opacity-90 flex items-center justify-center gap-2 border"
              style={{ color: "oklch(0.75 0.1 75)", borderColor: "oklch(0.4 0.1 75)", background: "oklch(0.18 0.06 145)" }}>
              <KeyRound size={15} />نسيت كلمة المرور؟
            </button>
          </div>
          <button onClick={goBack} className="w-full mt-3 text-sm py-2 rounded-lg transition-colors hover:opacity-80" style={{ color: "oklch(0.65 0.03 120)" }}>
            ← العودة للبوابة الرئيسية
          </button>
        </div>
      )}

      {/* ===== نموذج دخول المعلم الأول ===== */}
      {view === "head_teacher" && (
        <div className="w-full max-w-sm rounded-2xl p-8 border-2" style={{ background: "oklch(0.2 0.06 145)", borderColor: "oklch(0.4 0.12 200)" }}>
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: "oklch(0.3 0.1 200)" }}>
              <GraduationCap size={32} style={{ color: "oklch(0.75 0.12 200)" }} />
            </div>
            <h2 className="text-xl font-bold" style={{ color: "oklch(0.95 0.01 120)" }}>دخول المعلم الأول</h2>
            <p className="text-sm mt-1" style={{ color: "oklch(0.65 0.03 120)" }}>حدد المادة وأدخل كلمة المرور</p>
          </div>
          <form onSubmit={handleHeadTeacherLogin} className="space-y-4">
            <Input type="text" placeholder="اسم المادة (مثال: رياضيات)" value={subject}
              onChange={(e) => { setSubject(e.target.value); setError(""); }}
              className="text-right h-12 text-base border-2"
              style={{ background: "oklch(0.15 0.05 145)", borderColor: error ? "oklch(0.6 0.2 25)" : "oklch(0.35 0.08 145)", color: "oklch(0.95 0.01 120)" }} />
            <div className="relative">
              <Input type={showPassword ? "text" : "password"} placeholder="كلمة المرور" value={password}
                onChange={(e) => { setPassword(e.target.value); setError(""); }}
                className="text-right pr-4 pl-10 h-12 text-base border-2"
                style={{ background: "oklch(0.15 0.05 145)", borderColor: error ? "oklch(0.6 0.2 25)" : "oklch(0.35 0.08 145)", color: "oklch(0.95 0.01 120)" }}
                dir="ltr" />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100" style={{ color: "oklch(0.75 0.01 120)" }}>
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            {error && (
              <div className="flex items-center gap-2 text-sm p-3 rounded-lg" style={{ background: "oklch(0.25 0.08 25)", color: "oklch(0.75 0.15 25)" }}>
                <AlertCircle size={16} /><span>{error}</span>
              </div>
            )}
            <Button type="submit" disabled={isLoading} className="w-full h-12 text-base font-bold" style={{ background: "oklch(0.3 0.1 200)", color: "oklch(0.95 0.01 120)" }}>
              {isLoading ? "جاري التحقق..." : "دخول"}
            </Button>
          </form>
          <div className="mt-3 p-3 rounded-xl text-xs text-center" style={{ background: "oklch(0.18 0.05 145)", color: "oklch(0.6 0.03 120)" }}>
            كلمة مرور المعلم الأول = كلمة مرور الإدارة + "_ht"
          </div>
          <button onClick={goBack} className="w-full mt-3 text-sm py-2 rounded-lg transition-colors hover:opacity-80" style={{ color: "oklch(0.65 0.03 120)" }}>
            ← العودة للبوابة الرئيسية
          </button>
        </div>
      )}

      {/* Footer */}
      <p className="text-center text-xs mt-8" style={{ color: "oklch(0.4 0.03 120)" }}>
        نظام توزيع احتياط المعلمين — مدرسة الخوير الأساسية (5-9)
      </p>
    </div>
  );
}
