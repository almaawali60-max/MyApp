import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Plus, Pencil, Trash2, X, Save, Layers, RefreshCw, Tag } from "lucide-react";
import { toast } from "sonner";

type Domain = {
  id: number;
  domainKey: string;
  domainLabel: string;
  specialties: string[];
  color: string | null;
  isCore: boolean;
};

const DEFAULT_COLORS = [
  "oklch(0.45 0.18 140)",
  "oklch(0.5 0.2 30)",
  "oklch(0.5 0.18 200)",
  "oklch(0.5 0.2 260)",
  "oklch(0.55 0.18 155)",
  "oklch(0.5 0.18 60)",
  "oklch(0.5 0.2 310)",
  "oklch(0.5 0.18 15)",
];

type DialogState = {
  open: boolean;
  mode: "add" | "edit";
  domain?: Domain;
};

export default function SpecialtyDomains() {
  const utils = trpc.useUtils();

  const { data: domains, isLoading } = trpc.specialtyDomains.getAll.useQuery();

  const [dialog, setDialog] = useState<DialogState>({ open: false, mode: "add" });
  const [deleteKey, setDeleteKey] = useState<string | null>(null);

  // Form state
  const [formKey, setFormKey] = useState("");
  const [formLabel, setFormLabel] = useState("");
  const [formSpecialties, setFormSpecialties] = useState<string[]>([]);
  const [formSpecialtyInput, setFormSpecialtyInput] = useState("");
  const [formColor, setFormColor] = useState(DEFAULT_COLORS[0]);
  const [formIsCore, setFormIsCore] = useState(false);

  const upsertMutation = trpc.specialtyDomains.upsert.useMutation({
    onSuccess: () => {
      utils.specialtyDomains.getAll.invalidate();
      toast.success(dialog.mode === "add" ? "تم إضافة المجال بنجاح" : "تم تعديل المجال بنجاح");
      setDialog({ open: false, mode: "add" });
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.specialtyDomains.delete.useMutation({
    onSuccess: () => {
      utils.specialtyDomains.getAll.invalidate();
      toast.success("تم حذف المجال");
      setDeleteKey(null);
    },
    onError: (e) => toast.error(e.message),
  });

  const seedMutation = trpc.specialtyDomains.seedDefaults.useMutation({
    onSuccess: () => {
      utils.specialtyDomains.getAll.invalidate();
      toast.success("تم تحميل المجالات الافتراضية");
    },
    onError: (e) => toast.error(e.message),
  });

  function openAddDialog() {
    setFormKey("");
    setFormLabel("");
    setFormSpecialties([]);
    setFormSpecialtyInput("");
    setFormColor(DEFAULT_COLORS[0]);
    setFormIsCore(false);
    setDialog({ open: true, mode: "add" });
  }

  function openEditDialog(domain: Domain) {
    setFormKey(domain.domainKey);
    setFormLabel(domain.domainLabel);
    setFormSpecialties([...domain.specialties]);
    setFormSpecialtyInput("");
    setFormColor(domain.color || DEFAULT_COLORS[0]);
    setFormIsCore(domain.isCore);
    setDialog({ open: true, mode: "edit", domain });
  }

  function addSpecialty() {
    const trimmed = formSpecialtyInput.trim();
    if (!trimmed) return;
    if (!formSpecialties.includes(trimmed)) {
      setFormSpecialties(prev => [...prev, trimmed]);
    }
    setFormSpecialtyInput("");
  }

  function removeSpecialty(s: string) {
    setFormSpecialties(prev => prev.filter(x => x !== s));
  }

  function handleSave() {
    if (!formLabel.trim()) {
      toast.error("يرجى إدخال اسم المجال");
      return;
    }
    const key = dialog.mode === "edit" && dialog.domain
      ? dialog.domain.domainKey
      : (formKey.trim() || formLabel.trim().replace(/\s+/g, "_"));
    upsertMutation.mutate({
      domainKey: key,
      domainLabel: formLabel.trim(),
      specialties: formSpecialties,
      color: formColor,
      isCore: formIsCore,
    });
  }

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
            <Layers className="w-5 h-5 text-primary" />
            إدارة مجالات التخصص
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            صنّف التخصصات في مجالات لضمان دقة التوزيع وتطابق التخصصات
          </p>
        </div>
        <div className="flex gap-2">
          {(!domains || domains.length === 0) && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => seedMutation.mutate()}
              disabled={seedMutation.isPending}
            >
              <RefreshCw className="w-4 h-4 ml-1" />
              تحميل الافتراضية
            </Button>
          )}
          <Button size="sm" onClick={openAddDialog}>
            <Plus className="w-4 h-4 ml-1" />
            إضافة مجال
          </Button>
        </div>
      </div>

      {/* Domains List */}
      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">جارٍ التحميل...</div>
      ) : !domains || domains.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <Layers className="w-10 h-10 mx-auto mb-3 text-muted-foreground/40" />
            <p className="text-muted-foreground mb-4">لا توجد مجالات مضافة بعد</p>
            <Button variant="outline" onClick={() => seedMutation.mutate()} disabled={seedMutation.isPending}>
              <RefreshCw className="w-4 h-4 ml-1" />
              تحميل المجالات الافتراضية
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {(domains as Domain[]).map(domain => (
            <Card key={domain.domainKey} className="relative group">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full flex-shrink-0"
                      style={{ background: domain.color || "oklch(0.5 0.1 200)" }}
                    />
                    <CardTitle className="text-base">{domain.domainLabel}</CardTitle>
                    {domain.isCore && (
                      <Badge variant="secondary" className="text-xs">أساسية</Badge>
                    )}
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => openEditDialog(domain)}
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-destructive hover:text-destructive"
                      onClick={() => setDeleteKey(domain.domainKey)}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
                <CardDescription className="text-xs">
                  المفتاح: <code className="bg-muted px-1 rounded">{domain.domainKey}</code>
                </CardDescription>
              </CardHeader>
              <CardContent>
                {domain.specialties.length === 0 ? (
                  <p className="text-xs text-muted-foreground">لا توجد تخصصات مضافة</p>
                ) : (
                  <div className="flex flex-wrap gap-1.5">
                    {domain.specialties.map(s => (
                      <Badge
                        key={s}
                        variant="outline"
                        className="text-xs"
                        style={{ borderColor: domain.color || undefined, color: domain.color || undefined }}
                      >
                        <Tag className="w-2.5 h-2.5 ml-0.5" />
                        {s}
                      </Badge>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialog.open} onOpenChange={open => setDialog(d => ({ ...d, open }))}>
        <DialogContent className="sm:max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle>
              {dialog.mode === "add" ? "إضافة مجال جديد" : `تعديل: ${dialog.domain?.domainLabel}`}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2 max-h-[60vh] overflow-y-auto">
            <div>
              <Label className="mb-1 block">اسم المجال *</Label>
              <Input
                value={formLabel}
                onChange={e => setFormLabel(e.target.value)}
                placeholder="مثال: مجال العلوم، التربية الإسلامية..."
                autoFocus
              />
            </div>

            {dialog.mode === "add" && (
              <div>
                <Label className="mb-1 block">
                  المفتاح الفريد
                  <span className="text-xs text-muted-foreground mr-1">(اختياري — يُولَّد تلقائياً)</span>
                </Label>
                <Input
                  value={formKey}
                  onChange={e => setFormKey(e.target.value)}
                  placeholder="مثال: علوم، مهارات_فردية..."
                  dir="ltr"
                />
              </div>
            )}

            <div>
              <Label className="mb-1 block">التخصصات المنتمية لهذا المجال</Label>
              <div className="flex gap-2 mb-2">
                <Input
                  value={formSpecialtyInput}
                  onChange={e => setFormSpecialtyInput(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addSpecialty(); } }}
                  placeholder="اكتب تخصصاً واضغط Enter أو أضف..."
                />
                <Button type="button" variant="outline" onClick={addSpecialty}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              {formSpecialties.length > 0 ? (
                <div className="flex flex-wrap gap-1.5 p-2 bg-muted/30 rounded min-h-[40px]">
                  {formSpecialties.map(s => (
                    <Badge key={s} variant="secondary" className="text-xs gap-1">
                      {s}
                      <button onClick={() => removeSpecialty(s)} className="hover:text-destructive">
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground p-2">لم تُضف أي تخصصات بعد</p>
              )}
            </div>

            <div>
              <Label className="mb-2 block">لون المجال</Label>
              <div className="flex flex-wrap gap-2">
                {DEFAULT_COLORS.map(c => (
                  <button
                    key={c}
                    onClick={() => setFormColor(c)}
                    className={`w-7 h-7 rounded-full border-2 transition-all ${formColor === c ? "border-foreground scale-110" : "border-transparent"}`}
                    style={{ background: c }}
                    title={c}
                  />
                ))}
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Switch
                id="isCore"
                checked={formIsCore}
                onCheckedChange={setFormIsCore}
              />
              <Label htmlFor="isCore" className="cursor-pointer">
                مادة أساسية (تُعطى أولوية في التطابق)
              </Label>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDialog(d => ({ ...d, open: false }))}>
              <X className="w-4 h-4 ml-1" />
              إلغاء
            </Button>
            <Button onClick={handleSave} disabled={upsertMutation.isPending}>
              <Save className="w-4 h-4 ml-1" />
              {dialog.mode === "add" ? "إضافة" : "حفظ"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <AlertDialog open={!!deleteKey} onOpenChange={open => !open && setDeleteKey(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد الحذف</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف هذا المجال؟ لن يؤثر ذلك على البيانات الموجودة لكن سيُزيل التصنيف من الخوارزمية.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteKey && deleteMutation.mutate({ domainKey: deleteKey })}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
