import { useState, useMemo } from "react";
import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowRight, Plus, Pencil, Trash2, BookOpen, Save, X } from "lucide-react";
import { toast } from "sonner";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"] as const;
type DayOfWeek = (typeof DAYS)[number];

const DAY_LABELS: Record<DayOfWeek, string> = {
  Sunday: "الأحد",
  Monday: "الاثنين",
  Tuesday: "الثلاثاء",
  Wednesday: "الأربعاء",
  Thursday: "الخميس",
};

const PERIODS = [1, 2, 3, 4, 5, 6, 7, 8];

type ScheduleEntry = {
  id: number;
  teacherId: number;
  dayOfWeek: DayOfWeek;
  periodNumber: number;
  subjectName: string | null;
  className: string | null;
};

type CellDialogState = {
  open: boolean;
  mode: "add" | "edit";
  day: DayOfWeek;
  period: number;
  entry?: ScheduleEntry;
};

export default function TeacherScheduleEditor() {
  const params = useParams<{ id: string }>();
  const teacherId = parseInt(params.id || "0");
  const [, navigate] = useLocation();
  const [dialog, setDialog] = useState<CellDialogState>({
    open: false,
    mode: "add",
    day: "Sunday",
    period: 1,
  });
  const [formSubject, setFormSubject] = useState("");
  const [formClass, setFormClass] = useState("");
  const [formDay, setFormDay] = useState<DayOfWeek>("Sunday");
  const [formPeriod, setFormPeriod] = useState(1);

  const utils = trpc.useUtils();

  const { data: teacher } = trpc.teachers.getById.useQuery({ id: teacherId });
  const { data: scheduleRaw, isLoading } = trpc.teachers.getScheduleGrid.useQuery(
    { teacherId },
    { enabled: teacherId > 0 }
  );

  // بناء خريطة الجدول: day+period → entry
  const scheduleMap = useMemo(() => {
    const map = new Map<string, ScheduleEntry>();
    if (scheduleRaw) {
      for (const e of scheduleRaw as ScheduleEntry[]) {
        map.set(`${e.dayOfWeek}-${e.periodNumber}`, e);
      }
    }
    return map;
  }, [scheduleRaw]);

  const addMutation = trpc.teachers.addScheduleEntry.useMutation({
    onSuccess: () => {
      utils.teachers.getScheduleGrid.invalidate({ teacherId });
      utils.teachers.getById.invalidate({ id: teacherId });
      utils.teachers.getScheduleByDay.invalidate({ teacherId }); // تحديث فوري لصفحة الغياب
      toast.success("تمت إضافة الحصة بنجاح");
      setDialog(d => ({ ...d, open: false }));
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.teachers.updateScheduleEntry.useMutation({
    onSuccess: () => {
      utils.teachers.getScheduleGrid.invalidate({ teacherId });
      utils.teachers.getScheduleByDay.invalidate({ teacherId }); // تحديث فوري لصفحة الغياب
      toast.success("تم تعديل الحصة بنجاح");
      setDialog(d => ({ ...d, open: false }));
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.teachers.deleteScheduleEntry.useMutation({
    onSuccess: () => {
      utils.teachers.getScheduleGrid.invalidate({ teacherId });
      utils.teachers.getById.invalidate({ id: teacherId });
      utils.teachers.getScheduleByDay.invalidate({ teacherId }); // تحديث فوري لصفحة الغياب
      toast.success("تم حذف الحصة");
    },
    onError: (e) => toast.error(e.message),
  });

  function openAddDialog(day: DayOfWeek, period: number) {
    setFormSubject("");
    setFormClass("");
    setFormDay(day);
    setFormPeriod(period);
    setDialog({ open: true, mode: "add", day, period });
  }

  function openEditDialog(entry: ScheduleEntry) {
    setFormSubject(entry.subjectName || "");
    setFormClass(entry.className || "");
    setFormDay(entry.dayOfWeek);
    setFormPeriod(entry.periodNumber);
    setDialog({ open: true, mode: "edit", day: entry.dayOfWeek, period: entry.periodNumber, entry });
  }

  function handleSave() {
    if (dialog.mode === "add") {
      addMutation.mutate({
        teacherId,
        dayOfWeek: formDay,
        periodNumber: formPeriod,
        subjectName: formSubject || undefined,
        className: formClass || undefined,
      });
    } else if (dialog.entry) {
      updateMutation.mutate({
        id: dialog.entry.id,
        subjectName: formSubject || undefined,
        className: formClass || undefined,
      });
    }
  }

  function handleDelete(entry: ScheduleEntry) {
    if (confirm(`هل تريد حذف الحصة ${entry.periodNumber} يوم ${DAY_LABELS[entry.dayOfWeek]}؟`)) {
      deleteMutation.mutate({ id: entry.id });
    }
  }

  const totalPeriods = scheduleRaw?.length || 0;

  if (!teacherId) {
    return (
      <div className="p-8 text-center text-muted-foreground">معرّف المعلم غير صحيح</div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto" dir="rtl">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="sm" onClick={() => navigate("/teachers")}>
          <ArrowRight className="w-4 h-4 ml-1" />
          العودة
        </Button>
        <div>
          <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-primary" />
            تعديل جدول المعلم
          </h1>
          {teacher && (
            <p className="text-sm text-muted-foreground mt-0.5">
              {teacher.name} — النصاب الحالي:{" "}
              <Badge variant="secondary">{totalPeriods} حصة</Badge>
            </p>
          )}
        </div>
      </div>

      {/* Grid */}
      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">جارٍ التحميل...</div>
      ) : (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">الجدول الأسبوعي (انقر على خلية لتعديلها أو إضافة حصة)</CardTitle>
          </CardHeader>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="bg-muted/50">
                  <th className="border border-border p-2 text-center font-semibold w-16">الحصة</th>
                  {DAYS.map(day => (
                    <th key={day} className="border border-border p-2 text-center font-semibold min-w-[140px]">
                      {DAY_LABELS[day]}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {PERIODS.map(period => (
                  <tr key={period} className={period >= 7 ? "bg-amber-50/30 dark:bg-amber-950/10" : ""}>
                    <td className="border border-border p-2 text-center font-bold text-muted-foreground">
                      {period}
                      {period >= 7 && (
                        <span className="block text-xs text-amber-600 dark:text-amber-400">متأخرة</span>
                      )}
                    </td>
                    {DAYS.map(day => {
                      const key = `${day}-${period}`;
                      const entry = scheduleMap.get(key);
                      return (
                        <td key={day} className="border border-border p-1 align-top">
                          {entry ? (
                            <div className="bg-primary/10 rounded p-1.5 group relative min-h-[52px]">
                              <div className="font-medium text-xs text-primary leading-tight">
                                {entry.subjectName || "—"}
                              </div>
                              {entry.className && (
                                <div className="text-xs text-muted-foreground mt-0.5">
                                  {entry.className}
                                </div>
                              )}
                              <div className="absolute top-1 left-1 flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button
                                  onClick={() => openEditDialog(entry)}
                                  className="p-0.5 rounded bg-background/80 hover:bg-primary/20 text-primary"
                                  title="تعديل"
                                >
                                  <Pencil className="w-3 h-3" />
                                </button>
                                <button
                                  onClick={() => handleDelete(entry)}
                                  className="p-0.5 rounded bg-background/80 hover:bg-destructive/20 text-destructive"
                                  title="حذف"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          ) : (
                            <button
                              onClick={() => openAddDialog(day, period)}
                              className="w-full min-h-[52px] flex items-center justify-center text-muted-foreground/40 hover:text-primary hover:bg-primary/5 rounded transition-colors"
                              title="إضافة حصة"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {/* Legend */}
      <div className="mt-4 flex flex-wrap gap-3 text-xs text-muted-foreground">
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-primary/10 border border-primary/30 inline-block" />
          حصة مسجّلة (مرّر الماوس للتعديل/الحذف)
        </span>
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-amber-50 border border-amber-200 inline-block" />
          حصة متأخرة (7 أو 8) — تُراعى في منع الاحتياط
        </span>
      </div>

      {/* Dialog */}
      <Dialog open={dialog.open} onOpenChange={open => setDialog(d => ({ ...d, open }))}>
        <DialogContent className="sm:max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>
              {dialog.mode === "add" ? "إضافة حصة جديدة" : "تعديل الحصة"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            {dialog.mode === "add" && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium mb-1 block">اليوم</label>
                  <Select value={formDay} onValueChange={v => setFormDay(v as DayOfWeek)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {DAYS.map(d => (
                        <SelectItem key={d} value={d}>{DAY_LABELS[d]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">رقم الحصة</label>
                  <Select value={String(formPeriod)} onValueChange={v => setFormPeriod(Number(v))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PERIODS.map(p => (
                        <SelectItem key={p} value={String(p)}>الحصة {p}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
            {dialog.mode === "edit" && (
              <div className="text-sm text-muted-foreground bg-muted/50 rounded p-2">
                يوم {DAY_LABELS[dialog.day]} — الحصة {dialog.period}
              </div>
            )}
            <div>
              <label className="text-sm font-medium mb-1 block">اسم المادة</label>
              <Input
                value={formSubject}
                onChange={e => setFormSubject(e.target.value)}
                placeholder="مثال: رياضيات، علوم، لغة عربية..."
                autoFocus
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">الفصل / الشعبة</label>
              <Input
                value={formClass}
                onChange={e => setFormClass(e.target.value)}
                placeholder="مثال: 5أ، 9ب..."
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDialog(d => ({ ...d, open: false }))}>
              <X className="w-4 h-4 ml-1" />
              إلغاء
            </Button>
            <Button
              onClick={handleSave}
              disabled={addMutation.isPending || updateMutation.isPending}
            >
              <Save className="w-4 h-4 ml-1" />
              {dialog.mode === "add" ? "إضافة" : "حفظ التعديل"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
