// ============================================================================
// EmergencyPanel.tsx - لوحة الطوارئ القصوى
// للاستخدام في حالات العجز الشديد (9+ غياب، 20+ حصة)
// ============================================================================
import React, { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertTriangle,
  ShieldAlert,
  Siren,
  RotateCcw,
  CheckCircle,
  Zap,
  TrendingUp,
  Users,
  Clock,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { toast } from "sonner";

export default function EmergencyPanel() {
  const utils = trpc.useUtils();

  const today = new Date().toISOString().split("T")[0];
  const [selectedDate, setSelectedDate] = useState(today);
  const [emergencyReason, setEmergencyReason] = useState("");
  const [showBreakConfirm, setShowBreakConfirm] = useState(false);
  const [showForceConfirm, setShowForceConfirm] = useState(false);
  const [showRestoreConfirm, setShowRestoreConfirm] = useState(false);

  // إحصائيات اليوم
  const { data: stats, refetch: refetchStats } = trpc.emergency.getStats.useQuery(
    { date: selectedDate },
    { refetchInterval: 30000 }
  );

  // الجولة الحالية
  const { data: currentRound, refetch: refetchRound } = trpc.rotationRounds.getCurrent.useQuery();

  const isEmergencyActive = currentRound?.name?.includes("[طوارئ]");

  // =================== Mutations ===================

  const breakLimits = trpc.emergency.breakAllLimits.useMutation({
    onSuccess: (data) => {
      toast.success("تم تفعيل كسر القيود الشامل", {
        description: `السقف الجديد: ${data.details.emergencyCap} حصص (كان ${data.details.normalCap})`,
      });
      refetchRound();
      refetchStats();
      setShowBreakConfirm(false);
      setEmergencyReason("");
    },
    onError: (error) => {
      toast.error("فشل تفعيل الطوارئ", { description: error.message });
    },
  });

  const forceDistribute = trpc.emergency.forceDistributeRemaining.useMutation({
    onSuccess: (data) => {
      if (data.processed > 0) {
        toast.success(`تم توزيع ${data.processed} حصة قسراً`, {
          description: data.message,
        });
      }
      if (data.errors > 0) {
        toast.error(`${data.errors} حصة لم تُوزَّع`, {
          description: data.errorDetails?.slice(0, 3).join(" | "),
        });
      }
      refetchStats();
      setShowForceConfirm(false);
      setEmergencyReason("");
    },
    onError: (error) => {
      toast.error("فشل التوزيع القسري", { description: error.message });
    },
  });

  const restoreLimits = trpc.emergency.restoreNormalLimits.useMutation({
    onSuccess: (data) => {
      toast.success("تم إعادة القيود الطبيعية", { description: data.message });
      refetchRound();
      refetchStats();
      setShowRestoreConfirm(false);
    },
    onError: (error) => {
      toast.error("فشل إعادة القيود", { description: error.message });
    },
  });

  return (
    <div className="space-y-6 p-6" dir="rtl">
      {/* ===== رأس الطوارئ ===== */}
      <div
        className={`p-5 rounded-xl border-2 shadow-md ${
          isEmergencyActive
            ? "bg-red-950/40 border-red-500"
            : "bg-yellow-950/30 border-yellow-500"
        }`}
      >
        <div className="flex items-center gap-4">
          <Siren
            className={`w-10 h-10 ${
              isEmergencyActive ? "text-red-400 animate-pulse" : "text-yellow-400"
            }`}
          />
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              {isEmergencyActive ? "⚠️ وضع الطوارئ نشط!" : "لوحة الطوارئ القصوى"}
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              {isEmergencyActive
                ? `السقف الفردي مرفوع إلى 6 حصص — الجولة: ${currentRound?.name}`
                : "للاستخدام في حالات العجز الشديد فقط (9+ غياب / 20+ حصة شاغرة)"}
            </p>
          </div>
          {isEmergencyActive && (
            <Badge variant="destructive" className="mr-auto text-base px-3 py-1">
              طوارئ نشطة
            </Badge>
          )}
        </div>
      </div>

      {/* ===== اختيار التاريخ ===== */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Clock className="w-4 h-4" />
            تاريخ الطوارئ
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-48 text-center"
              dir="ltr"
            />
            <Button variant="outline" size="sm" onClick={() => refetchStats()}>
              تحديث الإحصائيات
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* ===== إحصائيات العجز ===== */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-400" />
            حالة العجز الحالية
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <StatBox
              label="إجمالي الغيابات"
              value={stats?.totalAbsences ?? 0}
              color="blue"
              icon={<Users className="w-5 h-5" />}
            />
            <StatBox
              label="الحصص الموزعة"
              value={stats?.distributed ?? 0}
              color="green"
              icon={<CheckCircle className="w-5 h-5" />}
            />
            <StatBox
              label="الحصص الشاغرة (تقديري)"
              value={stats?.vacant ?? 0}
              color={stats?.vacant && stats.vacant > 0 ? "red" : "green"}
              icon={<AlertTriangle className="w-5 h-5" />}
            />
          </div>
        </CardContent>
      </Card>

      {/* ===== خطوة 1: كسر القيود ===== */}
      <Card className={isEmergencyActive ? "border-red-500/50" : "border-yellow-500/50"}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-yellow-400">
            <ShieldAlert className="w-5 h-5" />
            الخطوة 1: تفعيل كسر القيود الشامل
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            يرفع السقف الفردي لجميع المعلمين من <strong>4 حصص</strong> إلى{" "}
            <strong>6 حصص</strong> مؤقتاً. يُستخدم عند عجز 4+ حصص.
          </p>
          <div className="bg-muted/30 rounded-lg p-3 text-sm space-y-1">
            <p className="text-green-400 font-medium">✅ القيود التي تُرفع:</p>
            <p className="text-muted-foreground mr-4">• السقف الفردي: 4 → 6 حصص</p>
            <p className="text-muted-foreground mr-4">• حماية النصاب 22+: تُتجاهل في التوزيع القسري</p>
            <p className="text-red-400 font-medium mt-2">❌ القيود الثابتة (لا تُكسر):</p>
            <p className="text-muted-foreground mr-4">• حمد عبدالله (60002) - حظر مطلق</p>
            <p className="text-muted-foreground mr-4">• لا يُكلف المعلم بحصتين في نفس الوقت</p>
            <p className="text-muted-foreground mr-4">• لا يُكلف الغائب نفسه</p>
          </div>
          <Button
            className="w-full bg-yellow-600 hover:bg-yellow-700 text-white"
            disabled={isEmergencyActive || breakLimits.isPending}
            onClick={() => setShowBreakConfirm(true)}
          >
            <Zap className="w-4 h-4 ml-2" />
            {isEmergencyActive ? "الطوارئ مفعّلة بالفعل" : "تفعيل كسر القيود"}
          </Button>
        </CardContent>
      </Card>

      {/* ===== خطوة 2: التوزيع القسري ===== */}
      <Card className="border-red-500/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-400">
            <TrendingUp className="w-5 h-5" />
            الخطوة 2: التوزيع القسري للحصص الشاغرة
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            يوزع جميع الحصص الشاغرة على أي معلم لديه فراغ في الجدول، بغض النظر عن
            الرصيد التراكمي أو سقف الجولة.
          </p>
          <Button
            variant="destructive"
            className="w-full"
            disabled={forceDistribute.isPending}
            onClick={() => setShowForceConfirm(true)}
          >
            <Siren className="w-4 h-4 ml-2" />
            {forceDistribute.isPending ? "جاري التوزيع..." : "توزيع الحصص المتبقية قسرياً"}
          </Button>
        </CardContent>
      </Card>

      {/* ===== خطوة 3: إعادة القيود ===== */}
      {isEmergencyActive && (
        <Card className="border-green-500/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-400">
              <RotateCcw className="w-5 h-5" />
              الخطوة 3: إعادة القيود الطبيعية
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              يُعيد السقف الفردي إلى 4 حصص ويُلغي وضع الطوارئ من الجولة الحالية.
              يُنصح بتنفيذها فور الانتهاء من التوزيع.
            </p>
            <Button
              variant="outline"
              className="w-full border-green-500 text-green-400 hover:bg-green-950/30"
              disabled={restoreLimits.isPending}
              onClick={() => setShowRestoreConfirm(true)}
            >
              <RotateCcw className="w-4 h-4 ml-2" />
              {restoreLimits.isPending ? "جاري الإعادة..." : "إعادة القيود الطبيعية"}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* ===== نافذة تأكيد كسر القيود ===== */}
      <Dialog open={showBreakConfirm} onOpenChange={setShowBreakConfirm}>
        <DialogContent dir="rtl" className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-yellow-400 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5" />
              تأكيد تفعيل كسر القيود
            </DialogTitle>
            <DialogDescription>
              سيُرفع السقف الفردي لجميع المعلمين من 4 إلى 6 حصص أسبوعياً.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="reason-break">سبب الطوارئ (مطلوب للسجل)</Label>
              <Textarea
                id="reason-break"
                placeholder="مثال: عجز 4 حصص - 9 غياب في يوم واحد"
                value={emergencyReason}
                onChange={(e) => setEmergencyReason(e.target.value)}
                className="mt-1"
                rows={3}
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setShowBreakConfirm(false)}>
                إلغاء
              </Button>
              <Button
                className="bg-yellow-600 hover:bg-yellow-700 text-white"
                disabled={!emergencyReason.trim() || breakLimits.isPending}
                onClick={() =>
                  breakLimits.mutate({ date: selectedDate, reason: emergencyReason })
                }
              >
                {breakLimits.isPending ? "جاري التفعيل..." : "تأكيد التفعيل"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== نافذة تأكيد التوزيع القسري ===== */}
      <Dialog open={showForceConfirm} onOpenChange={setShowForceConfirm}>
        <DialogContent dir="rtl" className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-red-400 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              تأكيد التوزيع القسري
            </DialogTitle>
            <DialogDescription>
              سيتم توزيع الحصص المتبقية على أي معلم متاح بغض النظر عن:
              الرصيد التراكمي، سقف الجولة، وحماية النصاب 22+.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="reason-force">سبب التوزيع القسري</Label>
              <Textarea
                id="reason-force"
                placeholder="مثال: عجز 4 حصص - استنفاد جميع الخيارات الطبيعية"
                value={emergencyReason}
                onChange={(e) => setEmergencyReason(e.target.value)}
                className="mt-1"
                rows={3}
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setShowForceConfirm(false)}>
                إلغاء
              </Button>
              <Button
                variant="destructive"
                disabled={!emergencyReason.trim() || forceDistribute.isPending}
                onClick={() =>
                  forceDistribute.mutate({ date: selectedDate, reason: emergencyReason })
                }
              >
                {forceDistribute.isPending ? "جاري التوزيع..." : "تأكيد التوزيع القسري"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== نافذة تأكيد إعادة القيود ===== */}
      <Dialog open={showRestoreConfirm} onOpenChange={setShowRestoreConfirm}>
        <DialogContent dir="rtl" className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-green-400 flex items-center gap-2">
              <RotateCcw className="w-5 h-5" />
              تأكيد إعادة القيود الطبيعية
            </DialogTitle>
            <DialogDescription>
              سيُعاد السقف الفردي إلى 4 حصص وستُلغى حالة الطوارئ.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-2 justify-end mt-4">
            <Button variant="outline" onClick={() => setShowRestoreConfirm(false)}>
              إلغاء
            </Button>
            <Button
              className="border-green-500 text-green-400 hover:bg-green-950/30"
              variant="outline"
              disabled={restoreLimits.isPending}
              onClick={() => restoreLimits.mutate()}
            >
              {restoreLimits.isPending ? "جاري الإعادة..." : "تأكيد الإعادة"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ===== مكوّن StatBox =====
function StatBox({
  label,
  value,
  color,
  icon,
}: {
  label: string;
  value: number;
  color: "blue" | "green" | "red" | "purple";
  icon?: React.ReactNode;
}) {
  const colors = {
    blue: "bg-blue-950/40 text-blue-300 border-blue-700/40",
    green: "bg-green-950/40 text-green-300 border-green-700/40",
    red: "bg-red-950/40 text-red-300 border-red-700/40",
    purple: "bg-purple-950/40 text-purple-300 border-purple-700/40",
  };
  return (
    <div className={`rounded-xl p-4 text-center border ${colors[color]}`}>
      {icon && <div className="flex justify-center mb-2 opacity-60">{icon}</div>}
      <p className="text-3xl font-bold">{value}</p>
      <p className="text-xs mt-1 opacity-80">{label}</p>
    </div>
  );
}
