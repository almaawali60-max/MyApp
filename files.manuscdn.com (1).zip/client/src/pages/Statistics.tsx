import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { BarChart3, TrendingUp, Award, Users, CalendarX, Printer } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

const monthNames = [
  "يناير","فبراير","مارس","أبريل","مايو","يونيو",
  "يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"
];

export default function StatisticsPage() {
  const today = new Date();
  const [selectedYear, setSelectedYear] = useState(today.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(today.getMonth() + 1);

  const { data: stats, isLoading } = trpc.stats.monthly.useQuery({
    year: selectedYear,
    month: selectedMonth,
  });
  const { data: weeklyStats } = trpc.stats.weeklyStats.useQuery();
  // خريطة سريعة: teacherId => weeklyCount
  const weeklyCountMap = new Map(
    (weeklyStats || []).map((w: any) => [w.teacherId, { count: w.weeklyCount, max: w.maxAllowed }])
  );

  const years = [today.getFullYear(), today.getFullYear() - 1];

  const sortedBySubstitute = [...(stats || [])].sort((a, b) => b.substituteCount - a.substituteCount);
  const sortedByAbsence = [...(stats || [])].sort((a, b) => b.absenceCount - a.absenceCount);

  const totalSubstitutes = stats?.reduce((sum, s) => sum + s.substituteCount, 0) || 0;
  const totalAbsences = stats?.reduce((sum, s) => sum + s.absenceCount, 0) || 0;
  const activeTeachers = stats?.filter((s) => s.substituteCount > 0).length || 0;

  // Top 10 for chart
  const chartData = sortedBySubstitute.slice(0, 10).map((s) => ({
    name: s.teacher.shortName || s.teacher.name.split(" ").slice(0, 2).join(" "),
    count: s.substituteCount,
    fullName: s.teacher.name,
  }));

  const COLORS = [
    "oklch(0.32 0.11 145)",
    "oklch(0.42 0.11 145)",
    "oklch(0.52 0.11 145)",
    "oklch(0.62 0.11 145)",
    "oklch(0.72 0.11 145)",
    "oklch(0.55 0.13 75)",
    "oklch(0.65 0.13 75)",
    "oklch(0.45 0.1 200)",
    "oklch(0.55 0.1 200)",
    "oklch(0.65 0.1 200)",
  ];

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold" style={{ color: "oklch(0.25 0.06 145)" }}>
            الإحصائيات الشهرية
          </h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            تقارير توزيع الاحتياط لكل معلم
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => window.print()}
          className="gap-2 text-sm no-print"
          style={{ borderColor: "oklch(0.32 0.11 145)", color: "oklch(0.32 0.11 145)" }}
        >
          <Printer size={15} />
          طباعة
        </Button>
      </div>

      {/* Month/Year Selector */}
      <div className="flex items-center gap-3 no-print">
        <Select value={String(selectedMonth)} onValueChange={(v) => setSelectedMonth(Number(v))}>
          <SelectTrigger className="w-36 text-sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {monthNames.map((name, i) => (
              <SelectItem key={i + 1} value={String(i + 1)}>{name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={String(selectedYear)} onValueChange={(v) => setSelectedYear(Number(v))}>
          <SelectTrigger className="w-28 text-sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {years.map((y) => (
              <SelectItem key={y} value={String(y)}>{y}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: "oklch(0.97 0.02 145)" }}>
                <Award size={18} style={{ color: "oklch(0.32 0.11 145)" }} />
              </div>
              <div>
                <p className="text-xl font-bold" style={{ color: "oklch(0.32 0.11 145)" }}>
                  {totalSubstitutes}
                </p>
                <p className="text-xs text-muted-foreground">حصص احتياط</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: "oklch(0.97 0.02 25)" }}>
                <CalendarX size={18} style={{ color: "oklch(0.55 0.2 25)" }} />
              </div>
              <div>
                <p className="text-xl font-bold" style={{ color: "oklch(0.55 0.2 25)" }}>
                  {totalAbsences}
                </p>
                <p className="text-xs text-muted-foreground">حالات غياب</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: "oklch(0.97 0.02 75)" }}>
                <Users size={18} style={{ color: "oklch(0.55 0.13 75)" }} />
              </div>
              <div>
                <p className="text-xl font-bold" style={{ color: "oklch(0.55 0.13 75)" }}>
                  {activeTeachers}
                </p>
                <p className="text-xs text-muted-foreground">معلم شارك في الاحتياط</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: "oklch(0.97 0.02 280)" }}>
                <TrendingUp size={18} style={{ color: "oklch(0.45 0.12 280)" }} />
              </div>
              <div>
                <p className="text-xl font-bold" style={{ color: "oklch(0.45 0.12 280)" }}>
                  {activeTeachers > 0 ? (totalSubstitutes / activeTeachers).toFixed(1) : 0}
                </p>
                <p className="text-xs text-muted-foreground">متوسط الاحتياط/معلم</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bar Chart */}
      {chartData.length > 0 && (
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-bold">
              أكثر المعلمين احتياطاً (أعلى 10)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.9 0.01 120)" />
                  <XAxis
                    dataKey="name"
                    tick={{ fontSize: 10, fill: "oklch(0.4 0.03 240)" }}
                    angle={-35}
                    textAnchor="end"
                    interval={0}
                  />
                  <YAxis tick={{ fontSize: 10, fill: "oklch(0.4 0.03 240)" }} />
                  <Tooltip
                    formatter={(value, name, props) => [
                      `${value} حصة`,
                      props.payload?.fullName || name,
                    ]}
                    contentStyle={{ fontFamily: "Cairo, sans-serif", fontSize: 12, direction: "rtl" }}
                  />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                    {chartData.map((_, index) => (
                      <Cell key={index} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Full Table */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold">
            تفاصيل الاحتياط - {monthNames[selectedMonth - 1]} {selectedYear}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-10 rounded animate-pulse bg-muted" />
              ))}
            </div>
          ) : !stats || stats.length === 0 ? (
            <p className="text-center text-muted-foreground text-sm py-8">
              لا توجد بيانات لهذا الشهر
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ background: "oklch(0.94 0.02 145)" }}>
                    <th className="px-4 py-2.5 text-right font-semibold text-xs rounded-r-lg"
                      style={{ color: "oklch(0.25 0.06 145)" }}>#</th>
                    <th className="px-4 py-2.5 text-right font-semibold text-xs"
                      style={{ color: "oklch(0.25 0.06 145)" }}>اسم المعلم</th>
                    <th className="px-4 py-2.5 text-center font-semibold text-xs"
                      style={{ color: "oklch(0.25 0.06 145)" }}>النصاب الأسبوعي</th>
                    <th className="px-4 py-2.5 text-center font-semibold text-xs"
                      style={{ color: "oklch(0.25 0.06 145)" }}>حصص الاحتياط</th>
                    <th className="px-4 py-2.5 text-center font-semibold text-xs"
                      style={{ color: "oklch(0.25 0.06 145)" }}>هذا الأسبوع</th>
                    <th className="px-4 py-2.5 text-center font-semibold text-xs rounded-l-lg"
                      style={{ color: "oklch(0.25 0.06 145)" }}>أيام الغياب</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedBySubstitute.map((item, idx) => (
                    <tr
                      key={item.teacher.id}
                      style={{ background: idx % 2 === 0 ? "oklch(0.99 0.005 120)" : "white" }}
                    >
                      <td className="px-4 py-2.5 text-center text-xs text-muted-foreground">
                        {idx + 1}
                      </td>
                      <td className="px-4 py-2.5">
                        <div className="flex items-center gap-2">
                          <div
                            className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0"
                            style={{ background: item.teacher.color || "oklch(0.32 0.11 145)" }}
                          >
                            {item.teacher.name.charAt(0)}
                          </div>
                          <span className="font-medium">{item.teacher.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-2.5 text-center text-muted-foreground">
                        {item.teacher.weeklyLoad || 0}
                      </td>
                      <td className="px-4 py-2.5 text-center">
                        {item.substituteCount > 0 ? (
                          <Badge
                            className="text-xs"
                            style={{
                              background: item.substituteCount > 10
                                ? "oklch(0.55 0.2 25)"
                                : item.substituteCount > 5
                                ? "oklch(0.65 0.13 75)"
                                : "oklch(0.32 0.11 145)",
                              color: "white"
                            }}
                          >
                            {item.substituteCount}
                          </Badge>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </td>
                      <td className="px-4 py-2.5 text-center">
                        {(() => {
                          const wk = weeklyCountMap.get(item.teacher.id);
                          const cnt = wk?.count || 0;
                          const max = wk?.max || 4;
                          const isAtLimit = cnt >= max;
                          const isNearLimit = cnt >= max - 1 && cnt < max;
                          return (
                            <span
                              className="inline-flex items-center justify-center px-2 py-0.5 rounded-full text-xs font-bold"
                              style={{
                                background: isAtLimit
                                  ? 'oklch(0.92 0.15 25)'
                                  : isNearLimit
                                  ? 'oklch(0.95 0.1 75)'
                                  : 'oklch(0.93 0.05 145)',
                                color: isAtLimit
                                  ? 'oklch(0.45 0.2 25)'
                                  : isNearLimit
                                  ? 'oklch(0.45 0.12 75)'
                                  : 'oklch(0.3 0.1 145)',
                              }}
                              title={isAtLimit ? 'وصل للحد الأقصى' : isNearLimit ? 'قريب من الحد' : ''}
                            >
                              {cnt}/{max}
                            </span>
                          );
                        })()}
                      </td>
                      <td className="px-4 py-2.5 text-center">
                        {item.absenceCount > 0 ? (
                          <Badge variant="outline" className="text-xs"
                            style={{ borderColor: "oklch(0.55 0.2 25)", color: "oklch(0.55 0.2 25)" }}>
                            {item.absenceCount}
                          </Badge>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white !important; }
        }
      `}</style>
    </div>
  );
}
