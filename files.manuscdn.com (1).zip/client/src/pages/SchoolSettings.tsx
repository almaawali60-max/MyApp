import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Building2, Save, RefreshCw, School, Phone, Mail, Globe, MapPin } from "lucide-react";

export default function SchoolSettingsPage() {
  const { data: settings, isLoading, refetch } = trpc.schoolSettings.get.useQuery();
  const updateMutation = trpc.schoolSettings.update.useMutation({
    onSuccess: () => {
      toast.success("تم حفظ إعدادات المدرسة بنجاح");
      refetch();
    },
    onError: (err) => toast.error("خطأ في الحفظ: " + err.message),
  });

  const [form, setForm] = useState({
    schoolName: "",
    schoolSubtitle: "",
    directorate: "",
    ministry: "",
    country: "",
    logoUrl: "",
    adminContact: "",
    adminPhone: "",
  });

  useEffect(() => {
    if (settings) {
      setForm({
        schoolName: settings.schoolName || "",
        schoolSubtitle: settings.schoolSubtitle || "",
        directorate: settings.directorate || "",
        ministry: settings.ministry || "",
        country: settings.country || "",
        logoUrl: settings.logoUrl || "",
        adminContact: settings.adminContact || "",
        adminPhone: settings.adminPhone || "",
      });
    }
  }, [settings]);

  const handleSave = () => {
    updateMutation.mutate(form);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="animate-spin" size={32} style={{ color: "oklch(0.75 0.13 75)" }} />
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div
          className="w-12 h-12 rounded-xl flex items-center justify-center"
          style={{ background: "oklch(0.75 0.13 75)" }}
        >
          <Building2 size={24} style={{ color: "oklch(0.15 0.05 145)" }} />
        </div>
        <div>
          <h1 className="text-xl font-bold" style={{ color: "oklch(0.9 0.01 120)" }}>
            إعدادات المدرسة
          </h1>
          <p className="text-sm" style={{ color: "oklch(0.6 0.03 120)" }}>
            تخصيص هوية المدرسة وبياناتها الرسمية
          </p>
        </div>
      </div>

      {/* Preview Card */}
      <Card style={{ background: "oklch(0.18 0.07 145)", border: "1px solid oklch(0.28 0.05 145)" }}>
        <CardHeader>
          <CardTitle className="text-sm font-medium" style={{ color: "oklch(0.75 0.13 75)" }}>
            معاينة الهوية
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center space-y-2 py-4">
            {form.logoUrl ? (
              <img src={form.logoUrl} alt="شعار المدرسة" className="w-16 h-16 rounded-full mx-auto object-cover" />
            ) : (
              <div
                className="w-16 h-16 rounded-full mx-auto flex items-center justify-center"
                style={{ background: "oklch(0.75 0.13 75)" }}
              >
                <School size={32} style={{ color: "oklch(0.15 0.05 145)" }} />
              </div>
            )}
            <p className="text-xs" style={{ color: "oklch(0.75 0.13 75)" }}>
              {form.country} — {form.ministry}
            </p>
            <p className="text-xs" style={{ color: "oklch(0.65 0.03 120)" }}>
              {form.directorate}
            </p>
            <h2 className="text-lg font-bold" style={{ color: "oklch(0.9 0.01 120)" }}>
              {form.schoolName || "اسم المدرسة"}
            </h2>
            <p className="text-sm" style={{ color: "oklch(0.65 0.03 120)" }}>
              {form.schoolSubtitle}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Form */}
      <Card style={{ background: "oklch(0.18 0.07 145)", border: "1px solid oklch(0.28 0.05 145)" }}>
        <CardHeader>
          <CardTitle className="text-base font-semibold" style={{ color: "oklch(0.9 0.01 120)" }}>
            البيانات الرسمية
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label style={{ color: "oklch(0.75 0.13 75)" }}>اسم المدرسة *</Label>
              <Input
                value={form.schoolName}
                onChange={(e) => setForm({ ...form, schoolName: e.target.value })}
                placeholder="مدرسة الخوير للتعليم الأساسي (5-9)"
                className="text-right"
                style={{ background: "oklch(0.22 0.07 145)", border: "1px solid oklch(0.32 0.05 145)", color: "oklch(0.9 0.01 120)" }}
              />
            </div>
            <div className="space-y-1.5">
              <Label style={{ color: "oklch(0.75 0.13 75)" }}>وصف النظام</Label>
              <Input
                value={form.schoolSubtitle}
                onChange={(e) => setForm({ ...form, schoolSubtitle: e.target.value })}
                placeholder="نظام توزيع الاحتياط اليومي"
                className="text-right"
                style={{ background: "oklch(0.22 0.07 145)", border: "1px solid oklch(0.32 0.05 145)", color: "oklch(0.9 0.01 120)" }}
              />
            </div>
            <div className="space-y-1.5">
              <Label style={{ color: "oklch(0.75 0.13 75)" }}>
                <MapPin size={14} className="inline ml-1" />
                المديرية
              </Label>
              <Input
                value={form.directorate}
                onChange={(e) => setForm({ ...form, directorate: e.target.value })}
                placeholder="المديرية العامة للتعليم بمسقط"
                className="text-right"
                style={{ background: "oklch(0.22 0.07 145)", border: "1px solid oklch(0.32 0.05 145)", color: "oklch(0.9 0.01 120)" }}
              />
            </div>
            <div className="space-y-1.5">
              <Label style={{ color: "oklch(0.75 0.13 75)" }}>الوزارة</Label>
              <Input
                value={form.ministry}
                onChange={(e) => setForm({ ...form, ministry: e.target.value })}
                placeholder="وزارة التعليم"
                className="text-right"
                style={{ background: "oklch(0.22 0.07 145)", border: "1px solid oklch(0.32 0.05 145)", color: "oklch(0.9 0.01 120)" }}
              />
            </div>
            <div className="space-y-1.5">
              <Label style={{ color: "oklch(0.75 0.13 75)" }}>
                <Globe size={14} className="inline ml-1" />
                الدولة
              </Label>
              <Input
                value={form.country}
                onChange={(e) => setForm({ ...form, country: e.target.value })}
                placeholder="سلطنة عُمان"
                className="text-right"
                style={{ background: "oklch(0.22 0.07 145)", border: "1px solid oklch(0.32 0.05 145)", color: "oklch(0.9 0.01 120)" }}
              />
            </div>
            <div className="space-y-1.5">
              <Label style={{ color: "oklch(0.75 0.13 75)" }}>رابط الشعار (URL)</Label>
              <Input
                value={form.logoUrl}
                onChange={(e) => setForm({ ...form, logoUrl: e.target.value })}
                placeholder="https://..."
                className="text-right"
                dir="ltr"
                style={{ background: "oklch(0.22 0.07 145)", border: "1px solid oklch(0.32 0.05 145)", color: "oklch(0.9 0.01 120)" }}
              />
            </div>
            <div className="space-y-1.5">
              <Label style={{ color: "oklch(0.75 0.13 75)" }}>
                <Mail size={14} className="inline ml-1" />
                البريد الإلكتروني
              </Label>
              <Input
                value={form.adminContact}
                onChange={(e) => setForm({ ...form, adminContact: e.target.value })}
                placeholder="almaawali60@gmail.com"
                className="text-right"
                dir="ltr"
                style={{ background: "oklch(0.22 0.07 145)", border: "1px solid oklch(0.32 0.05 145)", color: "oklch(0.9 0.01 120)" }}
              />
            </div>
            <div className="space-y-1.5">
              <Label style={{ color: "oklch(0.75 0.13 75)" }}>
                <Phone size={14} className="inline ml-1" />
                رقم الهاتف
              </Label>
              <Input
                value={form.adminPhone}
                onChange={(e) => setForm({ ...form, adminPhone: e.target.value })}
                placeholder="0096892668828"
                className="text-right"
                dir="ltr"
                style={{ background: "oklch(0.22 0.07 145)", border: "1px solid oklch(0.32 0.05 145)", color: "oklch(0.9 0.01 120)" }}
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <Button
              onClick={handleSave}
              disabled={updateMutation.isPending}
              className="gap-2 font-semibold"
              style={{ background: "oklch(0.75 0.13 75)", color: "oklch(0.15 0.05 145)" }}
            >
              {updateMutation.isPending ? (
                <RefreshCw size={16} className="animate-spin" />
              ) : (
                <Save size={16} />
              )}
              حفظ الإعدادات
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
