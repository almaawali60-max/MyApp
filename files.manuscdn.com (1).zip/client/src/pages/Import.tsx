import { useState, useRef, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  Upload, FileText, CheckCircle2, AlertCircle, Info,
  Users, BookOpen, FileImage, Loader2, ChevronRight
} from "lucide-react";

type ImportTab = "xml" | "pdf";

// مراحل استيراد PDF
type PdfPhase =
  | { type: "idle" }
  | { type: "reading" }                                    // قراءة الملف في المتصفح
  | { type: "init"; pageCount: number }                   // تهيئة + حذف القديم
  | { type: "converting"; current: number; total: number } // تحويل صفحة → صورة
  | { type: "analyzing"; current: number; total: number; teachers: number; entries: number; lastTeacher?: string }
  | { type: "done"; teachers: number; entries: number; pages: number };

interface ImportResult {
  teachersImported: number;
  scheduleEntriesImported: number;
  pagesProcessed?: number;
}

export default function ImportPage() {
  const utils = trpc.useUtils();
  const [activeTab, setActiveTab] = useState<ImportTab>("xml");

  // XML state
  const [isDraggingXml, setIsDraggingXml] = useState(false);
  const [selectedXmlFile, setSelectedXmlFile] = useState<File | null>(null);
  const xmlFileInputRef = useRef<HTMLInputElement>(null);

  // PDF state
  const [isDraggingPdf, setIsDraggingPdf] = useState(false);
  const [selectedPdfFile, setSelectedPdfFile] = useState<File | null>(null);
  const [clearOld, setClearOld] = useState(true);
  const [pdfPhase, setPdfPhase] = useState<PdfPhase>({ type: "idle" });
  const pdfFileInputRef = useRef<HTMLInputElement>(null);

  // Shared result/error
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const isPdfBusy = pdfPhase.type !== "idle" && pdfPhase.type !== "done";

  // XML mutation
  const xmlMutation = trpc.teachers.importXml.useMutation({
    onSuccess: (data) => {
      utils.teachers.list.invalidate();
      setImportResult(data);
      toast.success(`تم استيراد ${data.teachersImported} معلم و${data.scheduleEntriesImported} حصة بنجاح`);
    },
    onError: (err) => {
      setError(err.message || "حدث خطأ أثناء معالجة الملف");
      toast.error("فشل استيراد الملف");
    },
  });

  // PDF procedures
  const initMutation = trpc.teachers.importPdfInit.useMutation();
  const convertPageMutation = trpc.teachers.importPdfConvertPage.useMutation();
  const analyzePageMutation = trpc.teachers.importPdfPage.useMutation();
  const finalizeMutation = trpc.teachers.importPdfFinalize.useMutation();
  const deleteAllMutation = trpc.teachers.deleteAllTeachers.useMutation({
    onSuccess: () => { utils.teachers.list.invalidate(); toast.success("تم حذف جميع المعلمين بنجاح"); },
    onError: () => toast.error("فشل حذف المعلمين"),
  });
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // XML handler
  const handleXmlFile = async (file: File) => {
    if (!file.name.endsWith(".xml")) { toast.error("يرجى رفع ملف XML فقط"); return; }
    setSelectedXmlFile(file);
    setImportResult(null);
    setError(null);
    try {
      const buffer = await file.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      const rawHeader = new TextDecoder("iso-8859-1").decode(bytes.slice(0, 200));
      const encodingMatch = rawHeader.match(/encoding=["']([^"']+)["']/i);
      const declaredEncoding = encodingMatch ? encodingMatch[1].toLowerCase() : "utf-8";
      let browserEncoding = "utf-8";
      if (declaredEncoding.includes("1256") || declaredEncoding.includes("cp1256")) browserEncoding = "windows-1256";
      else if (declaredEncoding.includes("1252")) browserEncoding = "windows-1252";
      else if (declaredEncoding.includes("iso-8859-6")) browserEncoding = "iso-8859-6";
      let text: string;
      try { text = new TextDecoder(browserEncoding).decode(buffer); }
      catch { try { text = new TextDecoder("windows-1256").decode(buffer); } catch { text = new TextDecoder("utf-8", { fatal: false }).decode(buffer); } }
      if (!text.includes("<timetable") && !text.includes("<teacher")) { setError("الملف ليس جدول aSc Timetables صالح."); return; }
      xmlMutation.mutate({ xmlContent: text });
    } catch { setError("تعذر قراءة الملف."); }
  };

  // PDF handler — 3 phases, each page is a separate request
  const handlePdfFile = useCallback(async (file: File) => {
    if (!file.name.toLowerCase().endsWith(".pdf")) { toast.error("يرجى رفع ملف PDF فقط"); return; }
    setSelectedPdfFile(file);
    setImportResult(null);
    setError(null);

    // Phase 0: read file in browser
    setPdfPhase({ type: "reading" });
    let base64: string;
    try {
      const buffer = await file.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      let binary = "";
      const chunk = 8192;
      for (let i = 0; i < bytes.length; i += chunk)
        binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunk)));
      base64 = btoa(binary);
    } catch {
      setPdfPhase({ type: "idle" });
      setError("تعذر قراءة ملف PDF.");
      return;
    }

    // Phase 1: init — get page count + delete old
    setPdfPhase({ type: "init", pageCount: 0 });
    let pageCount: number;
    try {
      const res = await initMutation.mutateAsync({ pdfBase64: base64, clearOld });
      pageCount = res.pageCount;
      setPdfPhase({ type: "init", pageCount });
    } catch (err: unknown) {
      setPdfPhase({ type: "idle" });
      setError(err instanceof Error ? err.message : "فشل فتح ملف PDF");
      toast.error("فشل فتح ملف PDF");
      return;
    }

    // Phase 2: convert each page to image
    const pageImages: string[] = new Array(pageCount).fill("");
    setPdfPhase({ type: "converting", current: 0, total: pageCount });

    for (let i = 0; i < pageCount; i++) {
      try {
        const res = await convertPageMutation.mutateAsync({ pdfBase64: base64, pageIndex: i });
        pageImages[i] = res.imageBase64;
      } catch {
        pageImages[i] = ""; // skip failed page
      }
      setPdfPhase({ type: "converting", current: i + 1, total: pageCount });
    }

    // Phase 3: analyze each page with LLM
    let teachers = 0, entries = 0;
    const importedNames: string[] = []; // تجميع أسماء المعلمين المستوردين
    setPdfPhase({ type: "analyzing", current: 0, total: pageCount, teachers: 0, entries: 0 });

    for (let i = 0; i < pageCount; i++) {
      if (!pageImages[i]) { setPdfPhase(prev => prev.type === "analyzing" ? { ...prev, current: i + 1 } : prev); continue; }
      try {
        const res = await analyzePageMutation.mutateAsync({ pageImageBase64: pageImages[i], pageIndex: i });
        if (res.success && !res.skipped) {
          teachers++;
          entries += (res as { entriesCount?: number }).entriesCount ?? 0;
          const tName = (res as { teacherName?: string }).teacherName;
          if (tName) importedNames.push(tName);
        }
        setPdfPhase({
          type: "analyzing",
          current: i + 1,
          total: pageCount,
          teachers,
          entries,
          lastTeacher: res.success && !res.skipped ? (res as { teacherName?: string }).teacherName : undefined,
        });
      } catch {
        setPdfPhase(prev => prev.type === "analyzing" ? { ...prev, current: i + 1 } : prev);
      }
    }

    // Phase 4: finalize — deactivate teachers not in new schedule
    if (clearOld && importedNames.length > 0) {
      try { await finalizeMutation.mutateAsync({ importedTeacherNames: importedNames, clearOld }); } catch { /* non-critical */ }
    }

    // Done
    setPdfPhase({ type: "done", teachers, entries, pages: pageCount });
    utils.teachers.list.invalidate();
    setImportResult({ teachersImported: teachers, scheduleEntriesImported: entries, pagesProcessed: pageCount });
    toast.success(`تم استيراد ${teachers} معلم و${entries} حصة من ${pageCount} صفحة`);
  }, [clearOld, initMutation, convertPageMutation, analyzePageMutation, finalizeMutation, utils]);

  // Progress bar helper
  const ProgressBar = ({ value, total, color }: { value: number; total: number; color: string }) => (
    <div className="w-full bg-muted rounded-full h-2.5 overflow-hidden">
      <div
        className="h-full rounded-full transition-all duration-300"
        style={{ width: total > 0 ? `${Math.round((value / total) * 100)}%` : "0%", background: color }}
      />
    </div>
  );

  // Phase step indicator
  const phases = [
    { key: "reading", label: "قراءة الملف" },
    { key: "init", label: "تهيئة" },
    { key: "converting", label: "تحويل الصفحات" },
    { key: "analyzing", label: "تحليل بالذكاء الاصطناعي" },
    { key: "done", label: "اكتمل" },
  ];
  const currentPhaseIndex = phases.findIndex(p => p.key === pdfPhase.type);

  return (
    <div className="space-y-5 max-w-2xl mx-auto">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold" style={{ color: "oklch(0.25 0.06 145)" }}>رفع جدول المعلمين</h2>
        <p className="text-sm text-muted-foreground mt-0.5">استيراد جدول المعلمين من ملف XML أو PDF</p>
      </div>

      {/* زر حذف كل المعلمين */}
      <div className="flex justify-end">
        {!showDeleteConfirm ? (
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="flex items-center gap-1.5 text-xs text-red-500 hover:text-red-700 border border-red-200 hover:border-red-400 rounded-md px-3 py-1.5 transition-all"
          >
            حذف جميع المعلمين
          </button>
        ) : (
          <div className="flex items-center gap-2 text-xs border border-red-300 rounded-md px-3 py-1.5 bg-red-50">
            <span className="text-red-700 font-medium">تأكيد: حذف جميع المعلمين وجداولهم نهائياً؟</span>
            <button
              onClick={() => { deleteAllMutation.mutate(); setShowDeleteConfirm(false); }}
              disabled={deleteAllMutation.isPending}
              className="bg-red-600 text-white rounded px-2 py-0.5 hover:bg-red-700 disabled:opacity-50"
            >
              {deleteAllMutation.isPending ? "جاري..." : "نعم احذف"}
            </button>
            <button onClick={() => setShowDeleteConfirm(false)} className="text-muted-foreground hover:text-foreground">إلغاء</button>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 rounded-lg border bg-muted/30">
        {(["xml", "pdf"] as ImportTab[]).map(tab => (
          <button
            key={tab}
            onClick={() => { setActiveTab(tab); setImportResult(null); setError(null); setPdfPhase({ type: "idle" }); }}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-md text-sm font-medium transition-all ${activeTab === tab ? "bg-white shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}
          >
            {tab === "xml" ? <FileText size={15} /> : <FileImage size={15} />}
            {tab === "xml" ? "ملف XML" : "ملف PDF"}
          </button>
        ))}
      </div>

      {/* XML Tab */}
      {activeTab === "xml" && (
        <>
          <Card className="border-0 shadow-sm" style={{ background: "oklch(0.97 0.02 200)" }}>
            <CardContent className="p-4">
              <div className="flex gap-3">
                <Info size={16} className="shrink-0 mt-0.5" style={{ color: "oklch(0.45 0.1 200)" }} />
                <div className="text-sm space-y-1" style={{ color: "oklch(0.35 0.08 200)" }}>
                  <p className="font-semibold">تعليمات استيراد XML:</p>
                  <p>• قم برفع ملف XML المُصدَّر من برنامج aSc Timetables</p>
                  <p>• سيتم استخراج أسماء المعلمين وجداولهم الأسبوعية تلقائياً</p>
                  <p>• <strong>تنبيه:</strong> سيتم استبدال الجداول الموجودة مسبقاً</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card
            className={`border-2 border-dashed transition-all duration-200 cursor-pointer ${isDraggingXml ? "border-primary scale-[1.01]" : "border-border hover:border-primary/50"}`}
            style={isDraggingXml ? { background: "oklch(0.97 0.02 145)" } : {}}
            onDragOver={(e) => { e.preventDefault(); setIsDraggingXml(true); }}
            onDragLeave={() => setIsDraggingXml(false)}
            onDrop={(e) => { e.preventDefault(); setIsDraggingXml(false); const f = e.dataTransfer.files[0]; if (f) handleXmlFile(f); }}
            onClick={() => xmlFileInputRef.current?.click()}
          >
            <CardContent className="py-12 text-center">
              <input ref={xmlFileInputRef} type="file" accept=".xml" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleXmlFile(f); }} />
              {xmlMutation.isPending ? (
                <div className="space-y-3">
                  <div className="w-14 h-14 rounded-full mx-auto flex items-center justify-center animate-pulse" style={{ background: "oklch(0.94 0.02 145)" }}>
                    <Loader2 size={24} className="animate-spin" style={{ color: "oklch(0.32 0.11 145)" }} />
                  </div>
                  <p className="font-semibold" style={{ color: "oklch(0.32 0.11 145)" }}>جاري معالجة الملف...</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="w-14 h-14 rounded-full mx-auto flex items-center justify-center" style={{ background: "oklch(0.94 0.02 145)" }}>
                    <Upload size={24} style={{ color: "oklch(0.32 0.11 145)" }} />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">اسحب ملف XML هنا أو انقر للاختيار</p>
                    <p className="text-sm text-muted-foreground mt-1">يدعم ملفات .xml فقط</p>
                  </div>
                  <Button variant="outline" size="sm" className="gap-2" style={{ borderColor: "oklch(0.32 0.11 145)", color: "oklch(0.32 0.11 145)" }} onClick={(e) => { e.stopPropagation(); xmlFileInputRef.current?.click(); }}>
                    <FileText size={14} /> اختيار الملف
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
          {selectedXmlFile && !xmlMutation.isPending && (
            <div className="flex items-center gap-3 p-3 rounded-lg border" style={{ background: "oklch(0.97 0.02 145)", borderColor: "oklch(0.88 0.02 145)" }}>
              <FileText size={16} style={{ color: "oklch(0.32 0.11 145)" }} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{selectedXmlFile.name}</p>
                <p className="text-xs text-muted-foreground">{(selectedXmlFile.size / 1024).toFixed(1)} KB</p>
              </div>
            </div>
          )}
        </>
      )}

      {/* PDF Tab */}
      {activeTab === "pdf" && (
        <>
          <Card className="border-0 shadow-sm" style={{ background: "oklch(0.97 0.02 55)" }}>
            <CardContent className="p-4">
              <div className="flex gap-3">
                <Info size={16} className="shrink-0 mt-0.5" style={{ color: "oklch(0.5 0.12 55)" }} />
                <div className="text-sm space-y-1" style={{ color: "oklch(0.35 0.08 55)" }}>
                  <p className="font-semibold">تعليمات استيراد PDF:</p>
                  <p>• قم برفع ملف PDF الخاص بجدول المعلمين (كل صفحة = معلم واحد)</p>
                  <p>• يستخدم النظام الذكاء الاصطناعي لاستخراج الأسماء والجداول تلقائياً</p>
                  <p>• <strong>قد تستغرق المعالجة عدة دقائق</strong> حسب عدد الصفحات</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Clear old option */}
          <div className="flex items-center gap-3 p-3 rounded-lg border bg-muted/20">
            <input type="checkbox" id="clearOld" checked={clearOld} onChange={(e) => setClearOld(e.target.checked)} className="w-4 h-4 rounded" disabled={isPdfBusy} />
            <label htmlFor="clearOld" className="text-sm cursor-pointer">
              <span className="font-medium">حذف الجدول القديم قبل الاستيراد</span>
              <span className="text-muted-foreground mr-1">(يُنصح به عند رفع جدول جديد كلياً)</span>
            </label>
          </div>

          {/* Drop zone */}
          <Card
            className={`border-2 border-dashed transition-all duration-200 ${isPdfBusy ? "opacity-60 cursor-not-allowed" : "cursor-pointer"} ${isDraggingPdf ? "border-amber-500 scale-[1.01]" : "border-border hover:border-amber-400/70"}`}
            style={isDraggingPdf ? { background: "oklch(0.97 0.02 75)" } : {}}
            onDragOver={(e) => { e.preventDefault(); if (!isPdfBusy) setIsDraggingPdf(true); }}
            onDragLeave={() => setIsDraggingPdf(false)}
            onDrop={(e) => { e.preventDefault(); setIsDraggingPdf(false); if (!isPdfBusy) { const f = e.dataTransfer.files[0]; if (f) handlePdfFile(f); } }}
            onClick={() => !isPdfBusy && pdfFileInputRef.current?.click()}
          >
            <CardContent className="py-10 text-center">
              <input ref={pdfFileInputRef} type="file" accept=".pdf" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handlePdfFile(f); }} />
              <div className="space-y-3">
                <div className="w-14 h-14 rounded-full mx-auto flex items-center justify-center" style={{ background: "oklch(0.94 0.04 75)" }}>
                  {isPdfBusy
                    ? <Loader2 size={24} className="animate-spin" style={{ color: "oklch(0.55 0.13 75)" }} />
                    : <FileImage size={24} style={{ color: "oklch(0.55 0.13 75)" }} />
                  }
                </div>
                <div>
                  <p className="font-semibold text-foreground">
                    {isPdfBusy ? "جاري المعالجة..." : "اسحب ملف PDF هنا أو انقر للاختيار"}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {isPdfBusy ? "يرجى الانتظار حتى اكتمال المعالجة" : "يدعم ملفات .pdf فقط"}
                  </p>
                </div>
                {!isPdfBusy && (
                  <Button variant="outline" size="sm" className="gap-2" style={{ borderColor: "oklch(0.55 0.13 75)", color: "oklch(0.55 0.13 75)" }} onClick={(e) => { e.stopPropagation(); pdfFileInputRef.current?.click(); }}>
                    <FileImage size={14} /> اختيار ملف PDF
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* File info + progress below the file */}
          {selectedPdfFile && (
            <div className="rounded-xl border overflow-hidden" style={{ borderColor: "oklch(0.88 0.04 75)" }}>
              {/* File row */}
              <div className="flex items-center gap-3 p-3" style={{ background: "oklch(0.97 0.02 75)" }}>
                <FileImage size={16} style={{ color: "oklch(0.55 0.13 75)" }} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{selectedPdfFile.name}</p>
                  <p className="text-xs text-muted-foreground">{(selectedPdfFile.size / 1024 / 1024).toFixed(2)} MB</p>
                </div>
                {pdfPhase.type === "done" && <CheckCircle2 size={18} style={{ color: "oklch(0.45 0.15 145)" }} />}
              </div>

              {/* Progress section — shown when busy or done */}
              {pdfPhase.type !== "idle" && (
                <div className="p-4 space-y-4 border-t" style={{ background: "white", borderColor: "oklch(0.92 0.02 75)" }}>

                  {/* Step indicator */}
                  <div className="flex items-center gap-1 text-xs">
                    {phases.map((p, idx) => {
                      const isActive = p.key === pdfPhase.type;
                      const isDone = currentPhaseIndex > idx;
                      return (
                        <div key={p.key} className="flex items-center gap-1">
                          <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full font-medium transition-all ${
                            isActive ? "text-white" : isDone ? "text-white" : "text-muted-foreground bg-muted"
                          }`} style={isActive ? { background: "oklch(0.55 0.13 75)" } : isDone ? { background: "oklch(0.45 0.15 145)" } : {}}>
                            {isDone && <CheckCircle2 size={10} />}
                            {isActive && <Loader2 size={10} className="animate-spin" />}
                            {p.label}
                          </div>
                          {idx < phases.length - 1 && <ChevronRight size={10} className="text-muted-foreground shrink-0" />}
                        </div>
                      );
                    })}
                  </div>

                  {/* Phase-specific progress */}
                  {pdfPhase.type === "reading" && (
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">جاري قراءة الملف في المتصفح...</p>
                      <ProgressBar value={0} total={1} color="oklch(0.55 0.13 75)" />
                    </div>
                  )}

                  {pdfPhase.type === "init" && (
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">
                        {pdfPhase.pageCount > 0
                          ? `تم اكتشاف ${pdfPhase.pageCount} صفحة — جاري التهيئة...`
                          : "جاري فتح الملف وحذف الجدول القديم..."}
                      </p>
                      <div className="w-full bg-muted rounded-full h-2.5 overflow-hidden">
                        <div className="h-full rounded-full animate-pulse" style={{ width: "30%", background: "oklch(0.55 0.13 75)" }} />
                      </div>
                    </div>
                  )}

                  {pdfPhase.type === "converting" && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">تحويل الصفحات إلى صور</span>
                        <span className="font-semibold" style={{ color: "oklch(0.45 0.1 75)" }}>
                          {pdfPhase.current} / {pdfPhase.total}
                        </span>
                      </div>
                      <ProgressBar value={pdfPhase.current} total={pdfPhase.total} color="oklch(0.55 0.13 75)" />
                      <p className="text-xs text-muted-foreground text-left">
                        {Math.round((pdfPhase.current / pdfPhase.total) * 100)}% مكتمل
                      </p>
                    </div>
                  )}

                  {pdfPhase.type === "analyzing" && (
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">تحليل الصفحات بالذكاء الاصطناعي</span>
                        <span className="font-semibold" style={{ color: "oklch(0.45 0.1 75)" }}>
                          {pdfPhase.current} / {pdfPhase.total}
                        </span>
                      </div>
                      <ProgressBar value={pdfPhase.current} total={pdfPhase.total} color="oklch(0.45 0.15 145)" />
                      <div className="flex justify-between items-center">
                        <p className="text-xs text-muted-foreground">
                          {Math.round((pdfPhase.current / pdfPhase.total) * 100)}% مكتمل
                        </p>
                        <div className="flex gap-4 text-xs">
                          <span className="font-semibold" style={{ color: "oklch(0.32 0.11 145)" }}>
                            {pdfPhase.teachers} معلم
                          </span>
                          <span className="font-semibold" style={{ color: "oklch(0.55 0.13 75)" }}>
                            {pdfPhase.entries} حصة
                          </span>
                        </div>
                      </div>
                      {pdfPhase.lastTeacher && (
                        <p className="text-xs text-muted-foreground truncate">
                          آخر معلم: <span className="font-medium text-foreground">{pdfPhase.lastTeacher}</span>
                        </p>
                      )}
                    </div>
                  )}

                  {pdfPhase.type === "done" && (
                    <div className="flex items-center gap-2 text-sm" style={{ color: "oklch(0.32 0.11 145)" }}>
                      <CheckCircle2 size={16} />
                      <span className="font-semibold">اكتمل الاستيراد بنجاح!</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </>
      )}

      {/* Success Result */}
      {importResult && (
        <Card className="border-0 shadow-sm" style={{ background: "oklch(0.97 0.02 145)" }}>
          <CardContent className="p-5">
            <div className="flex items-start gap-3">
              <CheckCircle2 size={20} className="shrink-0 mt-0.5" style={{ color: "oklch(0.32 0.11 145)" }} />
              <div className="space-y-3 flex-1">
                <p className="font-bold" style={{ color: "oklch(0.25 0.06 145)" }}>تم الاستيراد بنجاح!</p>
                <div className={`grid gap-3 ${importResult.pagesProcessed !== undefined ? "grid-cols-3" : "grid-cols-2"}`}>
                  <div className="p-3 rounded-lg bg-white text-center">
                    <Users size={14} className="mx-auto mb-1" style={{ color: "oklch(0.32 0.11 145)" }} />
                    <p className="text-2xl font-bold" style={{ color: "oklch(0.32 0.11 145)" }}>{importResult.teachersImported}</p>
                    <p className="text-xs text-muted-foreground">معلم تم استيراده</p>
                  </div>
                  <div className="p-3 rounded-lg bg-white text-center">
                    <BookOpen size={14} className="mx-auto mb-1" style={{ color: "oklch(0.55 0.13 75)" }} />
                    <p className="text-2xl font-bold" style={{ color: "oklch(0.55 0.13 75)" }}>{importResult.scheduleEntriesImported}</p>
                    <p className="text-xs text-muted-foreground">حصة في الجدول</p>
                  </div>
                  {importResult.pagesProcessed !== undefined && (
                    <div className="p-3 rounded-lg bg-white text-center">
                      <FileImage size={14} className="mx-auto mb-1" style={{ color: "oklch(0.5 0.12 55)" }} />
                      <p className="text-2xl font-bold" style={{ color: "oklch(0.5 0.12 55)" }}>{importResult.pagesProcessed}</p>
                      <p className="text-xs text-muted-foreground">صفحة معالجة</p>
                    </div>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">يمكنك الآن الانتقال إلى صفحة إدارة المعلمين للتحقق من البيانات المستوردة</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Error */}
      {error && (
        <Card className="border-0 shadow-sm" style={{ background: "oklch(0.97 0.02 25)" }}>
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertCircle size={16} className="shrink-0 mt-0.5" style={{ color: "oklch(0.55 0.2 25)" }} />
              <div>
                <p className="font-semibold text-sm" style={{ color: "oklch(0.45 0.15 25)" }}>خطأ في الاستيراد</p>
                <p className="text-sm mt-1" style={{ color: "oklch(0.45 0.15 25)" }}>{error}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
